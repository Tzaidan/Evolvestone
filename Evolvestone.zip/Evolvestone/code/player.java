class player {
    deck d;
    hand h;
    battleField b;
    int life;
    int mana;
    int id;
    int maxMana;
    int maxLife;
    int deckSize;
    int handSize;
    int battleSize;
    rules r;
    
    public player (int playerId, int maxManaPoints, int startManaPoints, int maxLifePoints, int maxDeckSize, int maxHandSize, int maxBattleSize, rules rule) {
        
        id = playerId;
        maxMana = maxManaPoints;
        maxLife = maxLifePoints;
        deckSize = maxDeckSize;
        handSize = maxHandSize;
        battleSize = maxBattleSize;
        
        r = rule;
        
        d = new deck (id, deckSize, r);
        h = new hand (handSize);
        b = new battleField (battleSize);
        
        
        life = maxLife;
        mana = startManaPoints;
    }
    
    void takeDamage (int demage) {
        life = life - demage;
    }
    
    boolean isDead () {
        boolean out = false;
        if (life <= 0) {
            out = true;
        }
        return out;
    }
    
    void gainMana (int amountMana) {
        mana = mana + amountMana;
        if (mana > maxMana) {
            mana = maxMana;
        }
    }
    
    void loseMana (int amountMana) {
        mana = mana - amountMana;
        if (mana > maxMana) {
            mana = maxMana;
        } else if (mana < 0) {
            mana = 0;
        }
    }
    
    int getLife () {
        return life;
    }
    
    int getMana () {
        return mana;
    }
    
    void setLife (int x) {
        life = x;
    }
    
    public static void main (String [] args) {
        
    }
    
}















