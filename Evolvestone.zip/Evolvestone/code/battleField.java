class battleField {
    int cardsInBattle;
    int battleSize;
    card cards [];
    
    public battleField (int maxBattleSize) {
        cardsInBattle = 0;
        battleSize = maxBattleSize;
        cards = new card [battleSize + 1];
    }
    
    boolean isFull () {
        boolean out = true;
        if (cardsInBattle < battleSize) {
            out = false;
        }
        return out;
    }
    
    int getNumberOfCardsInBattle () {
        return cardsInBattle;
    }
    
    int getNumberOfBattlefieldSpotsLeft () {
        return (battleSize - cardsInBattle);
    }
    
    boolean addCard (card x) {
        boolean out = false;
        if (cardsInBattle < battleSize) {
            out = true;
            cards [cardsInBattle + 1] = x;
            cards [cardsInBattle + 1].setCanAttackFalse();
            cardsInBattle++;
        }
        return out;
    }
    
    card[] returnBattle () {
        return cards;
    }
    
    card returnCard (int cardId) {
        card out = null;
        if (cardId <= cardsInBattle && cardId > 0) {
            out = cards[cardId];
        }
        return out;
    }
    
    boolean removeCard (int cardId) {
        boolean out = false;
        if (cardId <= cardsInBattle && cardId > 0) {
            out = true;
            for (int i = cardId; i < cardsInBattle; i++){
                cards[i] = cards[i+1];
            }
            cardsInBattle--;
        }
        return out;
    }
    
    void setAllCanAttackTrue () {
        for (int i = 1; i <= cardsInBattle; i++) {
            cards[i].setCanAttackTrue();
        }
    }
    
    void printBattle () {
        for (int i = 1; i <= cardsInBattle; i++) {
            card x = cards[i];
            x.printCard();
        }
    }
    
    
    public static void main (String [] args) {

    }
    
}


























