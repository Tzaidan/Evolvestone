import java.io.*;

class gamePlay {
    player p1;
    player p2;
    
    rules rulesP1;
    rules rulesP2;
    
    int turn;
    
    int loseLifeOutOfCards1;
    int loseLifeOutOfCards2;
    
    
    int p1StartManaPoints;
    int p1MaxManaPoints;
    int p1ManaRate;
    int p1LifePoints;
    int p1MaxCardsInDeck;
    int p1MaxCardsInHand;
    int p1MaxCardsInBattlefield;
    int p1CardsDrawPerTurn;
    int p1CardsDrawInFirstTurn;
    
    
    int p2StartManaPoints;
    int p2MaxManaPoints;
    int p2ManaRate;
    int p2LifePoints;
    int p2MaxCardsInDeck;
    int p2MaxCardsInHand;
    int p2MaxCardsInBattlefield;
    int p2CardsDrawPerTurn;
    int p2CardsDrawInFirstTurn;
    
    
    int maxNumberOfTurns; // 0 for infinite turns
    int player2ExtraManaPointsInOneRound;
    int player2ExtraCardsInFirstDraw;
    int numberOfSimulations;
    
    
    int p1NumberOfSubsets;
    int [] p1AttackTwicePerTurn;
    int [] p1AttackInSameRoundSummoned;
    int [] p1EnemyMustTargetThisCard;
    int [] p1CardsWillOnlyLast_X_Rounds;
    int [] p1CardsCannotBeTarget;
    
    
    int p2NumberOfSubsets;
    int [] p2AttackTwicePerTurn;
    int [] p2AttackInSameRoundSummoned;
    int [] p2EnemyMustTargetThisCard;
    int [] p2CardsWillOnlyLast_X_Rounds;
    int [] p2CardsCannotBeTarget;
    
    
    
    public gamePlay (int gameId) {
        rulesP1 = new rules();
        rulesP2 = new rules();
        
        
        /*
        rulesP1.readRulesFile(1);
        
        if (rulesP1.getPlayer2RulesEqualsPlayer1() == 1) {
            rulesP2.readRulesFile(1);
        } else {
            rulesP2.readRulesFile(2);
        }
        */
        
        
        //para gerar os resultados de forma automatica
        rulesP1.readRulesFileAutomatic(1,gameId);
        
        //if (rulesP1.getPlayer2RulesEqualsPlayer1() == 1) {
            rulesP2.readRulesFileAutomatic(1,gameId);
        //} else {
            //rulesP2.readRulesFileAutomatic(2,gameId);
        //}
        
        
        //maneira antiga de gerar deck. Dessa maneira e gerado em arquvio
        //generateCards generate = new generateCards();
        //generate.generate(rulesP1,rulesP2);
        
        p1StartManaPoints = rulesP1.getStartManaPoints();
        p1MaxManaPoints = rulesP1.getMaxManaPoints();
        p1ManaRate = rulesP1.getManaRate();
        p1LifePoints = rulesP1.getLifePoints();
        p1MaxCardsInDeck = rulesP1.getMaxCardsInDeck();
        p1MaxCardsInHand = rulesP1.getMaxCardsInHand();
        p1MaxCardsInBattlefield = rulesP1.getMaxCardsInBattlefield();
        p1CardsDrawPerTurn = rulesP1.getCardsDrawPerTurn();
        p1CardsDrawInFirstTurn = rulesP1.getCardsDrawInFirstTurn();
        
        
        p2StartManaPoints = rulesP2.getStartManaPoints();
        p2MaxManaPoints = rulesP2.getMaxManaPoints();
        p2ManaRate = rulesP2.getManaRate();
        p2LifePoints = rulesP2.getLifePoints();
        p2MaxCardsInDeck = rulesP2.getMaxCardsInDeck();
        p2MaxCardsInHand = rulesP2.getMaxCardsInHand();
        p2MaxCardsInBattlefield = rulesP2.getMaxCardsInBattlefield();
        p2CardsDrawPerTurn = rulesP2.getCardsDrawPerTurn();
        p2CardsDrawInFirstTurn = rulesP2.getCardsDrawInFirstTurn();
        
        
        maxNumberOfTurns = rulesP1.getMaxTurns();
        player2ExtraManaPointsInOneRound = rulesP1.getPlayer2ExtraManaPoints();
        player2ExtraCardsInFirstDraw = rulesP1.getPlayer2ExtraCardsInFirstDraw();
        numberOfSimulations = rulesP1.getNumberOfSimulations();
        
        
        p1NumberOfSubsets = rulesP1.getNumberOfMonstersSubsets();
        p1AttackTwicePerTurn = new int [p1NumberOfSubsets];
        p1AttackInSameRoundSummoned = new int [p1NumberOfSubsets];
        p1EnemyMustTargetThisCard = new int [p1NumberOfSubsets];
        p1CardsWillOnlyLast_X_Rounds = new int [p1NumberOfSubsets];
        p1CardsCannotBeTarget = new int [p1NumberOfSubsets];
        p1AttackTwicePerTurn = rulesP1.getAttackTwicePerTurnRule();
        p1AttackInSameRoundSummoned = rulesP1.getAttackInTheSameTurnItWasSummonedRule();
        p1EnemyMustTargetThisCard = rulesP1.getMustTargetThisCardRule();
        p1CardsWillOnlyLast_X_Rounds = rulesP1.getNumberOfRoundsThisCardWillLastRule();
        p1CardsCannotBeTarget = rulesP1.getCannotBeTargetRule ();
        
        
        p2NumberOfSubsets = rulesP2.getNumberOfMonstersSubsets();
        p2AttackTwicePerTurn = new int [p2NumberOfSubsets];
        p2AttackInSameRoundSummoned = new int [p2NumberOfSubsets];
        p2EnemyMustTargetThisCard = new int [p2NumberOfSubsets];
        p2CardsWillOnlyLast_X_Rounds = new int [p2NumberOfSubsets];
        p2CardsCannotBeTarget = new int [p2NumberOfSubsets];
        p2AttackTwicePerTurn = rulesP2.getAttackTwicePerTurnRule();
        p2AttackInSameRoundSummoned = rulesP2.getAttackInTheSameTurnItWasSummonedRule();
        p2EnemyMustTargetThisCard = rulesP2.getMustTargetThisCardRule();
        p2CardsWillOnlyLast_X_Rounds = rulesP2.getNumberOfRoundsThisCardWillLastRule();
        p2CardsCannotBeTarget = rulesP2.getCannotBeTargetRule ();
        
        
        
        p1 = new player (1, p1MaxManaPoints, p1StartManaPoints, p1LifePoints, p1MaxCardsInDeck, p1MaxCardsInHand, p1MaxCardsInBattlefield, rulesP1);
        p1.d.getDeck();
        p1.d.shuffle();
        
        
        p2 = new player (2, p2MaxManaPoints, p2StartManaPoints, p2LifePoints, p2MaxCardsInDeck, p2MaxCardsInHand, p2MaxCardsInBattlefield, rulesP2);
        p2.d.getDeck();
        p2.d.shuffle();
        
        
        turn = 1;
        
        loseLifeOutOfCards1 = 1;
        loseLifeOutOfCards2 = 1;
        
    }
    
    // constructor for evolucionary
    public gamePlay (String [] list2) {
        
        rulesP1 = new rules();
        rulesP2 = new rules();
        
        rulesP1.readRulesForEvolucionary(1,list2);
        //rulesP2.readRulesForEvolucionary(2,list2); //regras diferentes para p1 e p2
        
        rulesP2.readRulesForEvolucionary(1,list2); //regras iguais para p1 e p2
        
        //maneira antiga de gerar deck. Dessa maneira e gerado em arquvio
        //generateCards generate = new generateCards();
        //generate.generate(rulesP1,rulesP2);
        
        p1StartManaPoints = rulesP1.getStartManaPoints();
        p1MaxManaPoints = rulesP1.getMaxManaPoints();
        p1ManaRate = rulesP1.getManaRate();
        p1LifePoints = rulesP1.getLifePoints();
        p1MaxCardsInDeck = rulesP1.getMaxCardsInDeck();
        p1MaxCardsInHand = rulesP1.getMaxCardsInHand();
        p1MaxCardsInBattlefield = rulesP1.getMaxCardsInBattlefield();
        p1CardsDrawPerTurn = rulesP1.getCardsDrawPerTurn();
        p1CardsDrawInFirstTurn = rulesP1.getCardsDrawInFirstTurn();
        
        
        p2StartManaPoints = rulesP2.getStartManaPoints();
        p2MaxManaPoints = rulesP2.getMaxManaPoints();
        p2ManaRate = rulesP2.getManaRate();
        p2LifePoints = rulesP2.getLifePoints();
        p2MaxCardsInDeck = rulesP2.getMaxCardsInDeck();
        p2MaxCardsInHand = rulesP2.getMaxCardsInHand();
        p2MaxCardsInBattlefield = rulesP2.getMaxCardsInBattlefield();
        p2CardsDrawPerTurn = rulesP2.getCardsDrawPerTurn();
        p2CardsDrawInFirstTurn = rulesP2.getCardsDrawInFirstTurn();
        
        
        maxNumberOfTurns = rulesP1.getMaxTurns();
        player2ExtraManaPointsInOneRound = rulesP1.getPlayer2ExtraManaPoints();
        player2ExtraCardsInFirstDraw = rulesP1.getPlayer2ExtraCardsInFirstDraw();
        numberOfSimulations = rulesP1.getNumberOfSimulations();
        
        
        p1NumberOfSubsets = rulesP1.getNumberOfMonstersSubsets();
        p1AttackTwicePerTurn = new int [p1NumberOfSubsets];
        p1AttackInSameRoundSummoned = new int [p1NumberOfSubsets];
        p1EnemyMustTargetThisCard = new int [p1NumberOfSubsets];
        p1CardsWillOnlyLast_X_Rounds = new int [p1NumberOfSubsets];
        p1CardsCannotBeTarget = new int [p1NumberOfSubsets];
        p1AttackTwicePerTurn = rulesP1.getAttackTwicePerTurnRule();
        p1AttackInSameRoundSummoned = rulesP1.getAttackInTheSameTurnItWasSummonedRule();
        p1EnemyMustTargetThisCard = rulesP1.getMustTargetThisCardRule();
        p1CardsWillOnlyLast_X_Rounds = rulesP1.getNumberOfRoundsThisCardWillLastRule();
        p1CardsCannotBeTarget = rulesP1.getCannotBeTargetRule ();
        
        
        p2NumberOfSubsets = rulesP2.getNumberOfMonstersSubsets();
        p2AttackTwicePerTurn = new int [p2NumberOfSubsets];
        p2AttackInSameRoundSummoned = new int [p2NumberOfSubsets];
        p2EnemyMustTargetThisCard = new int [p2NumberOfSubsets];
        p2CardsWillOnlyLast_X_Rounds = new int [p2NumberOfSubsets];
        p2CardsCannotBeTarget = new int [p2NumberOfSubsets];
        p2AttackTwicePerTurn = rulesP2.getAttackTwicePerTurnRule();
        p2AttackInSameRoundSummoned = rulesP2.getAttackInTheSameTurnItWasSummonedRule();
        p2EnemyMustTargetThisCard = rulesP2.getMustTargetThisCardRule();
        p2CardsWillOnlyLast_X_Rounds = rulesP2.getNumberOfRoundsThisCardWillLastRule();
        p2CardsCannotBeTarget = rulesP2.getCannotBeTargetRule ();
        
        
        
        p1 = new player (1, p1MaxManaPoints, p1StartManaPoints, p1LifePoints, p1MaxCardsInDeck, p1MaxCardsInHand, p1MaxCardsInBattlefield, rulesP1);
        p1.d.getDeck();
        p1.d.shuffle();
        
        
        p2 = new player (2, p2MaxManaPoints, p2StartManaPoints, p2LifePoints, p2MaxCardsInDeck, p2MaxCardsInHand, p2MaxCardsInBattlefield, rulesP2);
        p2.d.getDeck();
        p2.d.shuffle();
        
        
        turn = 1;
        
        loseLifeOutOfCards1 = 1;
        loseLifeOutOfCards2 = 1;
        
    }
    
    void firstTurn (int id) {
        if (id == 1) {
            turn++;
            
            for (int i = 0; i < p1CardsDrawInFirstTurn; i++) {
                card c = p1.d.getNextCard();
                p1.h.addCard(c);
            }
            
            p1.gainMana (p1ManaRate);
            
            playCardsP1 ();
            
            attackOffensiveP1 ();
            
            p1.b.setAllCanAttackTrue();
            
            decreaseAllRemainingRoundsP1();
            
            killCardsWithNoRemainingRoudsP1 ();
            
        } else {
            turn++;
            
            for (int i = 0; i < (p2CardsDrawInFirstTurn + player2ExtraCardsInFirstDraw); i++) {
                card c = p2.d.getNextCard();
                p2.h.addCard(c);
            }
            
            p2.gainMana (p2ManaRate);
            
            if (player2ExtraManaPointsInOneRound > 0) {
                int manaLeft =  playCardsP2 ();
                int mp = player2UseExtraManaPoints (manaLeft);
                if (mp > 0) {
                    playCardsP2WithExtraMana (manaLeft+mp);
                }
            } else {
                playCardsP2();
            }
            
            attackOffensiveP2 ();
            
            p2.b.setAllCanAttackTrue();
            
            decreaseAllRemainingRoundsP2();
            
            killCardsWithNoRemainingRoudsP2 ();
            
        }
    }
    
    void turn (int id) {
        if (id == 1) {
            turn++;
            
            card c1 = p1.d.getNextCard ();
            if (c1 == null) {
                p1.takeDamage(loseLifeOutOfCards1);
                loseLifeOutOfCards1++;
            } else {
                p1.h.addCard(c1);
            }
            
            p1.gainMana (p1ManaRate);
            
            playCardsP1 ();
            
            attackOffensiveP1 ();
            
            p1.b.setAllCanAttackTrue();
            
            decreaseAllRemainingRoundsP1();
            
            killCardsWithNoRemainingRoudsP1 ();
            
        } else {
            turn++;
            
            card c2 = p2.d.getNextCard ();
            if (c2 == null) {
                p2.takeDamage(loseLifeOutOfCards2);
                loseLifeOutOfCards2++;
            } else {
                p2.h.addCard(c2);
            }
            
            p2.gainMana (p2ManaRate);
            
            if (player2ExtraManaPointsInOneRound > 0) {
                int manaLeft =  playCardsP2 ();
                int mp = player2UseExtraManaPoints (manaLeft);
                if (mp > 0) {
                    playCardsP2WithExtraMana (manaLeft+mp);
                }
            } else {
                playCardsP2();
            }
            
            attackOffensiveP2 ();
            
            p2.b.setAllCanAttackTrue();
            
            decreaseAllRemainingRoundsP2();
            
            killCardsWithNoRemainingRoudsP2 ();
        }
    }
    
    //return 1 if player 1 wins, and return 2 if player 2 wins
    int play () {
        int whoWon = 0;

        firstTurn(1);
        firstTurn(2);
        
        while (!(p1.isDead()) && !(p2.isDead())) {
            int playerTurn = turn % 2;
            if (playerTurn == 1) {
                turn(1);
            } else {
                turn(2);
            }
            if (maxNumberOfTurns != 0 && turn >= maxNumberOfTurns) {
                if (p1.getLife() >= p2.getLife()) {
                    p2.setLife (0);
                } else {
                    p1.setLife(0);
                }
            }
        }
        
        if (p1.isDead()){
            whoWon = 2;
        } else if (p2.isDead()){
            whoWon = 1;
        }
        
        return whoWon;
    }
    
    void firstTurnWithLog (int id) {
        if (id == 1) {
            printTurn(1);
            turn++;
            
            for (int i = 0; i < p1CardsDrawInFirstTurn; i++) {
                card c = p1.d.getNextCard();
                p1.h.addCard(c);
            }
            
            printHand(1);
            
            p1.gainMana (p1ManaRate);
            
            printMana (1);
            
            playCardsP1 ();
            
            printBattlefield (1);
            
            printBattlefield (2);
            
            printAttack (1);
            
            attackOffensiveP1 ();
            
            printBattlefield (1);
            
            printBattlefield (2);
            
            printHand (1);
            
            printHealth (1);
            
            printHealth (2);
            
            p1.b.setAllCanAttackTrue();
            
            decreaseAllRemainingRoundsP1();
            
            killCardsWithNoRemainingRoudsP1 ();
            
        } else {
            printTurn(2);
            turn++;
            
            for (int i = 0; i < (p2CardsDrawInFirstTurn + player2ExtraCardsInFirstDraw); i++) {
                card c = p2.d.getNextCard();
                p2.h.addCard(c);
            }
            
            printHand(2);
            
            p2.gainMana (p2ManaRate);
            
            printMana (2);
            
            if (player2ExtraManaPointsInOneRound > 0) {
                int manaLeft =  playCardsP2 ();
                int mp = player2UseExtraManaPoints (manaLeft);
                if (mp > 0) {
                    playCardsP2WithExtraMana (manaLeft+mp);
                    printP2IsUsingExtraManaPoint();
                }
            } else {
                playCardsP2();
            }
            
            printBattlefield (2);
            
            printBattlefield (1);
            
            printAttack (2);
            
            attackOffensiveP2 ();
            
            printBattlefield (2);
            
            printBattlefield (1);
            
            printHand (2);
            
            printHealth (2);
            
            printHealth (1);
            
            p2.b.setAllCanAttackTrue();
            
            decreaseAllRemainingRoundsP2();
            
            killCardsWithNoRemainingRoudsP2 ();
            
        }
    }
    
    void turnWithLog (int id) {
        if (id == 1) {
            printTurn (1);
            turn++;
            
            card c1 = p1.d.getNextCard ();
            if (c1 == null) {
                printOutOfCards(1);
                p1.takeDamage(loseLifeOutOfCards1);
                loseLifeOutOfCards1++;
                printHealth(1);
            } else {
                p1.h.addCard(c1);
            }
            
            printHand (1);
            
            p1.gainMana (p1ManaRate);
            
            printMana (1);
            
            playCardsP1 ();
            
            printBattlefield (1);
            
            printBattlefield (2);
            
            printAttack (1);
            
            attackOffensiveP1 ();
            
            printBattlefield (1);
            
            printBattlefield (2);
            
            printHand (1);
            
            printHealth (1);
            
            printHealth (2);
            
            p1.b.setAllCanAttackTrue();
            
            decreaseAllRemainingRoundsP1();
            
            killCardsWithNoRemainingRoudsP1 ();
            
        } else {
            printTurn (2);
            turn++;
            
            card c2 = p2.d.getNextCard ();
            if (c2 == null) {
                printOutOfCards(2);
                p2.takeDamage(loseLifeOutOfCards2);
                loseLifeOutOfCards2++;
                printHealth(2);
            } else {
                p2.h.addCard(c2);
            }
            
            printHand (2);
            
            p2.gainMana (p2ManaRate);
            
            printMana (2);
            
            if (player2ExtraManaPointsInOneRound > 0) {
                int manaLeft =  playCardsP2 ();
                int mp = player2UseExtraManaPoints (manaLeft);
                if (mp > 0) {
                    playCardsP2WithExtraMana (manaLeft+mp);
                    printP2IsUsingExtraManaPoint();
                }
            } else {
                playCardsP2();
            }
            
            printBattlefield (2);
            
            printBattlefield (1);
            
            printAttack (2);
            
            attackOffensiveP2 ();
            
            printBattlefield (2);
            
            printBattlefield (1);
            
            printHand (2);
            
            printHealth (2);
            
            printHealth (1);
            
            p2.b.setAllCanAttackTrue();
            
            decreaseAllRemainingRoundsP2();
            
            killCardsWithNoRemainingRoudsP2 ();
        }
    }
    
    //return 1 if player 1 wins, and return 2 if player 2 wins
    int playWithLog () {
        int whoWon = 0;
        
        printDeck(1);
        printDeck(2);
        
        firstTurnWithLog(1);
        firstTurnWithLog(2);
        
        while (!(p1.isDead()) && !(p2.isDead())) {
            int playerTurn = turn % 2;
            if (playerTurn == 1) {
                turnWithLog(1);
            } else {
                turnWithLog(2);
            }
            if (maxNumberOfTurns != 0 && turn >= maxNumberOfTurns) {
                if (p1.getLife() >= p2.getLife()) {
                    printNumberOfTurnLimit();
                    p2.setLife (0);
                } else {
                    printNumberOfTurnLimit();
                    p1.setLife(0);
                }
            }
        }
        
        if (p1.isDead()){
            printDead(1);
            printVictory(2);
            whoWon = 2;
        } else if (p2.isDead()){
            printDead(2);
            printVictory(1);
            whoWon = 1;
        }
        
        return whoWon;
    }
    
    
    //-----------------------P1 Functions-----------------------
    
    void playCardsP1 () {
        double maxValue = 0;
        int maxValueId = 0;
        int mana = p1.getMana();
        
        for (int j = 0; j < p1.b.getNumberOfBattlefieldSpotsLeft(); j++) {
            for (int i = 1; i <= p1.h.getNumberOfCardsInHand(); i++) {
                if ((getCardValueP1(p1.h.returnCard(i)) > maxValue) && (p1.h.returnCard(i).getMana() <= mana)) {
                    maxValue = getCardValueP1(p1.h.returnCard(i));
                    maxValueId = i;
                }
            }
            if (maxValue != 0) {
                p1.b.addCard (p1.h.returnCard(maxValueId));
                mana = mana - p1.h.returnCard(maxValueId).getMana();
                
                int subset = p1.h.returnCard(maxValueId).getSubset();
                if (p1AttackInSameRoundSummoned[subset] == 1) {
                    p1.h.returnCard(maxValueId).setCanAttackTrue();
                }
                if (p1CardsWillOnlyLast_X_Rounds[subset] >= 1) {
                    p1.h.returnCard(maxValueId).setRemainingRounds(p1CardsWillOnlyLast_X_Rounds[subset]);
                }
                
                p1.h.removeCard(maxValueId);
                maxValue = 0;
                maxValueId = 0;
            }
        }
    }
    
    double getCardValueP1 (card c) {
        double value;
        value = ((c.getAttack() + c.getHealth()) / c.getMana());
        int numberOfSubsets = 0;
        int subset = c.getSubset ();
        
        if (p1AttackTwicePerTurn[subset] == 1) {
            numberOfSubsets++;
        }
        if (p1AttackInSameRoundSummoned[subset] == 1) {
            numberOfSubsets++;
        }
        if (p1EnemyMustTargetThisCard[subset] == 1) {
            numberOfSubsets++;
        }
        if (p1CardsWillOnlyLast_X_Rounds[subset] >= 1) {
            numberOfSubsets++;
        }
        if (p1CardsCannotBeTarget[subset] == 1) {
            numberOfSubsets++;
        }
        
        value = value + numberOfSubsets;
        
        return value;
    }
    
    void decreaseAllRemainingRoundsP1 () {
        for (int i = 1; i <= p1.b.getNumberOfCardsInBattle(); i++) {
            int subset = p1.b.returnCard(i).getSubset();
            if (p1CardsWillOnlyLast_X_Rounds[subset] >= 1) {
                p1.b.returnCard(i).decreaseRemainingRounds();
            }
        }
    }
    
    
    void killCardsWithNoRemainingRoudsP1 () {
        for (int i = 1; i <= p1.b.getNumberOfCardsInBattle(); i++) {
            int subset = p1.b.returnCard(i).getSubset();
            if (p1CardsWillOnlyLast_X_Rounds[subset] >= 1) {
                int x = p1.b.returnCard(i).getRemainingRounds();
                if (x <= 0) {
                    p1.b.removeCard(i);
                }
            }
        }
    }
    
    
    void attackOffensiveP1 () {
        int id = -1;
        card y = null;
        card c = null;
        boolean hasMustAttackCards = false;
        for (int i = 1; i<= p1.b.getNumberOfCardsInBattle(); i++) {
            c = p1.b.returnCard (i);
            if (c.getCanAttack() == true) {
                hasMustAttackCards = p2BattlefieldHasMustAttackCards();
                if (hasMustAttackCards == true ) {
                    if (p1AttackTwicePerTurn[c.getSubset()] == 1) {
                        id = getP2IdOfMustAttackCardWithLowestHealth();
                        y = p2.b.returnCard(id);
                        y.takeDamage(c.getAttack());
                        c.takeDamage(y.getAttack());
                        if (c.isDead() == true) {
                            p1.b.removeCard(i);
                            if (y.isDead() == true) {
                                p2.b.removeCard(id);
                            }
                        } else {
                            if (y.isDead() == true) {
                                p2.b.removeCard(id);
                                hasMustAttackCards = p2BattlefieldHasMustAttackCards();
                                if (hasMustAttackCards == true) {
                                    id = getP2IdOfMustAttackCardWithLowestHealth();
                                    y = p2.b.returnCard(id);
                                    y.takeDamage(c.getAttack());
                                    c.takeDamage(y.getAttack());
                                    if (y.isDead() == true) {
                                        p2.b.removeCard(id);
                                    }
                                    if (c.isDead() == true) {
                                        p1.b.removeCard(i);
                                    }
                                } else {
                                    p2.takeDamage(c.getAttack());
                                }
                            } else {
                                y.takeDamage(c.getAttack());
                                c.takeDamage(y.getAttack());
                                if (y.isDead() == true) {
                                    p2.b.removeCard(id);
                                }
                                if (c.isDead() == true) {
                                    p1.b.removeCard(i);
                                }
                            }
                        }
                    } else {
                        id = getP2IdOfMustAttackCardWithLowestHealth();
                        y = p2.b.returnCard(id);
                        y.takeDamage(c.getAttack());
                        c.takeDamage(y.getAttack());
                        if (y.isDead() == true) {
                            p2.b.removeCard(id);
                        }
                        if (c.isDead() == true) {
                            p1.b.removeCard(i);
                        }
                    }
                } else {
                    if (p1AttackTwicePerTurn[c.getSubset()] == 1) {
                        p2.takeDamage((2*(c.getAttack())));
                    } else {
                        p2.takeDamage(c.getAttack());
                    }
                }
            }
        }
    }
    
    boolean p2BattlefieldHasMustAttackCards () {
        boolean x = false;
        for (int i = 1; i <= p2.b.getNumberOfCardsInBattle(); i++) {
            int subset = p2.b.returnCard(i).getSubset();
            if (p2EnemyMustTargetThisCard[subset] == 1) {
                x = true;
                i = p2.b.getNumberOfCardsInBattle();
            }
        }
        return x;
    }
    
    int getP2IdOfMustAttackCardWithLowestHealth () {
        int id = -1;
        int minHealth = 999999;
        int partialHealth = -1;
        for (int i = 1; i <= p2.b.getNumberOfCardsInBattle(); i++) {
            int subset = p2.b.returnCard(i).getSubset();
            if (p2EnemyMustTargetThisCard[subset] == 1) {
                partialHealth = p2.b.returnCard(i).getHealth();
                if (partialHealth < minHealth) {
                    minHealth = partialHealth;
                    id = i;
                }
            }
        }
        return id;
    }
    
    
    
    
    
    //-----------------------P2 Functions-----------------------
    
    
    int playCardsP2 () {
        double maxValue = 0;
        int maxValueId = 0;
        int manaLeft = p2.getMana();
        
        for (int j = 0; j < p2.b.getNumberOfBattlefieldSpotsLeft(); j++) {
            for (int i = 1; i <= p2.h.getNumberOfCardsInHand(); i++) {
                if ((getCardValueP2(p2.h.returnCard(i)) > maxValue) && (p2.h.returnCard(i).getMana() <= manaLeft)) {
                    maxValue = getCardValueP2(p2.h.returnCard(i));
                    maxValueId = i;
                }
            }
            if (maxValue != 0) {
                p2.b.addCard (p2.h.returnCard(maxValueId));
                manaLeft = manaLeft - p2.h.returnCard(maxValueId).getMana();
                
                int subset = p2.h.returnCard(maxValueId).getSubset();
                if (p2AttackInSameRoundSummoned[subset] == 1) {
                    p2.h.returnCard(maxValueId).setCanAttackTrue();
                }
                if (p2CardsWillOnlyLast_X_Rounds[subset] >= 1) {
                    p2.h.returnCard(maxValueId).setRemainingRounds(p2CardsWillOnlyLast_X_Rounds[subset]);
                }
                
                p2.h.removeCard(maxValueId);
                maxValue = 0;
                maxValueId = 0;
            }
        }
        return manaLeft;
    }
    
    void playCardsP2WithExtraMana (int mana) {
        double maxValue = 0;
        int maxValueId = 0;
        int manaLeft = mana;
        
        for (int j = 0; j < p2.b.getNumberOfBattlefieldSpotsLeft(); j++) {
            for (int i = 1; i <= p2.h.getNumberOfCardsInHand(); i++) {
                if ((getCardValueP2(p2.h.returnCard(i)) > maxValue) && (p2.h.returnCard(i).getMana() <= manaLeft)) {
                    maxValue = getCardValueP2(p2.h.returnCard(i));
                    maxValueId = i;
                }
            }
            if (maxValue != 0) {
                p2.b.addCard (p2.h.returnCard(maxValueId));
                manaLeft = manaLeft - p2.h.returnCard(maxValueId).getMana();
                
                int subset = p2.h.returnCard(maxValueId).getSubset();
                if (p2AttackInSameRoundSummoned[subset] == 1) {
                    p2.h.returnCard(maxValueId).setCanAttackTrue();
                }
                if (p2CardsWillOnlyLast_X_Rounds[subset] >= 1) {
                    p2.h.returnCard(maxValueId).setRemainingRounds(p2CardsWillOnlyLast_X_Rounds[subset]);
                }
                
                p2.h.removeCard(maxValueId);
                maxValue = 0;
                maxValueId = 0;
            }
        }
    }
    
    double getCardValueP2 (card c) {
        double value;
        value = ((c.getAttack() + c.getHealth()) / c.getMana());
        int numberOfSubsets = 0;
        int subset = c.getSubset ();
        
        if (p2AttackTwicePerTurn[subset] == 1) {
            numberOfSubsets++;
        }
        if (p2AttackInSameRoundSummoned[subset] == 1) {
            numberOfSubsets++;
        }
        if (p2EnemyMustTargetThisCard[subset] == 1) {
            numberOfSubsets++;
        }
        if (p2CardsWillOnlyLast_X_Rounds[subset] >= 1) {
            numberOfSubsets++;
        }
        if (p2CardsCannotBeTarget[subset] == 1) {
            numberOfSubsets++;
        }
        
        value = value + numberOfSubsets;
        
        return value;
    }
    
    void decreaseAllRemainingRoundsP2 () {
        for (int i = 1; i <= p2.b.getNumberOfCardsInBattle(); i++) {
            int subset = p2.b.returnCard(i).getSubset();
            if (p2CardsWillOnlyLast_X_Rounds[subset] >= 1) {
                p2.b.returnCard(i).decreaseRemainingRounds();
            }
        }
    }
    
    
    void killCardsWithNoRemainingRoudsP2 () {
        for (int i = 1; i <= p2.b.getNumberOfCardsInBattle(); i++) {
            int subset = p2.b.returnCard(i).getSubset();
            if (p2CardsWillOnlyLast_X_Rounds[subset] >= 1) {
                int x = p2.b.returnCard(i).getRemainingRounds();
                if (x <= 0) {
                    p2.b.removeCard(i);
                }
            }
        }
    }
    
    
    void attackOffensiveP2 () {
        int id = -1;
        card y = null;
        card c = null;
        boolean hasMustAttackCards = false;
        for (int i = 1; i<= p2.b.getNumberOfCardsInBattle(); i++) {
            c = p2.b.returnCard (i);
            if (c.getCanAttack() == true) {
                hasMustAttackCards = p1BattlefieldHasMustAttackCards();
                if (hasMustAttackCards == true ) {
                    if (p2AttackTwicePerTurn[c.getSubset()] == 1) {
                        id = getP1IdOfMustAttackCardWithLowestHealth();
                        y = p1.b.returnCard(id);
                        y.takeDamage(c.getAttack());
                        c.takeDamage(y.getAttack());
                        if (c.isDead() == true) {
                            p2.b.removeCard(i);
                            if (y.isDead() == true) {
                                p1.b.removeCard(id);
                            }
                        } else {
                            if (y.isDead() == true) {
                                p1.b.removeCard(id);
                                hasMustAttackCards = p1BattlefieldHasMustAttackCards();
                                if (hasMustAttackCards == true) {
                                    id = getP1IdOfMustAttackCardWithLowestHealth();
                                    y = p1.b.returnCard(id);
                                    y.takeDamage(c.getAttack());
                                    c.takeDamage(y.getAttack());
                                    if (y.isDead() == true) {
                                        p1.b.removeCard(id);
                                    }
                                    if (c.isDead() == true) {
                                        p2.b.removeCard(i);
                                    }
                                } else {
                                    p1.takeDamage(c.getAttack());
                                }
                            } else {
                                y.takeDamage(c.getAttack());
                                c.takeDamage(y.getAttack());
                                if (y.isDead() == true) {
                                    p1.b.removeCard(id);
                                }
                                if (c.isDead() == true) {
                                    p2.b.removeCard(i);
                                }
                            }
                        }
                    } else {
                        id = getP1IdOfMustAttackCardWithLowestHealth();
                        y = p1.b.returnCard(id);
                        y.takeDamage(c.getAttack());
                        c.takeDamage(y.getAttack());
                        if (y.isDead() == true) {
                            p1.b.removeCard(id);
                        }
                        if (c.isDead() == true) {
                            p2.b.removeCard(i);
                        }
                    }
                } else {
                    if (p2AttackTwicePerTurn[c.getSubset()] == 1) {
                        p1.takeDamage((2*(c.getAttack())));
                    } else {
                        p1.takeDamage(c.getAttack());
                    }
                }
            }
        }
    }
    
    boolean p1BattlefieldHasMustAttackCards () {
        boolean x = false;
        for (int i = 1; i <= p1.b.getNumberOfCardsInBattle(); i++) {
            int subset = p1.b.returnCard(i).getSubset();
            if (p1EnemyMustTargetThisCard[subset] == 1) {
                x = true;
                i = p1.b.getNumberOfCardsInBattle();
            }
        }
        return x;
    }
    
    int getP1IdOfMustAttackCardWithLowestHealth () {
        int id = -1;
        int minHealth = 999999;
        int partialHealth = -1;
        for (int i = 1; i <= p1.b.getNumberOfCardsInBattle(); i++) {
            int subset = p1.b.returnCard(i).getSubset();
            if (p1EnemyMustTargetThisCard[subset] == 1) {
                partialHealth = p1.b.returnCard(i).getHealth();
                if (partialHealth < minHealth) {
                    minHealth = partialHealth;
                    id = i;
                }
            }
        }
        return id;
    }
    
    
    
    
    
    
    int getP2CostOfLowestCardInHand () {
        int minValue = 999999;
        int returnValue = -1;
        for (int i = 1; i <= p2.h.getNumberOfCardsInHand(); i++) {
            int minCardValue = p2.h.returnCard(i).getMana();
            if (minCardValue <= minValue) {
                minValue = minCardValue;
                returnValue = minCardValue;
            }
        }
        return returnValue;
    }
    
    int player2UseExtraManaPoints (int manaLeft) { // return the extra mana points to be used
        int extraManaPoints = 0;
        int lowestCost = getP2CostOfLowestCardInHand();
        if (lowestCost != -1) {
            if ((player2ExtraManaPointsInOneRound + manaLeft) >= lowestCost) {
                extraManaPoints = player2ExtraManaPointsInOneRound;
                player2ExtraManaPointsInOneRound = 0;
            }
        }
        return extraManaPoints;
    }
    
    rules getPlayer1RulesObject () {
        return rulesP1;
    }
    
    rules getPLayer2RulesObject () {
        return rulesP2;
    }
    
    void printDeck (int id) {
        if (id == 1) {
            System.out.println ("------------------------------------------------------PLAYER 1 DECK------------------------------------------------------");
            p1.d.printDeck();
            System.out.println ("-------------------------------------------------------------- ----------------------------------------------------------");
        } else {
            System.out.println ("------------------------------------------------------PLAYER 2 DECK------------------------------------------------------");
            p2.d.printDeck();
            System.out.println ("-------------------------------------------------------------- ----------------------------------------------------------");
        }
    }
    
    void printHand (int id) {
        if (id == 1) {
            System.out.println ("------------------------------------------------------PLAYER 1 HAND------------------------------------------------------");
            p1.h.printHand();
            System.out.println ("-------------------------------------------------------------- ----------------------------------------------------------");
        } else {
            System.out.println ("------------------------------------------------------PLAYER 2 HAND------------------------------------------------------");
            p2.h.printHand();
            System.out.println ("-------------------------------------------------------------- ----------------------------------------------------------");
        }
    }
    
    void printBattlefield (int id) {
        if (id == 1) {
            System.out.println ("------------------------------------------------------PLAYER 1 BATTLEFIELD------------------------------------------------------");
            p1.b.printBattle();
            System.out.println ("-------------------------------------------------------------- ----------------------------------------------------------");
        } else {
            System.out.println ("------------------------------------------------------PLAYER 2 BATTLEFIELD------------------------------------------------------");
            p2.b.printBattle();
            System.out.println ("-------------------------------------------------------------- ----------------------------------------------------------");
        }
    }
    
    void printAttack (int id) {
        if (id == 1) {
            System.out.println ("------------------------------------------------------PLAYER 1 IS ATTACKING------------------------------------------------------");
        } else {
            System.out.println ("------------------------------------------------------PLAYER 2 IS ATTACKING------------------------------------------------------");
        }
    }
    
    void printTurn (int id ) {
        if (id == 1) {
            System.out.println();
            System.out.println();
            System.out.println ("------------------------------------------------------PLAYER 1 TURN: "+turn+"------------------------------------------------------");
            System.out.println();
            System.out.println();
        } else {
            System.out.println();
            System.out.println();
            System.out.println ("------------------------------------------------------PLAYER 2 TURN: "+turn+"------------------------------------------------------");
            System.out.println();
            System.out.println();
        }
    }
    
    void printHealth (int id) {
        if (id == 1) {
            System.out.println ("------------------------------------------------------PLAYER 1 HEALTH: "+p1.getLife()+"------------------------------------------------------");
        } else {
            System.out.println ("------------------------------------------------------PLAYER 2 HEALTH: "+p2.getLife()+"------------------------------------------------------");
        }
    }
    
    void printMana (int id) {
        if (id == 1) {
            System.out.println ("------------------------------------------------------PLAYER 1 MANA: "+p1.getMana()+"------------------------------------------------------");
        } else {
            System.out.println ("------------------------------------------------------PLAYER 2 MANA: "+p2.getMana()+"------------------------------------------------------");
        }
    }
    
    void printOutOfCards (int id) {
        if (id == 1) {
            System.out.println ("------------------------------------------------------PLAYER 1 IS OUT OF CARDS------------------------------------------------------");
        } else {
            System.out.println ("------------------------------------------------------PLAYER 2 IS OUT OF CARDS------------------------------------------------------");
        }
    }
    
    void printP2IsUsingExtraManaPoint () {
        System.out.println ("------------------------------------------------------PLAYER 2 IS USING EXTRA MANA POINT------------------------------------------------------");
    }
    
    void printNumberOfTurnLimit () {
        System.out.println ("------------------------------------------------------GAME IS OVER BECAUSE THE NUMBER OF TURN LIMIT HAS BEEN REACHED ------------------------------------------------------");
    }
    
    void printDead (int id) {
        if (id == 1) {
            System.out.println ("------------------------------------------------------PLAYER 1 IS DEAD------------------------------------------------------");
        } else {
            System.out.println ("------------------------------------------------------PLAYER 2 IS DEAD------------------------------------------------------");
        }
    }
    
    void printVictory (int id) {
        if (id == 1) {
            System.out.println ("------------------------------------------------------PLAYER 1 WINS------------------------------------------------------");
        } else {
            System.out.println ("------------------------------------------------------PLAYER 2 WINS------------------------------------------------------");
        }
    }
    
    
    public static void main (String [] args) {
        int numberOfExecutions = 10;
        
        double metricBalance = 0;
        
        int [] player1WinsArray = new int [numberOfExecutions];
        int [] player2WinsArray = new int [numberOfExecutions];
        int [] avgNumberOfTurnsArray = new int [numberOfExecutions];
        int [] avgP1EndLifeArray = new int [numberOfExecutions];
        int [] avgP2EndLifeArray = new int [numberOfExecutions];
        
        for (int t = 1; t <= numberOfExecutions; t++) {
            int avgNumberOfTurns = 0;
            int avgP1EndLife = 0;
            int avgP2EndLife = 0;
            gamePlay gp = new gamePlay(t);
            int player1Wins = 0;
            int player2Wins = 0;
            for (int i = 0; i < gp.numberOfSimulations; i++) {
                gp = new gamePlay (t);
                int victory = gp.play();
                //int victory = gp.playWithLog();
                if (victory == 1) {
                    player1Wins++;
                    avgP1EndLife = avgP1EndLife + (gp.p1.getLife() * 100)/gp.p1LifePoints;
                } else if (victory == 2) {
                    player2Wins++;
                    avgP2EndLife = avgP2EndLife + (gp.p2.getLife() * 100)/gp.p2LifePoints;
                }
                avgNumberOfTurns = avgNumberOfTurns + gp.turn;
            }
        
            avgNumberOfTurns = avgNumberOfTurns / gp.numberOfSimulations;

        
            int p1WinsNormalized = player1Wins;
            int p2WinsNormalized = player2Wins;
        
            if (player1Wins == 0) {
                p1WinsNormalized = 1;
            }
            if (player2Wins == 0) {
                p2WinsNormalized = 1;
            }
        
            avgP1EndLife = avgP1EndLife / p1WinsNormalized;
            avgP2EndLife = avgP2EndLife / p2WinsNormalized;
        
            double vic = (double) player1Wins - (double) player2Wins;
            double out = Math.abs(vic);
            
            
            //double vic1 = ((double) player1Wins - (double) player2Wins);
            //double vic2 = ((double) avgNumberOfTurns - 12.0);
            //double out = Math.abs(vic1) + Math.abs(vic2);
            
            
            //double vic1 = ((double) player1Wins - (double) player2Wins);
            //double vic2 = ((double) avgNumberOfTurns - 12.0);
            //double vic3 = ((double) avgP1EndLife - 30.0);
            //double vic4 = ((double)avgP2EndLife - 30.0);
            //double out = Math.abs(vic1) + Math.abs(vic2) + Math.abs(vic3) + Math.abs(vic4);
            
            
            
            metricBalance = metricBalance + out;
            
        
            /**
             System.out.println("Player 1 won: "+player1Wins);
             System.out.println("Player 2 won: "+player2Wins);
             System.out.println("");
             System.out.println("Average number of turns: "+avgNumberOfTurns);
             System.out.println("");
             System.out.println("Average in % of player 1 end life when it wins: "+avgP1EndLife);
             System.out.println("Average in % of player 2 end life when it wins: "+avgP2EndLife);
        
             */
        
            
            
        
            //para gerar resultados no arquivo
            
            
            player1WinsArray [t-1] = player1Wins;
            player2WinsArray [t-1] = player2Wins;
            avgNumberOfTurnsArray [t-1] = avgNumberOfTurns;
            avgP1EndLifeArray [t-1] = avgP1EndLife;
            avgP2EndLifeArray [t-1] = avgP2EndLife;
            
            /*
            
            try {
                File file = new File ("../results/id"+(t)+"/resultados.txt");
                if (!file.exists ()) {
                    file.createNewFile ();
                }
                FileWriter fw = new FileWriter (file.getAbsoluteFile());
                BufferedWriter bw = new BufferedWriter (fw);
            
            
                bw.write(player1Wins+"\n");
                bw.write(player2Wins+"\n");
                bw.write(avgNumberOfTurns+"\n");
                bw.write(avgP1EndLife+"\n");
                bw.write(avgP2EndLife+"\n");
            
                bw.close();
            
            } catch (IOException e) {
                e.printStackTrace();
            }
             */
            
        
        }
        
        /*
        try {
            File file = new File ("../resultsGraphics/resultados1.txt");
            if (!file.exists ()) {
                file.createNewFile ();
            }
            FileWriter fw = new FileWriter (file.getAbsoluteFile());
            BufferedWriter bw = new BufferedWriter (fw);
            
            bw.write("player1Wins\n");
            for (int i = 0; i < numberOfExecutions; i++) {
                bw.write(player1WinsArray[i]+"\n");
            }
            bw.write("\n");
            bw.write("player2Wins\n");
            for (int i = 0; i < numberOfExecutions; i++) {
                bw.write(player2WinsArray[i]+"\n");
            }
            bw.write("\n");
            bw.write("avgNumberOfTurns\n");
            for (int i = 0; i < numberOfExecutions; i++) {
                bw.write(avgNumberOfTurnsArray[i]+"\n");
            }
            bw.write("\n");
            bw.write("avgP1EndLife\n");
            for (int i = 0; i < numberOfExecutions; i++) {
                bw.write(avgP1EndLifeArray[i]+"\n");
            }
            bw.write("\n");
            bw.write("avgP2EndLife\n");
            for (int i = 0; i < numberOfExecutions; i++) {
                bw.write(avgP2EndLifeArray[i]+"\n");
            }
            
            bw.close();
            
        } catch (IOException e) {
            e.printStackTrace();
        }
        */
        
        metricBalance = metricBalance/10;
        
        System.out.println(metricBalance);
        
    }
    
    
}
















