import java.io.*;

class readCards {
    
    card deckP1[];
    card deckP2[];
    int size1;
    int size2;
    
    int playerId;
    
    public readCards (int size, int pId) {
        if (pId == 1) {
            playerId = pId;
            size1 = size;
            deckP1 = new card [size1];
            readP1();
        } else if (pId == 2) {
            playerId = pId;
            size2 = size;
            deckP2 = new card [size2];
            readP2();
        }
        
    }
    
    card returnPlayerCard (int cardId) {
        card returnCard = null;
        if (playerId == 1) {
            returnCard = deckP1 [cardId];
        } else if (playerId == 2) {
            returnCard = deckP2 [cardId];
        }
        return returnCard;
    }
    
    
    
    void readP1 ( ) {
        
        for (int i = 0; i < size1; i++) {
            try (BufferedReader br = new BufferedReader(new FileReader("../cards/Player1/card"+i+".txt"))) {
                
                String line;
                int count = 0;
                
                while ((line = br.readLine()) != null) {
                    String [] split = line.split (" ");
                    
                    if (count % 5 == 0) {
                        deckP1[i] = new card();
                        deckP1[i].setName (line);
                    } else if (count % 5 == 1) {
                        int in = Integer.parseInt(split[1]);
                        deckP1[i].setSubset(in);
                    } else if (count % 5 == 2) {
                        int in = Integer.parseInt(split[1]);
                        deckP1[i].setAttack(in);
                    } else if (count % 5 == 3) {
                        int in = Integer.parseInt(split[1]);
                        deckP1[i].setHealth(in);
                    } else if (count % 5 == 4) {
                        int in = Integer.parseInt(split[1]);
                        deckP1[i].setMana(in);
                        
                        //System.out.println("Counter "+i);
                        //deckP1[i].printCard();
                    }
                    count++;
                }
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }
    
    void readP2 ( ) {
        
        for (int i = 0; i < size2; i++) {
            try (BufferedReader br = new BufferedReader(new FileReader("../cards/Player2/card"+i+".txt"))) {
                
                String line;
                int count = 0;
                
                while ((line = br.readLine()) != null) {
                    String [] split = line.split (" ");
                    
                    if (count % 5 == 0) {
                        deckP2[i] = new card();
                        deckP2[i].setName (line);
                    } else if (count % 5 == 1) {
                        int in = Integer.parseInt(split[1]);
                        deckP2[i].setSubset(in);
                    } else if (count % 5 == 2) {
                        int in = Integer.parseInt(split[1]);
                        deckP2[i].setAttack(in);
                    } else if (count % 5 == 3) {
                        int in = Integer.parseInt(split[1]);
                        deckP2[i].setHealth(in);
                    } else if (count % 5 == 4) {
                        int in = Integer.parseInt(split[1]);
                        deckP2[i].setMana(in);
                        
                        //System.out.println("Counter "+i);
                        //deckP2[i].printCard();
                    }
                    count++;
                }
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }
    
    public static void main (String [] args) {
        //readCards r = new readCards (35,35);
        //r.readP1();
        //System.out.println ("---------------------------");
        //r.readP2();
    }
    
}