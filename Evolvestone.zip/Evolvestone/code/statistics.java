import java.io.*;
import java.lang.Math;
import java.util.Arrays;

class statistics {
    int [] []  rules;
    public statistics () {
        rules = new int [17][10];
        for (int j = 0; j < 10; j++) {
            try (BufferedReader br = new BufferedReader(new FileReader("../results/id"+(j+21)+"/SimplifiedRulesP1.txt"))) {
                String line;
                int cont = 0;
                for (int i = 0; i < 27; i++) {
                    if (i == 0 || i == 9|| i == 12|| i == 13|| i == 14|| i == 15|| i == 17|| i == 18|| i == 19|| i == 21) {
                        line = br.readLine();
                    }
                    else {
                        line = br.readLine();
                        rules [cont][j] = Integer.parseInt(line);
                        cont ++;
                    }
                }
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }
    
    public void variancia(int id) {
        
        double p1 = 1 / Double.valueOf(rules[id].length - 1);
        
        double p2 = getSomaDosElementosAoQuadrado(id)
        
        - (Math.pow(getSomaDosElementos(id), 2) / Double
           
           .valueOf(rules[id].length));
        
        System.out.println( ((p1 * p2)/9) * 100);
        
    }
    
    public double getSomaDosElementosAoQuadrado(int id) {
        
        double total = 0;
        
        for (int counter = 0; counter < rules[id].length; counter++)
            
            total += Math.pow(rules[id][counter], 2);
        
        return total;
        
    }
    
    public double getSomaDosElementos(int id) {
        
        double total = 0;
        
        for (int counter = 0; counter < rules[id].length; counter++)
            
            total += rules[id][counter];
        
        return total;
        
    }
    
    public void r1 (int id) {
        Arrays.sort(rules[id]);
        int min = rules[id][0];
        int max = rules[id][9];
        
        int dif = max - min;
        System.out.println ((dif/9.0)*100);
        //System.out.println(rules[id][4]);
    }
    public void r2 (int id) {
        Arrays.sort(rules[id]);
        int min = rules[id][0];
        int max = rules[id][9];
        
        int dif = max - min;
        System.out.println ((dif/2.0)*100);
        //System.out.println(rules[id][4]);
    }
    public void r3 (int id) {
        Arrays.sort(rules[id]);
        int min = rules[id][0];
        int max = rules[id][9];
        
        int dif = max - min;
        System.out.println ((dif/36.0)*100);
        //System.out.println(rules[id][4]);
    }
    public void r4 (int id) {
        Arrays.sort(rules[id]);
        int min = rules[id][0];
        int max = rules[id][9];
        
        int dif = max - min;
        System.out.println ((dif/27.0)*100);
        //System.out.println(rules[id][4]);
    }
    public void r5 (int id) {
        Arrays.sort(rules[id]);
        int min = rules[id][0];
        int max = rules[id][9];
        
        int dif = max - min;
        System.out.println ((dif/9.0)*100);
        //System.out.println(rules[id][4]);
    }
    public void r6 (int id) {
        Arrays.sort(rules[id]);
        int min = rules[id][0];
        int max = rules[id][9];
        
        int dif = max - min;
        System.out.println ((dif/9.0)*100);
        //System.out.println(rules[id][4]);
    }
    public void r7 (int id) {
        Arrays.sort(rules[id]);
        int min = rules[id][0];
        int max = rules[id][9];
        
        int dif = max - min;
        System.out.println ((dif/2.0)*100);
        //System.out.println(rules[id][4]);
    }
    public void r8 (int id) {
        Arrays.sort(rules[id]);
        int min = rules[id][0];
        int max = rules[id][9];
        
        int dif = max - min;
        System.out.println ((dif/9.0)*100);
        //System.out.println(rules[id][4]);
    }
    public void r9 (int id) {
        Arrays.sort(rules[id]);
        int min = rules[id][0];
        int max = rules[id][9];
        
        int dif = max - min;
        System.out.println ((dif/9.0)*100);
        //System.out.println(rules[id][4]);
    }
    public void r10 (int id) {
        Arrays.sort(rules[id]);
        int min = rules[id][0];
        int max = rules[id][9];
        
        int dif = max - min;
        System.out.println ((dif/4.0)*100);
        //System.out.println(rules[id][4]);
    }
    public void r11 (int id) {
        Arrays.sort(rules[id]);
        int min = rules[id][0];
        int max = rules[id][9];
        
        int dif = max - min;
        System.out.println ((dif/18.0)*100);
        //System.out.println(rules[id][4]);
    }
    public void r12 (int id) {
        Arrays.sort(rules[id]);
        int min = rules[id][0];
        int max = rules[id][9];
        
        int dif = max - min;
        System.out.println ((dif/18.0)*100);
        //System.out.println(rules[id][4]);
    }
    public void r13 (int id) {
        Arrays.sort(rules[id]);
        int min = rules[id][0];
        int max = rules[id][9];
        
        int dif = max - min;
        System.out.println ((dif/1.0)*100);
        //System.out.println(rules[id][4]);
    }
    public void r14 (int id) {
        Arrays.sort(rules[id]);
        int min = rules[id][0];
        int max = rules[id][9];
        
        int dif = max - min;
        System.out.println ((dif/1.0)*100);
        //System.out.println(rules[id][4]);
    }
    public void r15 (int id) {
        Arrays.sort(rules[id]);
        int min = rules[id][0];
        int max = rules[id][9];
        
        int dif = max - min;
        System.out.println ((dif/1.0)*100);
        //System.out.println(rules[id][4]);
    }
    public void r16 (int id) {
        Arrays.sort(rules[id]);
        int min = rules[id][0];
        int max = rules[id][9];
        
        int dif = max - min;
        System.out.println ((dif/4.0)*100);
        //System.out.println(rules[id][4]);
    }
    public void r17 (int id) {
        Arrays.sort(rules[id]);
        int min = rules[id][0];
        int max = rules[id][9];
        
        int dif = max - min;
        System.out.println ((dif/1.0)*100);
        //System.out.println(rules[id][4]);
    }

    public void print (int id) {
        for (int i = 0; i < 10; i++) {
            System.out.println(rules[id][i]);
        }
    }
    
    public static void main (String [] args) {
        statistics s = new statistics();
        //s.print(15);
        
        s.r1(0);
        s.r2(1);
        s.r3(2);
        s.r4(3);
        s.r5(4);
        s.r6(5);
        s.r7(6);
        s.r8(7);
        s.r9(8);
        s.r10(9);
        s.r11(10);
        s.r12(11);
        s.r13(12);
        s.r14(13);
        s.r15(14);
        s.r16(15);
        s.r17(16);
         
    }
}