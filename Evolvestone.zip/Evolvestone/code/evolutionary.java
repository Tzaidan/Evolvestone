import java.lang.Math;
import java.util.ArrayList;
import java.util.List;
import org.uncommons.maths.random.MersenneTwisterRNG;
import org.uncommons.maths.random.Probability;
import org.uncommons.watchmaker.framework.EvolutionEngine;
import org.uncommons.watchmaker.framework.EvolutionObserver;
import org.uncommons.watchmaker.framework.EvolutionaryOperator;
import org.uncommons.watchmaker.framework.GenerationalEvolutionEngine;
import org.uncommons.watchmaker.framework.PopulationData;
import org.uncommons.watchmaker.framework.factories.StringFactory;
import org.uncommons.watchmaker.framework.operators.EvolutionPipeline;
import org.uncommons.watchmaker.framework.operators.StringCrossover;
import org.uncommons.watchmaker.framework.operators.StringMutation;
import org.uncommons.watchmaker.framework.selection.RouletteWheelSelection;
import org.uncommons.watchmaker.framework.termination.TargetFitness;
import org.uncommons.watchmaker.framework.FitnessEvaluator;
import org.uncommons.watchmaker.framework.CandidateFactory;
import org.uncommons.watchmaker.framework.EvolutionaryOperator;
import org.uncommons.watchmaker.framework.operators.EvolutionPipeline;
import java.util.Random;
import org.uncommons.watchmaker.framework.operators.StringCrossover;
import org.uncommons.watchmaker.framework.operators.StringMutation;
import org.uncommons.watchmaker.framework.SelectionStrategy;
import java.util.LinkedList;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Callable;
import java.util.concurrent.CopyOnWriteArraySet;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.io.*;






class StringEvaluator implements FitnessEvaluator<String>


{
    public double getFitness(String candidate,
                             List<? extends String> population)
    {
        
        String [] list = new String [candidate.length()];
        
        for (int i = 0; i < candidate.length(); i++) {
            char  chars = candidate.charAt(i);
            list [i] = chars+"";
        }
        
        double evaluation = evaluate (list);
        
        return evaluation;
    }
    
    public double evaluate (String [] list) {
        String [] list2 = new String [list.length];
        
        
        //max mana
        int r0 = Integer.parseInt(list[0]);
        //int r17 = Integer.parseInt(list[17]);
        r0 = r0 + 5;
        //r17 = r17+ 5;
        list2[0] = Integer.toString(r0);
        //list2[17] = Integer.toString(r17);
        
        //mana rate
        int r1 = Integer.parseInt(list[1]);
        //int r18 = Integer.parseInt(list[18]);
        if (r1 <= 3) {
            list2[1] = "1";
        } else if (r1 <= 6) {
            list2[1] = "2";
        } else {
            list2[1] = "3";
        }
        /*
        if (r18 <= 3) {
            list2[18] = "1";
        } else if (r18 <= 6) {
            list2[18] = "2";
        } else {
            list2[18] = "3";
        }
        */
         
        //life points
        int r2 = Integer.parseInt(list[2]);
        //int r19 = Integer.parseInt(list[19]);
        r2 = (r2 + 4) * 4;
        //r19 = (r19+ 4) * 4;
        list2[2] = Integer.toString(r2);
        //list2[19] = Integer.toString(r19);
        
        //max cards deck
        int r3 = Integer.parseInt(list[3]);
        //int r20 = Integer.parseInt(list[20]);
        r3 = (r3 + 6) * 3;
        //r20 = (r20 + 6) * 3;
        list2[3] = Integer.toString(r3);
        //list2[20] = Integer.toString(r20);
        
        //max cards hand
        int r4 = Integer.parseInt(list[4]);
        //int r21 = Integer.parseInt(list[21]);
        r4 = r4 + 5;
        //r21 = r21 + 5;
        list2[4] = Integer.toString(r4);
        //list2[21] = Integer.toString(r21);
        
        //max cards battlefield
        int r5 = Integer.parseInt(list[5]);
        //int r22 = Integer.parseInt(list[22]);
        r5 = r5 + 5;
        //r22 = r22 + 5;
        list2[5] = Integer.toString(r5);
        //list2[22] = Integer.toString(r22);
        
        //card draw per turn
        int r6 = Integer.parseInt(list[6]);
        //int r23 = Integer.parseInt(list[23]);
        if (r6 <= 3) {
            list2[6] = "1";
        } else if (r6 <= 6) {
            list2[6] = "2";
        } else {
            list2[6] = "3";
        }
        /*
        if (r23 <= 3) {
            list2[23] = "1";
        } else if (r23 <= 6) {
            list2[23] = "2";
        } else {
            list2[23] = "3";
        }
        */
        
        //number of cards first draw
        int r7 = Integer.parseInt(list[7]);
        //int r24 = Integer.parseInt(list[24]);
        r7 = r7 + 3;
        //r24 = r24 + 3;
        list2[7] = Integer.toString(r7);
        //list2[24] = Integer.toString(r24);
        
        //p2 extra mana in one round
        list2[8] = list[8];
        //list2[25] = list[25];
        
        //p2 extra card draw in first turn
        int r9 = Integer.parseInt(list[9]);
        //int r26 = Integer.parseInt(list[26]);
        if (r9 <= 1) {
            list2[9] = "0";
        } else if (r9 <= 3 ) {
            list2[9] = "1";
        } else if (r9 <= 5) {
            list2[9] = "2";
        } else if (r9 <= 7) {
            list2[9] = "3";
        } else {
            list2[9] = "4";
        }
        /*
        if (r26 <= 1) {
            list2[26] = "0";
        } else if (r26 <= 3 ) {
            list2[26] = "1";
        } else if (r26 <= 5) {
            list2[26] = "2";
        } else if (r26 <= 7) {
            list2[26] = "3";
        } else {
            list2[26] = "4";
        }
        */
        
        //max monster damage
        int r10 = Integer.parseInt(list[10]);
        //int r27 = Integer.parseInt(list[27]);
        r10 = (r10 + 2) * 2;
        //r27 = (r27 + 2) * 2;
        list2[10] = Integer.toString(r10);
        //list2[27] = Integer.toString(r27);
        
        //max monster health
        int r11 = Integer.parseInt(list[11]);
        //int r28 = Integer.parseInt(list[28]);
        r11 = (r11 + 2) * 2;
        //r28 = (r28 + 2) * 2;
        list2[11] = Integer.toString(r11);
        //list2[28] = Integer.toString(r28);
        
        //attack twice per turn
        int r12 = Integer.parseInt(list[12]);
        //int r29 = Integer.parseInt(list[29]);
        if (r12 <= 4) {
            list2[12] = "0";
        } else {
            list2[12] = "1";
        }
        /*
        if (r29 <= 4) {
            list2[29] = "0";
        } else {
            list2[29] = "1";
        }
        */
        //attack in the same turn it was summoned
        int r13 = Integer.parseInt(list[13]);
        //int r30 = Integer.parseInt(list[30]);
        if (r13 <= 4) {
            list2[13] = "0";
        } else {
            list2[13] = "1";
        }
        /*
        if (r30 <= 4) {
            list2[30] = "0";
        } else {
            list2[30] = "1";
        }
        */
        
        //must target this card
        int r14 = Integer.parseInt(list[14]);
        //int r31 = Integer.parseInt(list[31]);
        if (r14 <= 4) {
            list2[14] = "0";
        } else {
            list2[14] = "1";
        }
        /*
        if (r31 <= 4) {
            list2[31] = "0";
        } else {
            list2[31] = "1";
        }
        */
        
        /* teste
        //will last X round
        int r15 = Integer.parseInt(list[15]);
        //int r32 = Integer.parseInt(list[32]);
        if (r15 <= 1) {
            list2[15] = "0";
        } else if (r15 <= 3 ) {
            list2[15] = "1";
        } else if (r15 <= 5) {
            list2[15] = "2";
        } else if (r15 <= 7) {
            list2[15] = "3";
        } else {
            list2[15] = "4";
        }
         */
        /*
        if (r32 <= 1) {
            list2[32] = "0";
        } else if (r32 <= 3 ) {
            list2[32] = "1";
        } else if (r32 <= 5) {
            list2[32] = "2";
        } else if (r32 <= 7) {
            list2[32] = "3";
        } else {
            list2[32] = "4";
        }
        */
        
        //cannot target
        int r16 = Integer.parseInt(list[15]);
        //int r33 = Integer.parseInt(list[33]);
        if (r16 <= 4) {
            list2[15] = "0";
        } else {
            list2[15] = "1";
        }
        /*
        if (r33 <= 4) {
            list2[33] = "0";
        } else {
            list2[33] = "1";
        }
        */
        
        
        gamePlay gp = new gamePlay (list2);
        
        int avgNumberOfTurns = 0;
        int avgP1EndLife = 0;
        int avgP2EndLife = 0;
        int player1Wins = 0;
        int player2Wins = 0;
        for (int i = 0; i < gp.numberOfSimulations; i++) {
            gp = new gamePlay (list2);
            int victory = gp.play();
            //int victory = gp.playWithLog();
            if (victory == 1) {
                player1Wins++;
                avgP1EndLife = avgP1EndLife + (gp.p1.getLife() * 100)/gp.p1LifePoints;
            } else if (victory == 2) {
                player2Wins++;
                avgP2EndLife = avgP2EndLife + (gp.p2.getLife() * 100)/gp.p2LifePoints;
            }
            avgNumberOfTurns = avgNumberOfTurns + gp.turn;
        }
        avgNumberOfTurns = avgNumberOfTurns / gp.numberOfSimulations;
        
        int p1WinsNormalized = player1Wins;
        int p2WinsNormalized = player2Wins;
        
        if (player1Wins == 0) {
            p1WinsNormalized = 1;
        }
        if (player2Wins == 0) {
            p2WinsNormalized = 1;
        }
        
        avgP1EndLife = avgP1EndLife / p1WinsNormalized;
        avgP2EndLife = avgP2EndLife / p2WinsNormalized;

        
        double vic = (double) player1Wins - (double) player2Wins;
        double out = Math.abs(vic);
        
        
        //double vic1 = ((double) player1Wins - (double) player2Wins);
        //double vic2 = ((double) avgNumberOfTurns - 12.0);
        //double out = Math.abs(vic1) + Math.abs(vic2);
        
        
        //double vic1 = ((double) player1Wins - (double) player2Wins);
        //double vic2 = ((double) avgNumberOfTurns - 12.0);
        //double vic3 = ((double) avgP1EndLife - 30.0);
        //double vic4 = ((double)avgP2EndLife - 30.0);
        //double out = Math.abs(vic1) + Math.abs(vic2) + Math.abs(vic3) + Math.abs(vic4);
        
        
        return out;
    }
    
    
    //return false if smaller fitness are the best
    //return true if bigger fitness are the best
    public boolean isNatural()
    {
        return false;
    }
}






class evolutionary {
    public evolutionary () {
        
    }
    
    public static String format (String [] list) {
        String [] list2 = new String [list.length];
        
        
        //max mana
        int r0 = Integer.parseInt(list[0]);
        //int r17 = Integer.parseInt(list[17]);
        r0 = r0 + 5;
        //r17 = r17+ 5;
        list2[0] = Integer.toString(r0);
        //list2[17] = Integer.toString(r17);
        
        //mana rate
        int r1 = Integer.parseInt(list[1]);
        //int r18 = Integer.parseInt(list[18]);
        if (r1 <= 3) {
            list2[1] = "1";
        } else if (r1 <= 6) {
            list2[1] = "2";
        } else {
            list2[1] = "3";
        }
        /*
        if (r18 <= 3) {
            list2[18] = "1";
        } else if (r18 <= 6) {
            list2[18] = "2";
        } else {
            list2[18] = "3";
        }
        */
        
        //life points
        int r2 = Integer.parseInt(list[2]);
        //int r19 = Integer.parseInt(list[19]);
        r2 = (r2 + 4) * 4;
        //r19 = (r19+ 4) * 4;
        list2[2] = Integer.toString(r2);
        //list2[19] = Integer.toString(r19);
        
        //max cards deck
        int r3 = Integer.parseInt(list[3]);
        //int r20 = Integer.parseInt(list[20]);
        r3 = (r3 + 6) * 3;
        //r20 = (r20 + 6) * 3;
        list2[3] = Integer.toString(r3);
        //list2[20] = Integer.toString(r20);
        
        //max cards hand
        int r4 = Integer.parseInt(list[4]);
        //int r21 = Integer.parseInt(list[21]);
        r4 = r4 + 5;
        //r21 = r21 + 5;
        list2[4] = Integer.toString(r4);
        //list2[21] = Integer.toString(r21);
        
        //max cards battlefield
        int r5 = Integer.parseInt(list[5]);
        //int r22 = Integer.parseInt(list[22]);
        r5 = r5 + 5;
        //r22 = r22 + 5;
        list2[5] = Integer.toString(r5);
        //list2[22] = Integer.toString(r22);
        
        //card draw per turn
        int r6 = Integer.parseInt(list[6]);
        //int r23 = Integer.parseInt(list[23]);
        if (r6 <= 3) {
            list2[6] = "1";
        } else if (r6 <= 6) {
            list2[6] = "2";
        } else {
            list2[6] = "3";
        }
        /*
        if (r23 <= 3) {
            list2[23] = "1";
        } else if (r23 <= 6) {
            list2[23] = "2";
        } else {
            list2[23] = "3";
        }
        */
        
        //number of cards first draw
        int r7 = Integer.parseInt(list[7]);
        //int r24 = Integer.parseInt(list[24]);
        r7 = r7 + 3;
        //r24 = r24 + 3;
        list2[7] = Integer.toString(r7);
        //list2[24] = Integer.toString(r24);
        
        //p2 extra mana in one round
        list2[8] = list[8];
        //list2[25] = list[25];
        
        //p2 extra card draw in first turn
        int r9 = Integer.parseInt(list[9]);
        //int r26 = Integer.parseInt(list[26]);
        if (r9 <= 1) {
            list2[9] = "0";
        } else if (r9 <= 3 ) {
            list2[9] = "1";
        } else if (r9 <= 5) {
            list2[9] = "2";
        } else if (r9 <= 7) {
            list2[9] = "3";
        } else {
            list2[9] = "4";
        }
        /*
        if (r26 <= 1) {
            list2[26] = "0";
        } else if (r26 <= 3 ) {
            list2[26] = "1";
        } else if (r26 <= 5) {
            list2[26] = "2";
        } else if (r26 <= 7) {
            list2[26] = "3";
        } else {
            list2[26] = "4";
        }
        */
        
        //max monster damage
        int r10 = Integer.parseInt(list[10]);
        //int r27 = Integer.parseInt(list[27]);
        r10 = (r10 + 2) * 2;
        //r27 = (r27 + 2) * 2;
        list2[10] = Integer.toString(r10);
        //list2[27] = Integer.toString(r27);
        
        //max monster health
        int r11 = Integer.parseInt(list[11]);
        //int r28 = Integer.parseInt(list[28]);
        r11 = (r11 + 2) * 2;
        //r28 = (r28 + 2) * 2;
        list2[11] = Integer.toString(r11);
        //list2[28] = Integer.toString(r28);
        
        //attack twice per turn
        int r12 = Integer.parseInt(list[12]);
        //int r29 = Integer.parseInt(list[29]);
        if (r12 <= 4) {
            list2[12] = "0";
        } else {
            list2[12] = "1";
        }
        /*
        if (r29 <= 4) {
            list2[29] = "0";
        } else {
            list2[29] = "1";
        }
        */
        
        //attack in the same turn it was summoned
        int r13 = Integer.parseInt(list[13]);
        //int r30 = Integer.parseInt(list[30]);
        if (r13 <= 4) {
            list2[13] = "0";
        } else {
            list2[13] = "1";
        }
        /*
        if (r30 <= 4) {
            list2[30] = "0";
        } else {
            list2[30] = "1";
        }
        */
        
        //must target this card
        int r14 = Integer.parseInt(list[14]);
        //int r31 = Integer.parseInt(list[31]);
        if (r14 <= 4) {
            list2[14] = "0";
        } else {
            list2[14] = "1";
        }
        /*
        if (r31 <= 4) {
            list2[31] = "0";
        } else {
            list2[31] = "1";
        }
        */
        /* teste
        //will last X round
        int r15 = Integer.parseInt(list[15]);
        //int r32 = Integer.parseInt(list[32]);
        if (r15 <= 1) {
            list2[15] = "0";
        } else if (r15 <= 3 ) {
            list2[15] = "1";
        } else if (r15 <= 5) {
            list2[15] = "2";
        } else if (r15 <= 7) {
            list2[15] = "3";
        } else {
            list2[15] = "4";
        }
         */
        /*
        if (r32 <= 1) {
            list2[32] = "0";
        } else if (r32 <= 3 ) {
            list2[32] = "1";
        } else if (r32 <= 5) {
            list2[32] = "2";
        } else if (r32 <= 7) {
            list2[32] = "3";
        } else {
            list2[32] = "4";
        }
        */
        //cannot target
        int r16 = Integer.parseInt(list[15]);
        //int r33 = Integer.parseInt(list[33]);
        if (r16 <= 4) {
            list2[15] = "0";
        } else {
            list2[15] = "1";
        }
        /*
        if (r33 <= 4) {
            list2[33] = "0";
        } else {
            list2[33] = "1";
        }
        */
        
        String out = "";
        
        for (int j = 0; j < list2.length; j++) {
            out = out +""+list2[j]+" ";
        }
        
        return out;
    }
    
    public static String [] formatToFile (String [] list) {
        String [] list2 = new String [list.length];
        
        
        //max mana
        int r0 = Integer.parseInt(list[0]);
        //int r17 = Integer.parseInt(list[17]);
        r0 = r0 + 5;
        //r17 = r17+ 5;
        list2[0] = Integer.toString(r0);
        //list2[17] = Integer.toString(r17);
        
        //mana rate
        int r1 = Integer.parseInt(list[1]);
        //int r18 = Integer.parseInt(list[18]);
        if (r1 <= 3) {
            list2[1] = "1";
        } else if (r1 <= 6) {
            list2[1] = "2";
        } else {
            list2[1] = "3";
        }
        /*
         if (r18 <= 3) {
         list2[18] = "1";
         } else if (r18 <= 6) {
         list2[18] = "2";
         } else {
         list2[18] = "3";
         }
         */
        
        //life points
        int r2 = Integer.parseInt(list[2]);
        //int r19 = Integer.parseInt(list[19]);
        r2 = (r2 + 4) * 4;
        //r19 = (r19+ 4) * 4;
        list2[2] = Integer.toString(r2);
        //list2[19] = Integer.toString(r19);
        
        //max cards deck
        int r3 = Integer.parseInt(list[3]);
        //int r20 = Integer.parseInt(list[20]);
        r3 = (r3 + 6) * 3;
        //r20 = (r20 + 6) * 3;
        list2[3] = Integer.toString(r3);
        //list2[20] = Integer.toString(r20);
        
        //max cards hand
        int r4 = Integer.parseInt(list[4]);
        //int r21 = Integer.parseInt(list[21]);
        r4 = r4 + 5;
        //r21 = r21 + 5;
        list2[4] = Integer.toString(r4);
        //list2[21] = Integer.toString(r21);
        
        //max cards battlefield
        int r5 = Integer.parseInt(list[5]);
        //int r22 = Integer.parseInt(list[22]);
        r5 = r5 + 5;
        //r22 = r22 + 5;
        list2[5] = Integer.toString(r5);
        //list2[22] = Integer.toString(r22);
        
        //card draw per turn
        int r6 = Integer.parseInt(list[6]);
        //int r23 = Integer.parseInt(list[23]);
        if (r6 <= 3) {
            list2[6] = "1";
        } else if (r6 <= 6) {
            list2[6] = "2";
        } else {
            list2[6] = "3";
        }
        /*
         if (r23 <= 3) {
         list2[23] = "1";
         } else if (r23 <= 6) {
         list2[23] = "2";
         } else {
         list2[23] = "3";
         }
         */
        
        //number of cards first draw
        int r7 = Integer.parseInt(list[7]);
        //int r24 = Integer.parseInt(list[24]);
        r7 = r7 + 3;
        //r24 = r24 + 3;
        list2[7] = Integer.toString(r7);
        //list2[24] = Integer.toString(r24);
        
        //p2 extra mana in one round
        list2[8] = list[8];
        //list2[25] = list[25];
        
        //p2 extra card draw in first turn
        int r9 = Integer.parseInt(list[9]);
        //int r26 = Integer.parseInt(list[26]);
        if (r9 <= 1) {
            list2[9] = "0";
        } else if (r9 <= 3 ) {
            list2[9] = "1";
        } else if (r9 <= 5) {
            list2[9] = "2";
        } else if (r9 <= 7) {
            list2[9] = "3";
        } else {
            list2[9] = "4";
        }
        /*
         if (r26 <= 1) {
         list2[26] = "0";
         } else if (r26 <= 3 ) {
         list2[26] = "1";
         } else if (r26 <= 5) {
         list2[26] = "2";
         } else if (r26 <= 7) {
         list2[26] = "3";
         } else {
         list2[26] = "4";
         }
         */
        
        //max monster damage
        int r10 = Integer.parseInt(list[10]);
        //int r27 = Integer.parseInt(list[27]);
        r10 = (r10 + 2) * 2;
        //r27 = (r27 + 2) * 2;
        list2[10] = Integer.toString(r10);
        //list2[27] = Integer.toString(r27);
        
        //max monster health
        int r11 = Integer.parseInt(list[11]);
        //int r28 = Integer.parseInt(list[28]);
        r11 = (r11 + 2) * 2;
        //r28 = (r28 + 2) * 2;
        list2[11] = Integer.toString(r11);
        //list2[28] = Integer.toString(r28);
        
        //attack twice per turn
        int r12 = Integer.parseInt(list[12]);
        //int r29 = Integer.parseInt(list[29]);
        if (r12 <= 4) {
            list2[12] = "0";
        } else {
            list2[12] = "1";
        }
        /*
         if (r29 <= 4) {
         list2[29] = "0";
         } else {
         list2[29] = "1";
         }
         */
        
        //attack in the same turn it was summoned
        int r13 = Integer.parseInt(list[13]);
        //int r30 = Integer.parseInt(list[30]);
        if (r13 <= 4) {
            list2[13] = "0";
        } else {
            list2[13] = "1";
        }
        /*
         if (r30 <= 4) {
         list2[30] = "0";
         } else {
         list2[30] = "1";
         }
         */
        
        //must target this card
        int r14 = Integer.parseInt(list[14]);
        //int r31 = Integer.parseInt(list[31]);
        if (r14 <= 4) {
            list2[14] = "0";
        } else {
            list2[14] = "1";
        }
        /*
         if (r31 <= 4) {
         list2[31] = "0";
         } else {
         list2[31] = "1";
         }
         */
        
        /* teste
        //will last X round
        int r15 = Integer.parseInt(list[15]);
        //int r32 = Integer.parseInt(list[32]);
        if (r15 <= 1) {
            list2[15] = "0";
        } else if (r15 <= 3 ) {
            list2[15] = "1";
        } else if (r15 <= 5) {
            list2[15] = "2";
        } else if (r15 <= 7) {
            list2[15] = "3";
        } else {
            list2[15] = "4";
        }
         */
        /*
         if (r32 <= 1) {
         list2[32] = "0";
         } else if (r32 <= 3 ) {
         list2[32] = "1";
         } else if (r32 <= 5) {
         list2[32] = "2";
         } else if (r32 <= 7) {
         list2[32] = "3";
         } else {
         list2[32] = "4";
         }
         */
        //cannot target
        int r16 = Integer.parseInt(list[15]);
        //int r33 = Integer.parseInt(list[33]);
        if (r16 <= 4) {
            list2[15] = "0";
        } else {
            list2[15] = "1";
        }
        /*
         if (r33 <= 4) {
         list2[33] = "0";
         } else {
         list2[33] = "1";
         }
         */
        
        return list2;
    }
    
    public static void printResultToFile (String [] rule, int id) {
        try {
            File file = new File ("../results/id"+id+"/rulesP1.txt");
            if (!file.exists ()) {
                file.createNewFile ();
            }
            FileWriter fw = new FileWriter (file.getAbsoluteFile());
            BufferedWriter bw = new BufferedWriter (fw);
            
            
            bw.write("-> start mana points \n");
            bw.write("0\n");
            
            bw.write("-> max mana points \n");
            bw.write(Integer.parseInt(rule[0])+"\n");
            
            bw.write("-> mana rate \n");
            bw.write(Integer.parseInt(rule[1])+"\n");
            
            bw.write("-> life points \n");
            bw.write(Integer.parseInt(rule[2])+"\n");
            
            bw.write("-> max number of cards in the deck \n");
            bw.write(Integer.parseInt(rule[3])+"\n");
            
            bw.write("-> max number of cards in the hand \n");
            bw.write(Integer.parseInt(rule[4])+"\n");
            
            bw.write("-> max number of cards in the battlefield \n");
            bw.write(Integer.parseInt(rule[5])+"\n");
            
            bw.write("-> number of cards draw per turn \n");
            bw.write(Integer.parseInt(rule[6])+"\n");
            
            bw.write("-> number of cards in the first draw \n");
            bw.write(Integer.parseInt(rule[7])+"\n");
            
            bw.write("-> max number of turns (0 for infinite turns) \n");
            bw.write("0\n");
            
            bw.write("-> number of the player 2 extra mana points in one round \n");
            bw.write(Integer.parseInt(rule[8])+"\n");
            
            bw.write("-> number of the player 2 extra cards in the first draw \n");
            bw.write(Integer.parseInt(rule[9])+"\n");
            
            bw.write("-> player 2 rules are the same as player 1? (1 for true, 0 for false) \n");
            bw.write("0\n");
            
            bw.write("-> number of simulations \n");
            bw.write("1000\n");
            
            bw.write("-> number of subsets of monsters \n");
            bw.write("1\n");
            
            bw.write("-> % of monsters in each subset \n");
            bw.write("100\n");
            
            bw.write("-> max monster damage(one per subset, each one in separate lines) \n");
            bw.write(Integer.parseInt(rule[10])+"\n");
            
            bw.write("-> min monster damage \n");
            bw.write("1\n");
            
            bw.write("-> % of cards with attack greater than the max \n");
            bw.write("0\n");
            
            bw.write("-> max out of curve attack \n");
            bw.write("0\n");
            
            bw.write("-> max monster health \n");
            bw.write(Integer.parseInt(rule[11])+"\n");
            
            bw.write("-> min monster health \n");
            bw.write("1\n");
            
            bw.write("-> attack twice per turn (0 for subsets without this rule and 1 for subsets with this rule) \n");
            bw.write(Integer.parseInt(rule[12])+"\n");
            
            bw.write("-> attack in the same turn it was summoned (0 for subsets without this rule and 1 for subsets with this rule) \n");
            bw.write(Integer.parseInt(rule[13])+"\n");
            
            bw.write("-> enemy player must target cards with this rule (0 for subsets without this rule and 1 for subsets with this rule) \n");
            bw.write(Integer.parseInt(rule[14])+"\n");
            
            bw.write("-> cards with this rule will only last X rounds (0 for subsets without this rule and X for the subsets with this rule. X represents the number of rounds) \n");
            bw.write("0\n");//teste
            
            bw.write("-> cards with this rule cannot be target (0 for subsets without this rule and 1 for subsets with this rule) \n");
            bw.write(Integer.parseInt(rule[15])+"\n");
            
            bw.write("-> mana formula \n");
            bw.write("(a+h)/2\n");
            
            
            bw.close();
            
        } catch (IOException e) {
            e.printStackTrace();
        }
        /*
        try {
            File file2 = new File ("../results/id"+id+"/rulesP2.txt");
            if (!file2.exists ()) {
                file2.createNewFile ();
            }
            FileWriter fw2 = new FileWriter (file2.getAbsoluteFile());
            BufferedWriter bw2 = new BufferedWriter (fw2);
            
            
            bw2.write("-> start mana points \n");
            bw2.write("0\n");
            
            bw2.write("-> max mana points \n");
            bw2.write(Integer.parseInt(rule[17])+"\n");
            
            bw2.write("-> mana rate \n");
            bw2.write(Integer.parseInt(rule[18])+"\n");
            
            bw2.write("-> life points \n");
            bw2.write(Integer.parseInt(rule[19])+"\n");
            
            bw2.write("-> max number of cards in the deck \n");
            bw2.write(Integer.parseInt(rule[20])+"\n");
            
            bw2.write("-> max number of cards in the hand \n");
            bw2.write(Integer.parseInt(rule[21])+"\n");
            
            bw2.write("-> max number of cards in the battlefield \n");
            bw2.write(Integer.parseInt(rule[22])+"\n");
            
            bw2.write("-> number of cards draw per turn \n");
            bw2.write(Integer.parseInt(rule[23])+"\n");
            
            bw2.write("-> number of cards in the first draw \n");
            bw2.write(Integer.parseInt(rule[24])+"\n");
            
            bw2.write("-> max number of turns (0 for infinite turns) \n");
            bw2.write("0\n");
            
            bw2.write("-> number of the player 2 extra mana points in one round \n");
            bw2.write(Integer.parseInt(rule[25])+"\n");
            
            bw2.write("-> number of the player 2 extra cards in the first draw \n");
            bw2.write(Integer.parseInt(rule[26])+"\n");
            
            bw2.write("-> player 2 rules are the same as player 1? (1 for true, 0 for false) \n");
            bw2.write("0\n");
            
            bw2.write("-> number of simulations \n");
            bw2.write("1000\n");
            
            bw2.write("-> number of subsets of monsters \n");
            bw2.write("1\n");
            
            bw2.write("-> % of monsters in each subset \n");
            bw2.write("100\n");
            
            bw2.write("-> max monster damage(one per subset, each one in separate lines) \n");
            bw2.write(Integer.parseInt(rule[27])+"\n");
            
            bw2.write("-> min monster damage \n");
            bw2.write("1\n");
            
            bw2.write("-> % of cards with attack greater than the max \n");
            bw2.write("0\n");
            
            bw2.write("-> max out of curve attack \n");
            bw2.write("0\n");
            
            bw2.write("-> max monster health \n");
            bw2.write(Integer.parseInt(rule[28])+"\n");
            
            bw2.write("-> min monster health \n");
            bw2.write("1\n");
            
            bw2.write("-> attack twice per turn (0 for subsets without this rule and 1 for subsets with this rule) \n");
            bw2.write(Integer.parseInt(rule[29])+"\n");
            
            bw2.write("-> attack in the same turn it was summoned (0 for subsets without this rule and 1 for subsets with this rule) \n");
            bw2.write(Integer.parseInt(rule[30])+"\n");
            
            bw2.write("-> enemy player must target cards with this rule (0 for subsets without this rule and 1 for subsets with this rule) \n");
            bw2.write(Integer.parseInt(rule[31])+"\n");
            
            bw2.write("-> cards with this rule will only last X rounds (0 for subsets without this rule and X for the subsets with this rule. X represents the number of rounds) \n");
            bw2.write(Integer.parseInt(rule[32])+"\n");
            
            bw2.write("-> cards with this rule cannot be target (0 for subsets without this rule and 1 for subsets with this rule) \n");
            bw2.write(Integer.parseInt(rule[33])+"\n");
            
            bw2.write("-> mana formula \n");
            bw2.write("(a+h)/2\n");
            
            
            bw2.close();
            
        } catch (IOException e) {
            e.printStackTrace();
        }
         */
        /*
        try {
            File file = new File ("../results/id"+id+"/rulesP2.txt");
            if (!file.exists ()) {
                file.createNewFile ();
            }
            FileWriter fw = new FileWriter (file.getAbsoluteFile());
            BufferedWriter bw = new BufferedWriter (fw);
            
            
            bw.write("-> start mana points \n");
            bw.write("0\n");
            
            bw.write("-> max mana points \n");
            bw.write(Integer.parseInt(rule[0])+"\n");
            
            bw.write("-> mana rate \n");
            bw.write(Integer.parseInt(rule[1])+"\n");
            
            bw.write("-> life points \n");
            bw.write(Integer.parseInt(rule[2])+"\n");
            
            bw.write("-> max number of cards in the deck \n");
            bw.write(Integer.parseInt(rule[3])+"\n");
            
            bw.write("-> max number of cards in the hand \n");
            bw.write(Integer.parseInt(rule[4])+"\n");
            
            bw.write("-> max number of cards in the battlefield \n");
            bw.write(Integer.parseInt(rule[5])+"\n");
            
            bw.write("-> number of cards draw per turn \n");
            bw.write(Integer.parseInt(rule[6])+"\n");
            
            bw.write("-> number of cards in the first draw \n");
            bw.write(Integer.parseInt(rule[7])+"\n");
            
            bw.write("-> max number of turns (0 for infinite turns) \n");
            bw.write("0\n");
            
            bw.write("-> number of the player 2 extra mana points in one round \n");
            bw.write(Integer.parseInt(rule[8])+"\n");
            
            bw.write("-> number of the player 2 extra cards in the first draw \n");
            bw.write(Integer.parseInt(rule[9])+"\n");
            
            bw.write("-> player 2 rules are the same as player 1? (1 for true, 0 for false) \n");
            bw.write("0\n");
            
            bw.write("-> number of simulations \n");
            bw.write("1000\n");
            
            bw.write("-> number of subsets of monsters \n");
            bw.write("1\n");
            
            bw.write("-> % of monsters in each subset \n");
            bw.write("100\n");
            
            bw.write("-> max monster damage(one per subset, each one in separate lines) \n");
            bw.write(Integer.parseInt(rule[10])+"\n");
            
            bw.write("-> min monster damage \n");
            bw.write("1\n");
            
            bw.write("-> % of cards with attack greater than the max \n");
            bw.write("0\n");
            
            bw.write("-> max out of curve attack \n");
            bw.write("0\n");
            
            bw.write("-> max monster health \n");
            bw.write(Integer.parseInt(rule[11])+"\n");
            
            bw.write("-> min monster health \n");
            bw.write("1\n");
            
            bw.write("-> attack twice per turn (0 for subsets without this rule and 1 for subsets with this rule) \n");
            bw.write(Integer.parseInt(rule[12])+"\n");
            
            bw.write("-> attack in the same turn it was summoned (0 for subsets without this rule and 1 for subsets with this rule) \n");
            bw.write(Integer.parseInt(rule[13])+"\n");
            
            bw.write("-> enemy player must target cards with this rule (0 for subsets without this rule and 1 for subsets with this rule) \n");
            bw.write(Integer.parseInt(rule[14])+"\n");
            
            bw.write("-> cards with this rule will only last X rounds (0 for subsets without this rule and X for the subsets with this rule. X represents the number of rounds) \n");
            bw.write("0\n");//teste
            
            bw.write("-> cards with this rule cannot be target (0 for subsets without this rule and 1 for subsets with this rule) \n");
            bw.write(Integer.parseInt(rule[15])+"\n");
            
            bw.write("-> mana formula \n");
            bw.write("(a+h)/2\n");
            
            
            bw.close();
            
        } catch (IOException e) {
            e.printStackTrace();
        }
        */
    }
    
    public static void printResultToFile1Min(String [] rule, int id) {
        try {
            File file = new File ("../resultsEstatistica/id"+id+"/printResultToFile1Min.txt");
            if (!file.exists ()) {
                file.createNewFile ();
            }
            FileWriter fw = new FileWriter (file.getAbsoluteFile());
            BufferedWriter bw = new BufferedWriter (fw);
            
            
            bw.write("-> start mana points \n");
            bw.write("0\n");
            
            bw.write("-> max mana points \n");
            bw.write("5\n");
            
            bw.write("-> mana rate \n");
            bw.write(Integer.parseInt(rule[1])+"\n");
            
            bw.write("-> life points \n");
            bw.write(Integer.parseInt(rule[2])+"\n");
            
            bw.write("-> max number of cards in the deck \n");
            bw.write(Integer.parseInt(rule[3])+"\n");
            
            bw.write("-> max number of cards in the hand \n");
            bw.write(Integer.parseInt(rule[4])+"\n");
            
            bw.write("-> max number of cards in the battlefield \n");
            bw.write(Integer.parseInt(rule[5])+"\n");
            
            bw.write("-> number of cards draw per turn \n");
            bw.write(Integer.parseInt(rule[6])+"\n");
            
            bw.write("-> number of cards in the first draw \n");
            bw.write(Integer.parseInt(rule[7])+"\n");
            
            bw.write("-> max number of turns (0 for infinite turns) \n");
            bw.write("0\n");
            
            bw.write("-> number of the player 2 extra mana points in one round \n");
            bw.write(Integer.parseInt(rule[8])+"\n");
            
            bw.write("-> number of the player 2 extra cards in the first draw \n");
            bw.write(Integer.parseInt(rule[9])+"\n");
            
            bw.write("-> player 2 rules are the same as player 1? (1 for true, 0 for false) \n");
            bw.write("0\n");
            
            bw.write("-> number of simulations \n");
            bw.write("1000\n");
            
            bw.write("-> number of subsets of monsters \n");
            bw.write("1\n");
            
            bw.write("-> % of monsters in each subset \n");
            bw.write("100\n");
            
            bw.write("-> max monster damage(one per subset, each one in separate lines) \n");
            bw.write(Integer.parseInt(rule[10])+"\n");
            
            bw.write("-> min monster damage \n");
            bw.write("1\n");
            
            bw.write("-> % of cards with attack greater than the max \n");
            bw.write("0\n");
            
            bw.write("-> max out of curve attack \n");
            bw.write("0\n");
            
            bw.write("-> max monster health \n");
            bw.write(Integer.parseInt(rule[11])+"\n");
            
            bw.write("-> min monster health \n");
            bw.write("1\n");
            
            bw.write("-> attack twice per turn (0 for subsets without this rule and 1 for subsets with this rule) \n");
            bw.write(Integer.parseInt(rule[12])+"\n");
            
            bw.write("-> attack in the same turn it was summoned (0 for subsets without this rule and 1 for subsets with this rule) \n");
            bw.write(Integer.parseInt(rule[13])+"\n");
            
            bw.write("-> enemy player must target cards with this rule (0 for subsets without this rule and 1 for subsets with this rule) \n");
            bw.write(Integer.parseInt(rule[14])+"\n");
            
            bw.write("-> cards with this rule will only last X rounds (0 for subsets without this rule and X for the subsets with this rule. X represents the number of rounds) \n");
            bw.write("0\n");//teste
            
            bw.write("-> cards with this rule cannot be target (0 for subsets without this rule and 1 for subsets with this rule) \n");
            bw.write(Integer.parseInt(rule[15])+"\n");
            
            bw.write("-> mana formula \n");
            bw.write("(a+h)/2\n");
            
            
            bw.close();
            
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    public static void printResultToFile1Max (String [] rule, int id) {
        try {
            File file = new File ("../resultsEstatistica/id"+id+"/printResultToFile1Max.txt");
            if (!file.exists ()) {
                file.createNewFile ();
            }
            FileWriter fw = new FileWriter (file.getAbsoluteFile());
            BufferedWriter bw = new BufferedWriter (fw);
            
            
            bw.write("-> start mana points \n");
            bw.write("0\n");
            
            bw.write("-> max mana points \n");
            bw.write("14\n");
            
            bw.write("-> mana rate \n");
            bw.write(Integer.parseInt(rule[1])+"\n");
            
            bw.write("-> life points \n");
            bw.write(Integer.parseInt(rule[2])+"\n");
            
            bw.write("-> max number of cards in the deck \n");
            bw.write(Integer.parseInt(rule[3])+"\n");
            
            bw.write("-> max number of cards in the hand \n");
            bw.write(Integer.parseInt(rule[4])+"\n");
            
            bw.write("-> max number of cards in the battlefield \n");
            bw.write(Integer.parseInt(rule[5])+"\n");
            
            bw.write("-> number of cards draw per turn \n");
            bw.write(Integer.parseInt(rule[6])+"\n");
            
            bw.write("-> number of cards in the first draw \n");
            bw.write(Integer.parseInt(rule[7])+"\n");
            
            bw.write("-> max number of turns (0 for infinite turns) \n");
            bw.write("0\n");
            
            bw.write("-> number of the player 2 extra mana points in one round \n");
            bw.write(Integer.parseInt(rule[8])+"\n");
            
            bw.write("-> number of the player 2 extra cards in the first draw \n");
            bw.write(Integer.parseInt(rule[9])+"\n");
            
            bw.write("-> player 2 rules are the same as player 1? (1 for true, 0 for false) \n");
            bw.write("0\n");
            
            bw.write("-> number of simulations \n");
            bw.write("1000\n");
            
            bw.write("-> number of subsets of monsters \n");
            bw.write("1\n");
            
            bw.write("-> % of monsters in each subset \n");
            bw.write("100\n");
            
            bw.write("-> max monster damage(one per subset, each one in separate lines) \n");
            bw.write(Integer.parseInt(rule[10])+"\n");
            
            bw.write("-> min monster damage \n");
            bw.write("1\n");
            
            bw.write("-> % of cards with attack greater than the max \n");
            bw.write("0\n");
            
            bw.write("-> max out of curve attack \n");
            bw.write("0\n");
            
            bw.write("-> max monster health \n");
            bw.write(Integer.parseInt(rule[11])+"\n");
            
            bw.write("-> min monster health \n");
            bw.write("1\n");
            
            bw.write("-> attack twice per turn (0 for subsets without this rule and 1 for subsets with this rule) \n");
            bw.write(Integer.parseInt(rule[12])+"\n");
            
            bw.write("-> attack in the same turn it was summoned (0 for subsets without this rule and 1 for subsets with this rule) \n");
            bw.write(Integer.parseInt(rule[13])+"\n");
            
            bw.write("-> enemy player must target cards with this rule (0 for subsets without this rule and 1 for subsets with this rule) \n");
            bw.write(Integer.parseInt(rule[14])+"\n");
            
            bw.write("-> cards with this rule will only last X rounds (0 for subsets without this rule and X for the subsets with this rule. X represents the number of rounds) \n");
            bw.write("0\n");//teste
            
            bw.write("-> cards with this rule cannot be target (0 for subsets without this rule and 1 for subsets with this rule) \n");
            bw.write(Integer.parseInt(rule[15])+"\n");
            
            bw.write("-> mana formula \n");
            bw.write("(a+h)/2\n");
            
            
            bw.close();
            
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    public static void printResultToFile2Min (String [] rule, int id) {
        try {
            File file = new File ("../resultsEstatistica/id"+id+"/printResultToFile2Min.txt");
            if (!file.exists ()) {
                file.createNewFile ();
            }
            FileWriter fw = new FileWriter (file.getAbsoluteFile());
            BufferedWriter bw = new BufferedWriter (fw);
            
            
            bw.write("-> start mana points \n");
            bw.write("0\n");
            
            bw.write("-> max mana points \n");
            bw.write(Integer.parseInt(rule[0])+"\n");
            
            bw.write("-> mana rate \n");
            bw.write("1\n");
            
            bw.write("-> life points \n");
            bw.write(Integer.parseInt(rule[2])+"\n");
            
            bw.write("-> max number of cards in the deck \n");
            bw.write(Integer.parseInt(rule[3])+"\n");
            
            bw.write("-> max number of cards in the hand \n");
            bw.write(Integer.parseInt(rule[4])+"\n");
            
            bw.write("-> max number of cards in the battlefield \n");
            bw.write(Integer.parseInt(rule[5])+"\n");
            
            bw.write("-> number of cards draw per turn \n");
            bw.write(Integer.parseInt(rule[6])+"\n");
            
            bw.write("-> number of cards in the first draw \n");
            bw.write(Integer.parseInt(rule[7])+"\n");
            
            bw.write("-> max number of turns (0 for infinite turns) \n");
            bw.write("0\n");
            
            bw.write("-> number of the player 2 extra mana points in one round \n");
            bw.write(Integer.parseInt(rule[8])+"\n");
            
            bw.write("-> number of the player 2 extra cards in the first draw \n");
            bw.write(Integer.parseInt(rule[9])+"\n");
            
            bw.write("-> player 2 rules are the same as player 1? (1 for true, 0 for false) \n");
            bw.write("0\n");
            
            bw.write("-> number of simulations \n");
            bw.write("1000\n");
            
            bw.write("-> number of subsets of monsters \n");
            bw.write("1\n");
            
            bw.write("-> % of monsters in each subset \n");
            bw.write("100\n");
            
            bw.write("-> max monster damage(one per subset, each one in separate lines) \n");
            bw.write(Integer.parseInt(rule[10])+"\n");
            
            bw.write("-> min monster damage \n");
            bw.write("1\n");
            
            bw.write("-> % of cards with attack greater than the max \n");
            bw.write("0\n");
            
            bw.write("-> max out of curve attack \n");
            bw.write("0\n");
            
            bw.write("-> max monster health \n");
            bw.write(Integer.parseInt(rule[11])+"\n");
            
            bw.write("-> min monster health \n");
            bw.write("1\n");
            
            bw.write("-> attack twice per turn (0 for subsets without this rule and 1 for subsets with this rule) \n");
            bw.write(Integer.parseInt(rule[12])+"\n");
            
            bw.write("-> attack in the same turn it was summoned (0 for subsets without this rule and 1 for subsets with this rule) \n");
            bw.write(Integer.parseInt(rule[13])+"\n");
            
            bw.write("-> enemy player must target cards with this rule (0 for subsets without this rule and 1 for subsets with this rule) \n");
            bw.write(Integer.parseInt(rule[14])+"\n");
            
            bw.write("-> cards with this rule will only last X rounds (0 for subsets without this rule and X for the subsets with this rule. X represents the number of rounds) \n");
            bw.write("0\n");//teste
            
            bw.write("-> cards with this rule cannot be target (0 for subsets without this rule and 1 for subsets with this rule) \n");
            bw.write(Integer.parseInt(rule[15])+"\n");
            
            bw.write("-> mana formula \n");
            bw.write("(a+h)/2\n");
            
            
            bw.close();
            
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    public static void printResultToFile2Max (String [] rule, int id) {
        try {
            File file = new File ("../resultsEstatistica/id"+id+"/printResultToFile2Max.txt");
            if (!file.exists ()) {
                file.createNewFile ();
            }
            FileWriter fw = new FileWriter (file.getAbsoluteFile());
            BufferedWriter bw = new BufferedWriter (fw);
            
            
            bw.write("-> start mana points \n");
            bw.write("0\n");
            
            bw.write("-> max mana points \n");
            bw.write(Integer.parseInt(rule[0])+"\n");
            
            bw.write("-> mana rate \n");
            bw.write("3\n");
            
            bw.write("-> life points \n");
            bw.write(Integer.parseInt(rule[2])+"\n");
            
            bw.write("-> max number of cards in the deck \n");
            bw.write(Integer.parseInt(rule[3])+"\n");
            
            bw.write("-> max number of cards in the hand \n");
            bw.write(Integer.parseInt(rule[4])+"\n");
            
            bw.write("-> max number of cards in the battlefield \n");
            bw.write(Integer.parseInt(rule[5])+"\n");
            
            bw.write("-> number of cards draw per turn \n");
            bw.write(Integer.parseInt(rule[6])+"\n");
            
            bw.write("-> number of cards in the first draw \n");
            bw.write(Integer.parseInt(rule[7])+"\n");
            
            bw.write("-> max number of turns (0 for infinite turns) \n");
            bw.write("0\n");
            
            bw.write("-> number of the player 2 extra mana points in one round \n");
            bw.write(Integer.parseInt(rule[8])+"\n");
            
            bw.write("-> number of the player 2 extra cards in the first draw \n");
            bw.write(Integer.parseInt(rule[9])+"\n");
            
            bw.write("-> player 2 rules are the same as player 1? (1 for true, 0 for false) \n");
            bw.write("0\n");
            
            bw.write("-> number of simulations \n");
            bw.write("1000\n");
            
            bw.write("-> number of subsets of monsters \n");
            bw.write("1\n");
            
            bw.write("-> % of monsters in each subset \n");
            bw.write("100\n");
            
            bw.write("-> max monster damage(one per subset, each one in separate lines) \n");
            bw.write(Integer.parseInt(rule[10])+"\n");
            
            bw.write("-> min monster damage \n");
            bw.write("1\n");
            
            bw.write("-> % of cards with attack greater than the max \n");
            bw.write("0\n");
            
            bw.write("-> max out of curve attack \n");
            bw.write("0\n");
            
            bw.write("-> max monster health \n");
            bw.write(Integer.parseInt(rule[11])+"\n");
            
            bw.write("-> min monster health \n");
            bw.write("1\n");
            
            bw.write("-> attack twice per turn (0 for subsets without this rule and 1 for subsets with this rule) \n");
            bw.write(Integer.parseInt(rule[12])+"\n");
            
            bw.write("-> attack in the same turn it was summoned (0 for subsets without this rule and 1 for subsets with this rule) \n");
            bw.write(Integer.parseInt(rule[13])+"\n");
            
            bw.write("-> enemy player must target cards with this rule (0 for subsets without this rule and 1 for subsets with this rule) \n");
            bw.write(Integer.parseInt(rule[14])+"\n");
            
            bw.write("-> cards with this rule will only last X rounds (0 for subsets without this rule and X for the subsets with this rule. X represents the number of rounds) \n");
            bw.write("0\n");//teste
            
            bw.write("-> cards with this rule cannot be target (0 for subsets without this rule and 1 for subsets with this rule) \n");
            bw.write(Integer.parseInt(rule[15])+"\n");
            
            bw.write("-> mana formula \n");
            bw.write("(a+h)/2\n");
            
            
            bw.close();
            
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    public static void printResultToFile3Min (String [] rule, int id) {
        try {
            File file = new File ("../resultsEstatistica/id"+id+"/printResultToFile3Min.txt");
            if (!file.exists ()) {
                file.createNewFile ();
            }
            FileWriter fw = new FileWriter (file.getAbsoluteFile());
            BufferedWriter bw = new BufferedWriter (fw);
            
            
            bw.write("-> start mana points \n");
            bw.write("0\n");
            
            bw.write("-> max mana points \n");
            bw.write(Integer.parseInt(rule[0])+"\n");
            
            bw.write("-> mana rate \n");
            bw.write(Integer.parseInt(rule[1])+"\n");
            
            bw.write("-> life points \n");
            bw.write("16\n");
            
            bw.write("-> max number of cards in the deck \n");
            bw.write(Integer.parseInt(rule[3])+"\n");
            
            bw.write("-> max number of cards in the hand \n");
            bw.write(Integer.parseInt(rule[4])+"\n");
            
            bw.write("-> max number of cards in the battlefield \n");
            bw.write(Integer.parseInt(rule[5])+"\n");
            
            bw.write("-> number of cards draw per turn \n");
            bw.write(Integer.parseInt(rule[6])+"\n");
            
            bw.write("-> number of cards in the first draw \n");
            bw.write(Integer.parseInt(rule[7])+"\n");
            
            bw.write("-> max number of turns (0 for infinite turns) \n");
            bw.write("0\n");
            
            bw.write("-> number of the player 2 extra mana points in one round \n");
            bw.write(Integer.parseInt(rule[8])+"\n");
            
            bw.write("-> number of the player 2 extra cards in the first draw \n");
            bw.write(Integer.parseInt(rule[9])+"\n");
            
            bw.write("-> player 2 rules are the same as player 1? (1 for true, 0 for false) \n");
            bw.write("0\n");
            
            bw.write("-> number of simulations \n");
            bw.write("1000\n");
            
            bw.write("-> number of subsets of monsters \n");
            bw.write("1\n");
            
            bw.write("-> % of monsters in each subset \n");
            bw.write("100\n");
            
            bw.write("-> max monster damage(one per subset, each one in separate lines) \n");
            bw.write(Integer.parseInt(rule[10])+"\n");
            
            bw.write("-> min monster damage \n");
            bw.write("1\n");
            
            bw.write("-> % of cards with attack greater than the max \n");
            bw.write("0\n");
            
            bw.write("-> max out of curve attack \n");
            bw.write("0\n");
            
            bw.write("-> max monster health \n");
            bw.write(Integer.parseInt(rule[11])+"\n");
            
            bw.write("-> min monster health \n");
            bw.write("1\n");
            
            bw.write("-> attack twice per turn (0 for subsets without this rule and 1 for subsets with this rule) \n");
            bw.write(Integer.parseInt(rule[12])+"\n");
            
            bw.write("-> attack in the same turn it was summoned (0 for subsets without this rule and 1 for subsets with this rule) \n");
            bw.write(Integer.parseInt(rule[13])+"\n");
            
            bw.write("-> enemy player must target cards with this rule (0 for subsets without this rule and 1 for subsets with this rule) \n");
            bw.write(Integer.parseInt(rule[14])+"\n");
            
            bw.write("-> cards with this rule will only last X rounds (0 for subsets without this rule and X for the subsets with this rule. X represents the number of rounds) \n");
            bw.write("0\n");//teste
            
            bw.write("-> cards with this rule cannot be target (0 for subsets without this rule and 1 for subsets with this rule) \n");
            bw.write(Integer.parseInt(rule[15])+"\n");
            
            bw.write("-> mana formula \n");
            bw.write("(a+h)/2\n");
            
            
            bw.close();
            
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    public static void printResultToFile3Max (String [] rule, int id) {
        try {
            File file = new File ("../resultsEstatistica/id"+id+"/printResultToFile3Max.txt");
            if (!file.exists ()) {
                file.createNewFile ();
            }
            FileWriter fw = new FileWriter (file.getAbsoluteFile());
            BufferedWriter bw = new BufferedWriter (fw);
            
            
            bw.write("-> start mana points \n");
            bw.write("0\n");
            
            bw.write("-> max mana points \n");
            bw.write(Integer.parseInt(rule[0])+"\n");
            
            bw.write("-> mana rate \n");
            bw.write(Integer.parseInt(rule[1])+"\n");
            
            bw.write("-> life points \n");
            bw.write("52\n");
            
            bw.write("-> max number of cards in the deck \n");
            bw.write(Integer.parseInt(rule[3])+"\n");
            
            bw.write("-> max number of cards in the hand \n");
            bw.write(Integer.parseInt(rule[4])+"\n");
            
            bw.write("-> max number of cards in the battlefield \n");
            bw.write(Integer.parseInt(rule[5])+"\n");
            
            bw.write("-> number of cards draw per turn \n");
            bw.write(Integer.parseInt(rule[6])+"\n");
            
            bw.write("-> number of cards in the first draw \n");
            bw.write(Integer.parseInt(rule[7])+"\n");
            
            bw.write("-> max number of turns (0 for infinite turns) \n");
            bw.write("0\n");
            
            bw.write("-> number of the player 2 extra mana points in one round \n");
            bw.write(Integer.parseInt(rule[8])+"\n");
            
            bw.write("-> number of the player 2 extra cards in the first draw \n");
            bw.write(Integer.parseInt(rule[9])+"\n");
            
            bw.write("-> player 2 rules are the same as player 1? (1 for true, 0 for false) \n");
            bw.write("0\n");
            
            bw.write("-> number of simulations \n");
            bw.write("1000\n");
            
            bw.write("-> number of subsets of monsters \n");
            bw.write("1\n");
            
            bw.write("-> % of monsters in each subset \n");
            bw.write("100\n");
            
            bw.write("-> max monster damage(one per subset, each one in separate lines) \n");
            bw.write(Integer.parseInt(rule[10])+"\n");
            
            bw.write("-> min monster damage \n");
            bw.write("1\n");
            
            bw.write("-> % of cards with attack greater than the max \n");
            bw.write("0\n");
            
            bw.write("-> max out of curve attack \n");
            bw.write("0\n");
            
            bw.write("-> max monster health \n");
            bw.write(Integer.parseInt(rule[11])+"\n");
            
            bw.write("-> min monster health \n");
            bw.write("1\n");
            
            bw.write("-> attack twice per turn (0 for subsets without this rule and 1 for subsets with this rule) \n");
            bw.write(Integer.parseInt(rule[12])+"\n");
            
            bw.write("-> attack in the same turn it was summoned (0 for subsets without this rule and 1 for subsets with this rule) \n");
            bw.write(Integer.parseInt(rule[13])+"\n");
            
            bw.write("-> enemy player must target cards with this rule (0 for subsets without this rule and 1 for subsets with this rule) \n");
            bw.write(Integer.parseInt(rule[14])+"\n");
            
            bw.write("-> cards with this rule will only last X rounds (0 for subsets without this rule and X for the subsets with this rule. X represents the number of rounds) \n");
            bw.write("0\n");//teste
            
            bw.write("-> cards with this rule cannot be target (0 for subsets without this rule and 1 for subsets with this rule) \n");
            bw.write(Integer.parseInt(rule[15])+"\n");
            
            bw.write("-> mana formula \n");
            bw.write("(a+h)/2\n");
            
            
            bw.close();
            
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    public static void printResultToFile4Min (String [] rule, int id) {
        try {
            File file = new File ("../resultsEstatistica/id"+id+"/printResultToFile4Min.txt");
            if (!file.exists ()) {
                file.createNewFile ();
            }
            FileWriter fw = new FileWriter (file.getAbsoluteFile());
            BufferedWriter bw = new BufferedWriter (fw);
            
            
            bw.write("-> start mana points \n");
            bw.write("0\n");
            
            bw.write("-> max mana points \n");
            bw.write(Integer.parseInt(rule[0])+"\n");
            
            bw.write("-> mana rate \n");
            bw.write(Integer.parseInt(rule[1])+"\n");
            
            bw.write("-> life points \n");
            bw.write(Integer.parseInt(rule[2])+"\n");
            
            bw.write("-> max number of cards in the deck \n");
            bw.write("18\n");
            
            bw.write("-> max number of cards in the hand \n");
            bw.write(Integer.parseInt(rule[4])+"\n");
            
            bw.write("-> max number of cards in the battlefield \n");
            bw.write(Integer.parseInt(rule[5])+"\n");
            
            bw.write("-> number of cards draw per turn \n");
            bw.write(Integer.parseInt(rule[6])+"\n");
            
            bw.write("-> number of cards in the first draw \n");
            bw.write(Integer.parseInt(rule[7])+"\n");
            
            bw.write("-> max number of turns (0 for infinite turns) \n");
            bw.write("0\n");
            
            bw.write("-> number of the player 2 extra mana points in one round \n");
            bw.write(Integer.parseInt(rule[8])+"\n");
            
            bw.write("-> number of the player 2 extra cards in the first draw \n");
            bw.write(Integer.parseInt(rule[9])+"\n");
            
            bw.write("-> player 2 rules are the same as player 1? (1 for true, 0 for false) \n");
            bw.write("0\n");
            
            bw.write("-> number of simulations \n");
            bw.write("1000\n");
            
            bw.write("-> number of subsets of monsters \n");
            bw.write("1\n");
            
            bw.write("-> % of monsters in each subset \n");
            bw.write("100\n");
            
            bw.write("-> max monster damage(one per subset, each one in separate lines) \n");
            bw.write(Integer.parseInt(rule[10])+"\n");
            
            bw.write("-> min monster damage \n");
            bw.write("1\n");
            
            bw.write("-> % of cards with attack greater than the max \n");
            bw.write("0\n");
            
            bw.write("-> max out of curve attack \n");
            bw.write("0\n");
            
            bw.write("-> max monster health \n");
            bw.write(Integer.parseInt(rule[11])+"\n");
            
            bw.write("-> min monster health \n");
            bw.write("1\n");
            
            bw.write("-> attack twice per turn (0 for subsets without this rule and 1 for subsets with this rule) \n");
            bw.write(Integer.parseInt(rule[12])+"\n");
            
            bw.write("-> attack in the same turn it was summoned (0 for subsets without this rule and 1 for subsets with this rule) \n");
            bw.write(Integer.parseInt(rule[13])+"\n");
            
            bw.write("-> enemy player must target cards with this rule (0 for subsets without this rule and 1 for subsets with this rule) \n");
            bw.write(Integer.parseInt(rule[14])+"\n");
            
            bw.write("-> cards with this rule will only last X rounds (0 for subsets without this rule and X for the subsets with this rule. X represents the number of rounds) \n");
            bw.write("0\n");//teste
            
            bw.write("-> cards with this rule cannot be target (0 for subsets without this rule and 1 for subsets with this rule) \n");
            bw.write(Integer.parseInt(rule[15])+"\n");
            
            bw.write("-> mana formula \n");
            bw.write("(a+h)/2\n");
            
            
            bw.close();
            
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    public static void printResultToFile4Max (String [] rule, int id) {
        try {
            File file = new File ("../resultsEstatistica/id"+id+"/printResultToFile4Max.txt");
            if (!file.exists ()) {
                file.createNewFile ();
            }
            FileWriter fw = new FileWriter (file.getAbsoluteFile());
            BufferedWriter bw = new BufferedWriter (fw);
            
            
            bw.write("-> start mana points \n");
            bw.write("0\n");
            
            bw.write("-> max mana points \n");
            bw.write(Integer.parseInt(rule[0])+"\n");
            
            bw.write("-> mana rate \n");
            bw.write(Integer.parseInt(rule[1])+"\n");
            
            bw.write("-> life points \n");
            bw.write(Integer.parseInt(rule[2])+"\n");
            
            bw.write("-> max number of cards in the deck \n");
            bw.write("45\n");
            
            bw.write("-> max number of cards in the hand \n");
            bw.write(Integer.parseInt(rule[4])+"\n");
            
            bw.write("-> max number of cards in the battlefield \n");
            bw.write(Integer.parseInt(rule[5])+"\n");
            
            bw.write("-> number of cards draw per turn \n");
            bw.write(Integer.parseInt(rule[6])+"\n");
            
            bw.write("-> number of cards in the first draw \n");
            bw.write(Integer.parseInt(rule[7])+"\n");
            
            bw.write("-> max number of turns (0 for infinite turns) \n");
            bw.write("0\n");
            
            bw.write("-> number of the player 2 extra mana points in one round \n");
            bw.write(Integer.parseInt(rule[8])+"\n");
            
            bw.write("-> number of the player 2 extra cards in the first draw \n");
            bw.write(Integer.parseInt(rule[9])+"\n");
            
            bw.write("-> player 2 rules are the same as player 1? (1 for true, 0 for false) \n");
            bw.write("0\n");
            
            bw.write("-> number of simulations \n");
            bw.write("1000\n");
            
            bw.write("-> number of subsets of monsters \n");
            bw.write("1\n");
            
            bw.write("-> % of monsters in each subset \n");
            bw.write("100\n");
            
            bw.write("-> max monster damage(one per subset, each one in separate lines) \n");
            bw.write(Integer.parseInt(rule[10])+"\n");
            
            bw.write("-> min monster damage \n");
            bw.write("1\n");
            
            bw.write("-> % of cards with attack greater than the max \n");
            bw.write("0\n");
            
            bw.write("-> max out of curve attack \n");
            bw.write("0\n");
            
            bw.write("-> max monster health \n");
            bw.write(Integer.parseInt(rule[11])+"\n");
            
            bw.write("-> min monster health \n");
            bw.write("1\n");
            
            bw.write("-> attack twice per turn (0 for subsets without this rule and 1 for subsets with this rule) \n");
            bw.write(Integer.parseInt(rule[12])+"\n");
            
            bw.write("-> attack in the same turn it was summoned (0 for subsets without this rule and 1 for subsets with this rule) \n");
            bw.write(Integer.parseInt(rule[13])+"\n");
            
            bw.write("-> enemy player must target cards with this rule (0 for subsets without this rule and 1 for subsets with this rule) \n");
            bw.write(Integer.parseInt(rule[14])+"\n");
            
            bw.write("-> cards with this rule will only last X rounds (0 for subsets without this rule and X for the subsets with this rule. X represents the number of rounds) \n");
            bw.write("0\n");//teste
            
            bw.write("-> cards with this rule cannot be target (0 for subsets without this rule and 1 for subsets with this rule) \n");
            bw.write(Integer.parseInt(rule[15])+"\n");
            
            bw.write("-> mana formula \n");
            bw.write("(a+h)/2\n");
            
            
            bw.close();
            
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    public static void printResultToFile5Min (String [] rule, int id) {
        try {
            File file = new File ("../resultsEstatistica/id"+id+"/printResultToFile5Min.txt");
            if (!file.exists ()) {
                file.createNewFile ();
            }
            FileWriter fw = new FileWriter (file.getAbsoluteFile());
            BufferedWriter bw = new BufferedWriter (fw);
            
            
            bw.write("-> start mana points \n");
            bw.write("0\n");
            
            bw.write("-> max mana points \n");
            bw.write(Integer.parseInt(rule[0])+"\n");
            
            bw.write("-> mana rate \n");
            bw.write(Integer.parseInt(rule[1])+"\n");
            
            bw.write("-> life points \n");
            bw.write(Integer.parseInt(rule[2])+"\n");
            
            bw.write("-> max number of cards in the deck \n");
            bw.write(Integer.parseInt(rule[3])+"\n");
            
            bw.write("-> max number of cards in the hand \n");
            bw.write("5\n");
            
            bw.write("-> max number of cards in the battlefield \n");
            bw.write(Integer.parseInt(rule[5])+"\n");
            
            bw.write("-> number of cards draw per turn \n");
            bw.write(Integer.parseInt(rule[6])+"\n");
            
            bw.write("-> number of cards in the first draw \n");
            bw.write(Integer.parseInt(rule[7])+"\n");
            
            bw.write("-> max number of turns (0 for infinite turns) \n");
            bw.write("0\n");
            
            bw.write("-> number of the player 2 extra mana points in one round \n");
            bw.write(Integer.parseInt(rule[8])+"\n");
            
            bw.write("-> number of the player 2 extra cards in the first draw \n");
            bw.write(Integer.parseInt(rule[9])+"\n");
            
            bw.write("-> player 2 rules are the same as player 1? (1 for true, 0 for false) \n");
            bw.write("0\n");
            
            bw.write("-> number of simulations \n");
            bw.write("1000\n");
            
            bw.write("-> number of subsets of monsters \n");
            bw.write("1\n");
            
            bw.write("-> % of monsters in each subset \n");
            bw.write("100\n");
            
            bw.write("-> max monster damage(one per subset, each one in separate lines) \n");
            bw.write(Integer.parseInt(rule[10])+"\n");
            
            bw.write("-> min monster damage \n");
            bw.write("1\n");
            
            bw.write("-> % of cards with attack greater than the max \n");
            bw.write("0\n");
            
            bw.write("-> max out of curve attack \n");
            bw.write("0\n");
            
            bw.write("-> max monster health \n");
            bw.write(Integer.parseInt(rule[11])+"\n");
            
            bw.write("-> min monster health \n");
            bw.write("1\n");
            
            bw.write("-> attack twice per turn (0 for subsets without this rule and 1 for subsets with this rule) \n");
            bw.write(Integer.parseInt(rule[12])+"\n");
            
            bw.write("-> attack in the same turn it was summoned (0 for subsets without this rule and 1 for subsets with this rule) \n");
            bw.write(Integer.parseInt(rule[13])+"\n");
            
            bw.write("-> enemy player must target cards with this rule (0 for subsets without this rule and 1 for subsets with this rule) \n");
            bw.write(Integer.parseInt(rule[14])+"\n");
            
            bw.write("-> cards with this rule will only last X rounds (0 for subsets without this rule and X for the subsets with this rule. X represents the number of rounds) \n");
            bw.write("0\n");//teste
            
            bw.write("-> cards with this rule cannot be target (0 for subsets without this rule and 1 for subsets with this rule) \n");
            bw.write(Integer.parseInt(rule[15])+"\n");
            
            bw.write("-> mana formula \n");
            bw.write("(a+h)/2\n");
            
            
            bw.close();
            
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    public static void printResultToFile5Max (String [] rule, int id) {
        try {
            File file = new File ("../resultsEstatistica/id"+id+"/printResultToFile5Max.txt");
            if (!file.exists ()) {
                file.createNewFile ();
            }
            FileWriter fw = new FileWriter (file.getAbsoluteFile());
            BufferedWriter bw = new BufferedWriter (fw);
            
            
            bw.write("-> start mana points \n");
            bw.write("0\n");
            
            bw.write("-> max mana points \n");
            bw.write(Integer.parseInt(rule[0])+"\n");
            
            bw.write("-> mana rate \n");
            bw.write(Integer.parseInt(rule[1])+"\n");
            
            bw.write("-> life points \n");
            bw.write(Integer.parseInt(rule[2])+"\n");
            
            bw.write("-> max number of cards in the deck \n");
            bw.write(Integer.parseInt(rule[3])+"\n");
            
            bw.write("-> max number of cards in the hand \n");
            bw.write("14\n");
            
            bw.write("-> max number of cards in the battlefield \n");
            bw.write(Integer.parseInt(rule[5])+"\n");
            
            bw.write("-> number of cards draw per turn \n");
            bw.write(Integer.parseInt(rule[6])+"\n");
            
            bw.write("-> number of cards in the first draw \n");
            bw.write(Integer.parseInt(rule[7])+"\n");
            
            bw.write("-> max number of turns (0 for infinite turns) \n");
            bw.write("0\n");
            
            bw.write("-> number of the player 2 extra mana points in one round \n");
            bw.write(Integer.parseInt(rule[8])+"\n");
            
            bw.write("-> number of the player 2 extra cards in the first draw \n");
            bw.write(Integer.parseInt(rule[9])+"\n");
            
            bw.write("-> player 2 rules are the same as player 1? (1 for true, 0 for false) \n");
            bw.write("0\n");
            
            bw.write("-> number of simulations \n");
            bw.write("1000\n");
            
            bw.write("-> number of subsets of monsters \n");
            bw.write("1\n");
            
            bw.write("-> % of monsters in each subset \n");
            bw.write("100\n");
            
            bw.write("-> max monster damage(one per subset, each one in separate lines) \n");
            bw.write(Integer.parseInt(rule[10])+"\n");
            
            bw.write("-> min monster damage \n");
            bw.write("1\n");
            
            bw.write("-> % of cards with attack greater than the max \n");
            bw.write("0\n");
            
            bw.write("-> max out of curve attack \n");
            bw.write("0\n");
            
            bw.write("-> max monster health \n");
            bw.write(Integer.parseInt(rule[11])+"\n");
            
            bw.write("-> min monster health \n");
            bw.write("1\n");
            
            bw.write("-> attack twice per turn (0 for subsets without this rule and 1 for subsets with this rule) \n");
            bw.write(Integer.parseInt(rule[12])+"\n");
            
            bw.write("-> attack in the same turn it was summoned (0 for subsets without this rule and 1 for subsets with this rule) \n");
            bw.write(Integer.parseInt(rule[13])+"\n");
            
            bw.write("-> enemy player must target cards with this rule (0 for subsets without this rule and 1 for subsets with this rule) \n");
            bw.write(Integer.parseInt(rule[14])+"\n");
            
            bw.write("-> cards with this rule will only last X rounds (0 for subsets without this rule and X for the subsets with this rule. X represents the number of rounds) \n");
            bw.write("0\n");//teste
            
            bw.write("-> cards with this rule cannot be target (0 for subsets without this rule and 1 for subsets with this rule) \n");
            bw.write(Integer.parseInt(rule[15])+"\n");
            
            bw.write("-> mana formula \n");
            bw.write("(a+h)/2\n");
            
            
            bw.close();
            
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    public static void printResultToFile6Min (String [] rule, int id) {
        try {
            File file = new File ("../resultsEstatistica/id"+id+"/printResultToFile6Min.txt");
            if (!file.exists ()) {
                file.createNewFile ();
            }
            FileWriter fw = new FileWriter (file.getAbsoluteFile());
            BufferedWriter bw = new BufferedWriter (fw);
            
            
            bw.write("-> start mana points \n");
            bw.write("0\n");
            
            bw.write("-> max mana points \n");
            bw.write(Integer.parseInt(rule[0])+"\n");
            
            bw.write("-> mana rate \n");
            bw.write(Integer.parseInt(rule[1])+"\n");
            
            bw.write("-> life points \n");
            bw.write(Integer.parseInt(rule[2])+"\n");
            
            bw.write("-> max number of cards in the deck \n");
            bw.write(Integer.parseInt(rule[3])+"\n");
            
            bw.write("-> max number of cards in the hand \n");
            bw.write(Integer.parseInt(rule[4])+"\n");
            
            bw.write("-> max number of cards in the battlefield \n");
            bw.write("5\n");
            
            bw.write("-> number of cards draw per turn \n");
            bw.write(Integer.parseInt(rule[6])+"\n");
            
            bw.write("-> number of cards in the first draw \n");
            bw.write(Integer.parseInt(rule[7])+"\n");
            
            bw.write("-> max number of turns (0 for infinite turns) \n");
            bw.write("0\n");
            
            bw.write("-> number of the player 2 extra mana points in one round \n");
            bw.write(Integer.parseInt(rule[8])+"\n");
            
            bw.write("-> number of the player 2 extra cards in the first draw \n");
            bw.write(Integer.parseInt(rule[9])+"\n");
            
            bw.write("-> player 2 rules are the same as player 1? (1 for true, 0 for false) \n");
            bw.write("0\n");
            
            bw.write("-> number of simulations \n");
            bw.write("1000\n");
            
            bw.write("-> number of subsets of monsters \n");
            bw.write("1\n");
            
            bw.write("-> % of monsters in each subset \n");
            bw.write("100\n");
            
            bw.write("-> max monster damage(one per subset, each one in separate lines) \n");
            bw.write(Integer.parseInt(rule[10])+"\n");
            
            bw.write("-> min monster damage \n");
            bw.write("1\n");
            
            bw.write("-> % of cards with attack greater than the max \n");
            bw.write("0\n");
            
            bw.write("-> max out of curve attack \n");
            bw.write("0\n");
            
            bw.write("-> max monster health \n");
            bw.write(Integer.parseInt(rule[11])+"\n");
            
            bw.write("-> min monster health \n");
            bw.write("1\n");
            
            bw.write("-> attack twice per turn (0 for subsets without this rule and 1 for subsets with this rule) \n");
            bw.write(Integer.parseInt(rule[12])+"\n");
            
            bw.write("-> attack in the same turn it was summoned (0 for subsets without this rule and 1 for subsets with this rule) \n");
            bw.write(Integer.parseInt(rule[13])+"\n");
            
            bw.write("-> enemy player must target cards with this rule (0 for subsets without this rule and 1 for subsets with this rule) \n");
            bw.write(Integer.parseInt(rule[14])+"\n");
            
            bw.write("-> cards with this rule will only last X rounds (0 for subsets without this rule and X for the subsets with this rule. X represents the number of rounds) \n");
            bw.write("0\n");//teste
            
            bw.write("-> cards with this rule cannot be target (0 for subsets without this rule and 1 for subsets with this rule) \n");
            bw.write(Integer.parseInt(rule[15])+"\n");
            
            bw.write("-> mana formula \n");
            bw.write("(a+h)/2\n");
            
            
            bw.close();
            
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    public static void printResultToFile6Max (String [] rule, int id) {
        try {
            File file = new File ("../resultsEstatistica/id"+id+"/printResultToFile6Max.txt");
            if (!file.exists ()) {
                file.createNewFile ();
            }
            FileWriter fw = new FileWriter (file.getAbsoluteFile());
            BufferedWriter bw = new BufferedWriter (fw);
            
            
            bw.write("-> start mana points \n");
            bw.write("0\n");
            
            bw.write("-> max mana points \n");
            bw.write(Integer.parseInt(rule[0])+"\n");
            
            bw.write("-> mana rate \n");
            bw.write(Integer.parseInt(rule[1])+"\n");
            
            bw.write("-> life points \n");
            bw.write(Integer.parseInt(rule[2])+"\n");
            
            bw.write("-> max number of cards in the deck \n");
            bw.write(Integer.parseInt(rule[3])+"\n");
            
            bw.write("-> max number of cards in the hand \n");
            bw.write(Integer.parseInt(rule[4])+"\n");
            
            bw.write("-> max number of cards in the battlefield \n");
            bw.write("14\n");
            
            bw.write("-> number of cards draw per turn \n");
            bw.write(Integer.parseInt(rule[6])+"\n");
            
            bw.write("-> number of cards in the first draw \n");
            bw.write(Integer.parseInt(rule[7])+"\n");
            
            bw.write("-> max number of turns (0 for infinite turns) \n");
            bw.write("0\n");
            
            bw.write("-> number of the player 2 extra mana points in one round \n");
            bw.write(Integer.parseInt(rule[8])+"\n");
            
            bw.write("-> number of the player 2 extra cards in the first draw \n");
            bw.write(Integer.parseInt(rule[9])+"\n");
            
            bw.write("-> player 2 rules are the same as player 1? (1 for true, 0 for false) \n");
            bw.write("0\n");
            
            bw.write("-> number of simulations \n");
            bw.write("1000\n");
            
            bw.write("-> number of subsets of monsters \n");
            bw.write("1\n");
            
            bw.write("-> % of monsters in each subset \n");
            bw.write("100\n");
            
            bw.write("-> max monster damage(one per subset, each one in separate lines) \n");
            bw.write(Integer.parseInt(rule[10])+"\n");
            
            bw.write("-> min monster damage \n");
            bw.write("1\n");
            
            bw.write("-> % of cards with attack greater than the max \n");
            bw.write("0\n");
            
            bw.write("-> max out of curve attack \n");
            bw.write("0\n");
            
            bw.write("-> max monster health \n");
            bw.write(Integer.parseInt(rule[11])+"\n");
            
            bw.write("-> min monster health \n");
            bw.write("1\n");
            
            bw.write("-> attack twice per turn (0 for subsets without this rule and 1 for subsets with this rule) \n");
            bw.write(Integer.parseInt(rule[12])+"\n");
            
            bw.write("-> attack in the same turn it was summoned (0 for subsets without this rule and 1 for subsets with this rule) \n");
            bw.write(Integer.parseInt(rule[13])+"\n");
            
            bw.write("-> enemy player must target cards with this rule (0 for subsets without this rule and 1 for subsets with this rule) \n");
            bw.write(Integer.parseInt(rule[14])+"\n");
            
            bw.write("-> cards with this rule will only last X rounds (0 for subsets without this rule and X for the subsets with this rule. X represents the number of rounds) \n");
            bw.write("0\n");//teste
            
            bw.write("-> cards with this rule cannot be target (0 for subsets without this rule and 1 for subsets with this rule) \n");
            bw.write(Integer.parseInt(rule[15])+"\n");
            
            bw.write("-> mana formula \n");
            bw.write("(a+h)/2\n");
            
            
            bw.close();
            
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    public static void printResultToFile7Min (String [] rule, int id) {
        try {
            File file = new File ("../resultsEstatistica/id"+id+"/printResultToFile7Min.txt");
            if (!file.exists ()) {
                file.createNewFile ();
            }
            FileWriter fw = new FileWriter (file.getAbsoluteFile());
            BufferedWriter bw = new BufferedWriter (fw);
            
            
            bw.write("-> start mana points \n");
            bw.write("0\n");
            
            bw.write("-> max mana points \n");
            bw.write(Integer.parseInt(rule[0])+"\n");
            
            bw.write("-> mana rate \n");
            bw.write(Integer.parseInt(rule[1])+"\n");
            
            bw.write("-> life points \n");
            bw.write(Integer.parseInt(rule[2])+"\n");
            
            bw.write("-> max number of cards in the deck \n");
            bw.write(Integer.parseInt(rule[3])+"\n");
            
            bw.write("-> max number of cards in the hand \n");
            bw.write(Integer.parseInt(rule[4])+"\n");
            
            bw.write("-> max number of cards in the battlefield \n");
            bw.write(Integer.parseInt(rule[5])+"\n");
            
            bw.write("-> number of cards draw per turn \n");
            bw.write("1\n");
            
            bw.write("-> number of cards in the first draw \n");
            bw.write(Integer.parseInt(rule[7])+"\n");
            
            bw.write("-> max number of turns (0 for infinite turns) \n");
            bw.write("0\n");
            
            bw.write("-> number of the player 2 extra mana points in one round \n");
            bw.write(Integer.parseInt(rule[8])+"\n");
            
            bw.write("-> number of the player 2 extra cards in the first draw \n");
            bw.write(Integer.parseInt(rule[9])+"\n");
            
            bw.write("-> player 2 rules are the same as player 1? (1 for true, 0 for false) \n");
            bw.write("0\n");
            
            bw.write("-> number of simulations \n");
            bw.write("1000\n");
            
            bw.write("-> number of subsets of monsters \n");
            bw.write("1\n");
            
            bw.write("-> % of monsters in each subset \n");
            bw.write("100\n");
            
            bw.write("-> max monster damage(one per subset, each one in separate lines) \n");
            bw.write(Integer.parseInt(rule[10])+"\n");
            
            bw.write("-> min monster damage \n");
            bw.write("1\n");
            
            bw.write("-> % of cards with attack greater than the max \n");
            bw.write("0\n");
            
            bw.write("-> max out of curve attack \n");
            bw.write("0\n");
            
            bw.write("-> max monster health \n");
            bw.write(Integer.parseInt(rule[11])+"\n");
            
            bw.write("-> min monster health \n");
            bw.write("1\n");
            
            bw.write("-> attack twice per turn (0 for subsets without this rule and 1 for subsets with this rule) \n");
            bw.write(Integer.parseInt(rule[12])+"\n");
            
            bw.write("-> attack in the same turn it was summoned (0 for subsets without this rule and 1 for subsets with this rule) \n");
            bw.write(Integer.parseInt(rule[13])+"\n");
            
            bw.write("-> enemy player must target cards with this rule (0 for subsets without this rule and 1 for subsets with this rule) \n");
            bw.write(Integer.parseInt(rule[14])+"\n");
            
            bw.write("-> cards with this rule will only last X rounds (0 for subsets without this rule and X for the subsets with this rule. X represents the number of rounds) \n");
            bw.write("0\n");//teste
            
            bw.write("-> cards with this rule cannot be target (0 for subsets without this rule and 1 for subsets with this rule) \n");
            bw.write(Integer.parseInt(rule[15])+"\n");
            
            bw.write("-> mana formula \n");
            bw.write("(a+h)/2\n");
            
            
            bw.close();
            
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    public static void printResultToFile7Max (String [] rule, int id) {
        try {
            File file = new File ("../resultsEstatistica/id"+id+"/printResultToFile7Max.txt");
            if (!file.exists ()) {
                file.createNewFile ();
            }
            FileWriter fw = new FileWriter (file.getAbsoluteFile());
            BufferedWriter bw = new BufferedWriter (fw);
            
            
            bw.write("-> start mana points \n");
            bw.write("0\n");
            
            bw.write("-> max mana points \n");
            bw.write(Integer.parseInt(rule[0])+"\n");
            
            bw.write("-> mana rate \n");
            bw.write(Integer.parseInt(rule[1])+"\n");
            
            bw.write("-> life points \n");
            bw.write(Integer.parseInt(rule[2])+"\n");
            
            bw.write("-> max number of cards in the deck \n");
            bw.write(Integer.parseInt(rule[3])+"\n");
            
            bw.write("-> max number of cards in the hand \n");
            bw.write(Integer.parseInt(rule[4])+"\n");
            
            bw.write("-> max number of cards in the battlefield \n");
            bw.write(Integer.parseInt(rule[5])+"\n");
            
            bw.write("-> number of cards draw per turn \n");
            bw.write("3\n");
            
            bw.write("-> number of cards in the first draw \n");
            bw.write(Integer.parseInt(rule[7])+"\n");
            
            bw.write("-> max number of turns (0 for infinite turns) \n");
            bw.write("0\n");
            
            bw.write("-> number of the player 2 extra mana points in one round \n");
            bw.write(Integer.parseInt(rule[8])+"\n");
            
            bw.write("-> number of the player 2 extra cards in the first draw \n");
            bw.write(Integer.parseInt(rule[9])+"\n");
            
            bw.write("-> player 2 rules are the same as player 1? (1 for true, 0 for false) \n");
            bw.write("0\n");
            
            bw.write("-> number of simulations \n");
            bw.write("1000\n");
            
            bw.write("-> number of subsets of monsters \n");
            bw.write("1\n");
            
            bw.write("-> % of monsters in each subset \n");
            bw.write("100\n");
            
            bw.write("-> max monster damage(one per subset, each one in separate lines) \n");
            bw.write(Integer.parseInt(rule[10])+"\n");
            
            bw.write("-> min monster damage \n");
            bw.write("1\n");
            
            bw.write("-> % of cards with attack greater than the max \n");
            bw.write("0\n");
            
            bw.write("-> max out of curve attack \n");
            bw.write("0\n");
            
            bw.write("-> max monster health \n");
            bw.write(Integer.parseInt(rule[11])+"\n");
            
            bw.write("-> min monster health \n");
            bw.write("1\n");
            
            bw.write("-> attack twice per turn (0 for subsets without this rule and 1 for subsets with this rule) \n");
            bw.write(Integer.parseInt(rule[12])+"\n");
            
            bw.write("-> attack in the same turn it was summoned (0 for subsets without this rule and 1 for subsets with this rule) \n");
            bw.write(Integer.parseInt(rule[13])+"\n");
            
            bw.write("-> enemy player must target cards with this rule (0 for subsets without this rule and 1 for subsets with this rule) \n");
            bw.write(Integer.parseInt(rule[14])+"\n");
            
            bw.write("-> cards with this rule will only last X rounds (0 for subsets without this rule and X for the subsets with this rule. X represents the number of rounds) \n");
            bw.write("0\n");//teste
            
            bw.write("-> cards with this rule cannot be target (0 for subsets without this rule and 1 for subsets with this rule) \n");
            bw.write(Integer.parseInt(rule[15])+"\n");
            
            bw.write("-> mana formula \n");
            bw.write("(a+h)/2\n");
            
            
            bw.close();
            
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    public static void printResultToFile8Min (String [] rule, int id) {
        try {
            File file = new File ("../resultsEstatistica/id"+id+"/printResultToFile8Min.txt");
            if (!file.exists ()) {
                file.createNewFile ();
            }
            FileWriter fw = new FileWriter (file.getAbsoluteFile());
            BufferedWriter bw = new BufferedWriter (fw);
            
            
            bw.write("-> start mana points \n");
            bw.write("0\n");
            
            bw.write("-> max mana points \n");
            bw.write(Integer.parseInt(rule[0])+"\n");
            
            bw.write("-> mana rate \n");
            bw.write(Integer.parseInt(rule[1])+"\n");
            
            bw.write("-> life points \n");
            bw.write(Integer.parseInt(rule[2])+"\n");
            
            bw.write("-> max number of cards in the deck \n");
            bw.write(Integer.parseInt(rule[3])+"\n");
            
            bw.write("-> max number of cards in the hand \n");
            bw.write(Integer.parseInt(rule[4])+"\n");
            
            bw.write("-> max number of cards in the battlefield \n");
            bw.write(Integer.parseInt(rule[5])+"\n");
            
            bw.write("-> number of cards draw per turn \n");
            bw.write(Integer.parseInt(rule[6])+"\n");
            
            bw.write("-> number of cards in the first draw \n");
            bw.write("3\n");
            
            bw.write("-> max number of turns (0 for infinite turns) \n");
            bw.write("0\n");
            
            bw.write("-> number of the player 2 extra mana points in one round \n");
            bw.write(Integer.parseInt(rule[8])+"\n");
            
            bw.write("-> number of the player 2 extra cards in the first draw \n");
            bw.write(Integer.parseInt(rule[9])+"\n");
            
            bw.write("-> player 2 rules are the same as player 1? (1 for true, 0 for false) \n");
            bw.write("0\n");
            
            bw.write("-> number of simulations \n");
            bw.write("1000\n");
            
            bw.write("-> number of subsets of monsters \n");
            bw.write("1\n");
            
            bw.write("-> % of monsters in each subset \n");
            bw.write("100\n");
            
            bw.write("-> max monster damage(one per subset, each one in separate lines) \n");
            bw.write(Integer.parseInt(rule[10])+"\n");
            
            bw.write("-> min monster damage \n");
            bw.write("1\n");
            
            bw.write("-> % of cards with attack greater than the max \n");
            bw.write("0\n");
            
            bw.write("-> max out of curve attack \n");
            bw.write("0\n");
            
            bw.write("-> max monster health \n");
            bw.write(Integer.parseInt(rule[11])+"\n");
            
            bw.write("-> min monster health \n");
            bw.write("1\n");
            
            bw.write("-> attack twice per turn (0 for subsets without this rule and 1 for subsets with this rule) \n");
            bw.write(Integer.parseInt(rule[12])+"\n");
            
            bw.write("-> attack in the same turn it was summoned (0 for subsets without this rule and 1 for subsets with this rule) \n");
            bw.write(Integer.parseInt(rule[13])+"\n");
            
            bw.write("-> enemy player must target cards with this rule (0 for subsets without this rule and 1 for subsets with this rule) \n");
            bw.write(Integer.parseInt(rule[14])+"\n");
            
            bw.write("-> cards with this rule will only last X rounds (0 for subsets without this rule and X for the subsets with this rule. X represents the number of rounds) \n");
            bw.write("0\n");//teste
            
            bw.write("-> cards with this rule cannot be target (0 for subsets without this rule and 1 for subsets with this rule) \n");
            bw.write(Integer.parseInt(rule[15])+"\n");
            
            bw.write("-> mana formula \n");
            bw.write("(a+h)/2\n");
            
            
            bw.close();
            
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    public static void printResultToFile8Max (String [] rule, int id) {
        try {
            File file = new File ("../resultsEstatistica/id"+id+"/printResultToFile8Max.txt");
            if (!file.exists ()) {
                file.createNewFile ();
            }
            FileWriter fw = new FileWriter (file.getAbsoluteFile());
            BufferedWriter bw = new BufferedWriter (fw);
            
            
            bw.write("-> start mana points \n");
            bw.write("0\n");
            
            bw.write("-> max mana points \n");
            bw.write(Integer.parseInt(rule[0])+"\n");
            
            bw.write("-> mana rate \n");
            bw.write(Integer.parseInt(rule[1])+"\n");
            
            bw.write("-> life points \n");
            bw.write(Integer.parseInt(rule[2])+"\n");
            
            bw.write("-> max number of cards in the deck \n");
            bw.write(Integer.parseInt(rule[3])+"\n");
            
            bw.write("-> max number of cards in the hand \n");
            bw.write(Integer.parseInt(rule[4])+"\n");
            
            bw.write("-> max number of cards in the battlefield \n");
            bw.write(Integer.parseInt(rule[5])+"\n");
            
            bw.write("-> number of cards draw per turn \n");
            bw.write(Integer.parseInt(rule[6])+"\n");
            
            bw.write("-> number of cards in the first draw \n");
            bw.write("12\n");
            
            bw.write("-> max number of turns (0 for infinite turns) \n");
            bw.write("0\n");
            
            bw.write("-> number of the player 2 extra mana points in one round \n");
            bw.write(Integer.parseInt(rule[8])+"\n");
            
            bw.write("-> number of the player 2 extra cards in the first draw \n");
            bw.write(Integer.parseInt(rule[9])+"\n");
            
            bw.write("-> player 2 rules are the same as player 1? (1 for true, 0 for false) \n");
            bw.write("0\n");
            
            bw.write("-> number of simulations \n");
            bw.write("1000\n");
            
            bw.write("-> number of subsets of monsters \n");
            bw.write("1\n");
            
            bw.write("-> % of monsters in each subset \n");
            bw.write("100\n");
            
            bw.write("-> max monster damage(one per subset, each one in separate lines) \n");
            bw.write(Integer.parseInt(rule[10])+"\n");
            
            bw.write("-> min monster damage \n");
            bw.write("1\n");
            
            bw.write("-> % of cards with attack greater than the max \n");
            bw.write("0\n");
            
            bw.write("-> max out of curve attack \n");
            bw.write("0\n");
            
            bw.write("-> max monster health \n");
            bw.write(Integer.parseInt(rule[11])+"\n");
            
            bw.write("-> min monster health \n");
            bw.write("1\n");
            
            bw.write("-> attack twice per turn (0 for subsets without this rule and 1 for subsets with this rule) \n");
            bw.write(Integer.parseInt(rule[12])+"\n");
            
            bw.write("-> attack in the same turn it was summoned (0 for subsets without this rule and 1 for subsets with this rule) \n");
            bw.write(Integer.parseInt(rule[13])+"\n");
            
            bw.write("-> enemy player must target cards with this rule (0 for subsets without this rule and 1 for subsets with this rule) \n");
            bw.write(Integer.parseInt(rule[14])+"\n");
            
            bw.write("-> cards with this rule will only last X rounds (0 for subsets without this rule and X for the subsets with this rule. X represents the number of rounds) \n");
            bw.write("0\n");//teste
            
            bw.write("-> cards with this rule cannot be target (0 for subsets without this rule and 1 for subsets with this rule) \n");
            bw.write(Integer.parseInt(rule[15])+"\n");
            
            bw.write("-> mana formula \n");
            bw.write("(a+h)/2\n");
            
            
            bw.close();
            
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    public static void printResultToFile9Min (String [] rule, int id) {
        try {
            File file = new File ("../resultsEstatistica/id"+id+"/printResultToFile9Min.txt");
            if (!file.exists ()) {
                file.createNewFile ();
            }
            FileWriter fw = new FileWriter (file.getAbsoluteFile());
            BufferedWriter bw = new BufferedWriter (fw);
            
            
            bw.write("-> start mana points \n");
            bw.write("0\n");
            
            bw.write("-> max mana points \n");
            bw.write(Integer.parseInt(rule[0])+"\n");
            
            bw.write("-> mana rate \n");
            bw.write(Integer.parseInt(rule[1])+"\n");
            
            bw.write("-> life points \n");
            bw.write(Integer.parseInt(rule[2])+"\n");
            
            bw.write("-> max number of cards in the deck \n");
            bw.write(Integer.parseInt(rule[3])+"\n");
            
            bw.write("-> max number of cards in the hand \n");
            bw.write(Integer.parseInt(rule[4])+"\n");
            
            bw.write("-> max number of cards in the battlefield \n");
            bw.write(Integer.parseInt(rule[5])+"\n");
            
            bw.write("-> number of cards draw per turn \n");
            bw.write(Integer.parseInt(rule[6])+"\n");
            
            bw.write("-> number of cards in the first draw \n");
            bw.write(Integer.parseInt(rule[7])+"\n");
            
            bw.write("-> max number of turns (0 for infinite turns) \n");
            bw.write("0\n");
            
            bw.write("-> number of the player 2 extra mana points in one round \n");
            bw.write("0\n");
            
            bw.write("-> number of the player 2 extra cards in the first draw \n");
            bw.write(Integer.parseInt(rule[9])+"\n");
            
            bw.write("-> player 2 rules are the same as player 1? (1 for true, 0 for false) \n");
            bw.write("0\n");
            
            bw.write("-> number of simulations \n");
            bw.write("1000\n");
            
            bw.write("-> number of subsets of monsters \n");
            bw.write("1\n");
            
            bw.write("-> % of monsters in each subset \n");
            bw.write("100\n");
            
            bw.write("-> max monster damage(one per subset, each one in separate lines) \n");
            bw.write(Integer.parseInt(rule[10])+"\n");
            
            bw.write("-> min monster damage \n");
            bw.write("1\n");
            
            bw.write("-> % of cards with attack greater than the max \n");
            bw.write("0\n");
            
            bw.write("-> max out of curve attack \n");
            bw.write("0\n");
            
            bw.write("-> max monster health \n");
            bw.write(Integer.parseInt(rule[11])+"\n");
            
            bw.write("-> min monster health \n");
            bw.write("1\n");
            
            bw.write("-> attack twice per turn (0 for subsets without this rule and 1 for subsets with this rule) \n");
            bw.write(Integer.parseInt(rule[12])+"\n");
            
            bw.write("-> attack in the same turn it was summoned (0 for subsets without this rule and 1 for subsets with this rule) \n");
            bw.write(Integer.parseInt(rule[13])+"\n");
            
            bw.write("-> enemy player must target cards with this rule (0 for subsets without this rule and 1 for subsets with this rule) \n");
            bw.write(Integer.parseInt(rule[14])+"\n");
            
            bw.write("-> cards with this rule will only last X rounds (0 for subsets without this rule and X for the subsets with this rule. X represents the number of rounds) \n");
            bw.write("0\n");//teste
            
            bw.write("-> cards with this rule cannot be target (0 for subsets without this rule and 1 for subsets with this rule) \n");
            bw.write(Integer.parseInt(rule[15])+"\n");
            
            bw.write("-> mana formula \n");
            bw.write("(a+h)/2\n");
            
            
            bw.close();
            
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    public static void printResultToFile9Max (String [] rule, int id) {
        try {
            File file = new File ("../resultsEstatistica/id"+id+"/printResultToFile9Max.txt");
            if (!file.exists ()) {
                file.createNewFile ();
            }
            FileWriter fw = new FileWriter (file.getAbsoluteFile());
            BufferedWriter bw = new BufferedWriter (fw);
            
            
            bw.write("-> start mana points \n");
            bw.write("0\n");
            
            bw.write("-> max mana points \n");
            bw.write(Integer.parseInt(rule[0])+"\n");
            
            bw.write("-> mana rate \n");
            bw.write(Integer.parseInt(rule[1])+"\n");
            
            bw.write("-> life points \n");
            bw.write(Integer.parseInt(rule[2])+"\n");
            
            bw.write("-> max number of cards in the deck \n");
            bw.write(Integer.parseInt(rule[3])+"\n");
            
            bw.write("-> max number of cards in the hand \n");
            bw.write(Integer.parseInt(rule[4])+"\n");
            
            bw.write("-> max number of cards in the battlefield \n");
            bw.write(Integer.parseInt(rule[5])+"\n");
            
            bw.write("-> number of cards draw per turn \n");
            bw.write(Integer.parseInt(rule[6])+"\n");
            
            bw.write("-> number of cards in the first draw \n");
            bw.write(Integer.parseInt(rule[7])+"\n");
            
            bw.write("-> max number of turns (0 for infinite turns) \n");
            bw.write("0\n");
            
            bw.write("-> number of the player 2 extra mana points in one round \n");
            bw.write("9\n");
            
            bw.write("-> number of the player 2 extra cards in the first draw \n");
            bw.write(Integer.parseInt(rule[9])+"\n");
            
            bw.write("-> player 2 rules are the same as player 1? (1 for true, 0 for false) \n");
            bw.write("0\n");
            
            bw.write("-> number of simulations \n");
            bw.write("1000\n");
            
            bw.write("-> number of subsets of monsters \n");
            bw.write("1\n");
            
            bw.write("-> % of monsters in each subset \n");
            bw.write("100\n");
            
            bw.write("-> max monster damage(one per subset, each one in separate lines) \n");
            bw.write(Integer.parseInt(rule[10])+"\n");
            
            bw.write("-> min monster damage \n");
            bw.write("1\n");
            
            bw.write("-> % of cards with attack greater than the max \n");
            bw.write("0\n");
            
            bw.write("-> max out of curve attack \n");
            bw.write("0\n");
            
            bw.write("-> max monster health \n");
            bw.write(Integer.parseInt(rule[11])+"\n");
            
            bw.write("-> min monster health \n");
            bw.write("1\n");
            
            bw.write("-> attack twice per turn (0 for subsets without this rule and 1 for subsets with this rule) \n");
            bw.write(Integer.parseInt(rule[12])+"\n");
            
            bw.write("-> attack in the same turn it was summoned (0 for subsets without this rule and 1 for subsets with this rule) \n");
            bw.write(Integer.parseInt(rule[13])+"\n");
            
            bw.write("-> enemy player must target cards with this rule (0 for subsets without this rule and 1 for subsets with this rule) \n");
            bw.write(Integer.parseInt(rule[14])+"\n");
            
            bw.write("-> cards with this rule will only last X rounds (0 for subsets without this rule and X for the subsets with this rule. X represents the number of rounds) \n");
            bw.write("0\n");//teste
            
            bw.write("-> cards with this rule cannot be target (0 for subsets without this rule and 1 for subsets with this rule) \n");
            bw.write(Integer.parseInt(rule[15])+"\n");
            
            bw.write("-> mana formula \n");
            bw.write("(a+h)/2\n");
            
            
            bw.close();
            
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    public static void printResultToFile10Min (String [] rule, int id) {
        try {
            File file = new File ("../resultsEstatistica/id"+id+"/printResultToFile10Min.txt");
            if (!file.exists ()) {
                file.createNewFile ();
            }
            FileWriter fw = new FileWriter (file.getAbsoluteFile());
            BufferedWriter bw = new BufferedWriter (fw);
            
            
            bw.write("-> start mana points \n");
            bw.write("0\n");
            
            bw.write("-> max mana points \n");
            bw.write(Integer.parseInt(rule[0])+"\n");
            
            bw.write("-> mana rate \n");
            bw.write(Integer.parseInt(rule[1])+"\n");
            
            bw.write("-> life points \n");
            bw.write(Integer.parseInt(rule[2])+"\n");
            
            bw.write("-> max number of cards in the deck \n");
            bw.write(Integer.parseInt(rule[3])+"\n");
            
            bw.write("-> max number of cards in the hand \n");
            bw.write(Integer.parseInt(rule[4])+"\n");
            
            bw.write("-> max number of cards in the battlefield \n");
            bw.write(Integer.parseInt(rule[5])+"\n");
            
            bw.write("-> number of cards draw per turn \n");
            bw.write(Integer.parseInt(rule[6])+"\n");
            
            bw.write("-> number of cards in the first draw \n");
            bw.write(Integer.parseInt(rule[7])+"\n");
            
            bw.write("-> max number of turns (0 for infinite turns) \n");
            bw.write("0\n");
            
            bw.write("-> number of the player 2 extra mana points in one round \n");
            bw.write(Integer.parseInt(rule[8])+"\n");
            
            bw.write("-> number of the player 2 extra cards in the first draw \n");
            bw.write("0\n");
            
            bw.write("-> player 2 rules are the same as player 1? (1 for true, 0 for false) \n");
            bw.write("0\n");
            
            bw.write("-> number of simulations \n");
            bw.write("1000\n");
            
            bw.write("-> number of subsets of monsters \n");
            bw.write("1\n");
            
            bw.write("-> % of monsters in each subset \n");
            bw.write("100\n");
            
            bw.write("-> max monster damage(one per subset, each one in separate lines) \n");
            bw.write(Integer.parseInt(rule[10])+"\n");
            
            bw.write("-> min monster damage \n");
            bw.write("1\n");
            
            bw.write("-> % of cards with attack greater than the max \n");
            bw.write("0\n");
            
            bw.write("-> max out of curve attack \n");
            bw.write("0\n");
            
            bw.write("-> max monster health \n");
            bw.write(Integer.parseInt(rule[11])+"\n");
            
            bw.write("-> min monster health \n");
            bw.write("1\n");
            
            bw.write("-> attack twice per turn (0 for subsets without this rule and 1 for subsets with this rule) \n");
            bw.write(Integer.parseInt(rule[12])+"\n");
            
            bw.write("-> attack in the same turn it was summoned (0 for subsets without this rule and 1 for subsets with this rule) \n");
            bw.write(Integer.parseInt(rule[13])+"\n");
            
            bw.write("-> enemy player must target cards with this rule (0 for subsets without this rule and 1 for subsets with this rule) \n");
            bw.write(Integer.parseInt(rule[14])+"\n");
            
            bw.write("-> cards with this rule will only last X rounds (0 for subsets without this rule and X for the subsets with this rule. X represents the number of rounds) \n");
            bw.write("0\n");//teste
            
            bw.write("-> cards with this rule cannot be target (0 for subsets without this rule and 1 for subsets with this rule) \n");
            bw.write(Integer.parseInt(rule[15])+"\n");
            
            bw.write("-> mana formula \n");
            bw.write("(a+h)/2\n");
            
            
            bw.close();
            
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    public static void printResultToFile10Max (String [] rule, int id) {
        try {
            File file = new File ("../resultsEstatistica/id"+id+"/printResultToFile10Max.txt");
            if (!file.exists ()) {
                file.createNewFile ();
            }
            FileWriter fw = new FileWriter (file.getAbsoluteFile());
            BufferedWriter bw = new BufferedWriter (fw);
            
            
            bw.write("-> start mana points \n");
            bw.write("0\n");
            
            bw.write("-> max mana points \n");
            bw.write(Integer.parseInt(rule[0])+"\n");
            
            bw.write("-> mana rate \n");
            bw.write(Integer.parseInt(rule[1])+"\n");
            
            bw.write("-> life points \n");
            bw.write(Integer.parseInt(rule[2])+"\n");
            
            bw.write("-> max number of cards in the deck \n");
            bw.write(Integer.parseInt(rule[3])+"\n");
            
            bw.write("-> max number of cards in the hand \n");
            bw.write(Integer.parseInt(rule[4])+"\n");
            
            bw.write("-> max number of cards in the battlefield \n");
            bw.write(Integer.parseInt(rule[5])+"\n");
            
            bw.write("-> number of cards draw per turn \n");
            bw.write(Integer.parseInt(rule[6])+"\n");
            
            bw.write("-> number of cards in the first draw \n");
            bw.write(Integer.parseInt(rule[7])+"\n");
            
            bw.write("-> max number of turns (0 for infinite turns) \n");
            bw.write("0\n");
            
            bw.write("-> number of the player 2 extra mana points in one round \n");
            bw.write(Integer.parseInt(rule[8])+"\n");
            
            bw.write("-> number of the player 2 extra cards in the first draw \n");
            bw.write("4\n");
            
            bw.write("-> player 2 rules are the same as player 1? (1 for true, 0 for false) \n");
            bw.write("0\n");
            
            bw.write("-> number of simulations \n");
            bw.write("1000\n");
            
            bw.write("-> number of subsets of monsters \n");
            bw.write("1\n");
            
            bw.write("-> % of monsters in each subset \n");
            bw.write("100\n");
            
            bw.write("-> max monster damage(one per subset, each one in separate lines) \n");
            bw.write(Integer.parseInt(rule[10])+"\n");
            
            bw.write("-> min monster damage \n");
            bw.write("1\n");
            
            bw.write("-> % of cards with attack greater than the max \n");
            bw.write("0\n");
            
            bw.write("-> max out of curve attack \n");
            bw.write("0\n");
            
            bw.write("-> max monster health \n");
            bw.write(Integer.parseInt(rule[11])+"\n");
            
            bw.write("-> min monster health \n");
            bw.write("1\n");
            
            bw.write("-> attack twice per turn (0 for subsets without this rule and 1 for subsets with this rule) \n");
            bw.write(Integer.parseInt(rule[12])+"\n");
            
            bw.write("-> attack in the same turn it was summoned (0 for subsets without this rule and 1 for subsets with this rule) \n");
            bw.write(Integer.parseInt(rule[13])+"\n");
            
            bw.write("-> enemy player must target cards with this rule (0 for subsets without this rule and 1 for subsets with this rule) \n");
            bw.write(Integer.parseInt(rule[14])+"\n");
            
            bw.write("-> cards with this rule will only last X rounds (0 for subsets without this rule and X for the subsets with this rule. X represents the number of rounds) \n");
            bw.write("0\n");//teste
            
            bw.write("-> cards with this rule cannot be target (0 for subsets without this rule and 1 for subsets with this rule) \n");
            bw.write(Integer.parseInt(rule[15])+"\n");
            
            bw.write("-> mana formula \n");
            bw.write("(a+h)/2\n");
            
            
            bw.close();
            
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    public static void printResultToFile11Min (String [] rule, int id) {
        try {
            File file = new File ("../resultsEstatistica/id"+id+"/printResultToFile11Min.txt");
            if (!file.exists ()) {
                file.createNewFile ();
            }
            FileWriter fw = new FileWriter (file.getAbsoluteFile());
            BufferedWriter bw = new BufferedWriter (fw);
            
            
            bw.write("-> start mana points \n");
            bw.write("0\n");
            
            bw.write("-> max mana points \n");
            bw.write(Integer.parseInt(rule[0])+"\n");
            
            bw.write("-> mana rate \n");
            bw.write(Integer.parseInt(rule[1])+"\n");
            
            bw.write("-> life points \n");
            bw.write(Integer.parseInt(rule[2])+"\n");
            
            bw.write("-> max number of cards in the deck \n");
            bw.write(Integer.parseInt(rule[3])+"\n");
            
            bw.write("-> max number of cards in the hand \n");
            bw.write(Integer.parseInt(rule[4])+"\n");
            
            bw.write("-> max number of cards in the battlefield \n");
            bw.write(Integer.parseInt(rule[5])+"\n");
            
            bw.write("-> number of cards draw per turn \n");
            bw.write(Integer.parseInt(rule[6])+"\n");
            
            bw.write("-> number of cards in the first draw \n");
            bw.write(Integer.parseInt(rule[7])+"\n");
            
            bw.write("-> max number of turns (0 for infinite turns) \n");
            bw.write("0\n");
            
            bw.write("-> number of the player 2 extra mana points in one round \n");
            bw.write(Integer.parseInt(rule[8])+"\n");
            
            bw.write("-> number of the player 2 extra cards in the first draw \n");
            bw.write(Integer.parseInt(rule[9])+"\n");
            
            bw.write("-> player 2 rules are the same as player 1? (1 for true, 0 for false) \n");
            bw.write("0\n");
            
            bw.write("-> number of simulations \n");
            bw.write("1000\n");
            
            bw.write("-> number of subsets of monsters \n");
            bw.write("1\n");
            
            bw.write("-> % of monsters in each subset \n");
            bw.write("100\n");
            
            bw.write("-> max monster damage(one per subset, each one in separate lines) \n");
            bw.write("4\n");
            
            bw.write("-> min monster damage \n");
            bw.write("1\n");
            
            bw.write("-> % of cards with attack greater than the max \n");
            bw.write("0\n");
            
            bw.write("-> max out of curve attack \n");
            bw.write("0\n");
            
            bw.write("-> max monster health \n");
            bw.write(Integer.parseInt(rule[11])+"\n");
            
            bw.write("-> min monster health \n");
            bw.write("1\n");
            
            bw.write("-> attack twice per turn (0 for subsets without this rule and 1 for subsets with this rule) \n");
            bw.write(Integer.parseInt(rule[12])+"\n");
            
            bw.write("-> attack in the same turn it was summoned (0 for subsets without this rule and 1 for subsets with this rule) \n");
            bw.write(Integer.parseInt(rule[13])+"\n");
            
            bw.write("-> enemy player must target cards with this rule (0 for subsets without this rule and 1 for subsets with this rule) \n");
            bw.write(Integer.parseInt(rule[14])+"\n");
            
            bw.write("-> cards with this rule will only last X rounds (0 for subsets without this rule and X for the subsets with this rule. X represents the number of rounds) \n");
            bw.write("0\n");//teste
            
            bw.write("-> cards with this rule cannot be target (0 for subsets without this rule and 1 for subsets with this rule) \n");
            bw.write(Integer.parseInt(rule[15])+"\n");
            
            bw.write("-> mana formula \n");
            bw.write("(a+h)/2\n");
            
            
            bw.close();
            
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    public static void printResultToFile11Max (String [] rule, int id) {
        try {
            File file = new File ("../resultsEstatistica/id"+id+"/printResultToFile11Max.txt");
            if (!file.exists ()) {
                file.createNewFile ();
            }
            FileWriter fw = new FileWriter (file.getAbsoluteFile());
            BufferedWriter bw = new BufferedWriter (fw);
            
            
            bw.write("-> start mana points \n");
            bw.write("0\n");
            
            bw.write("-> max mana points \n");
            bw.write(Integer.parseInt(rule[0])+"\n");
            
            bw.write("-> mana rate \n");
            bw.write(Integer.parseInt(rule[1])+"\n");
            
            bw.write("-> life points \n");
            bw.write(Integer.parseInt(rule[2])+"\n");
            
            bw.write("-> max number of cards in the deck \n");
            bw.write(Integer.parseInt(rule[3])+"\n");
            
            bw.write("-> max number of cards in the hand \n");
            bw.write(Integer.parseInt(rule[4])+"\n");
            
            bw.write("-> max number of cards in the battlefield \n");
            bw.write(Integer.parseInt(rule[5])+"\n");
            
            bw.write("-> number of cards draw per turn \n");
            bw.write(Integer.parseInt(rule[6])+"\n");
            
            bw.write("-> number of cards in the first draw \n");
            bw.write(Integer.parseInt(rule[7])+"\n");
            
            bw.write("-> max number of turns (0 for infinite turns) \n");
            bw.write("0\n");
            
            bw.write("-> number of the player 2 extra mana points in one round \n");
            bw.write(Integer.parseInt(rule[8])+"\n");
            
            bw.write("-> number of the player 2 extra cards in the first draw \n");
            bw.write(Integer.parseInt(rule[9])+"\n");
            
            bw.write("-> player 2 rules are the same as player 1? (1 for true, 0 for false) \n");
            bw.write("0\n");
            
            bw.write("-> number of simulations \n");
            bw.write("1000\n");
            
            bw.write("-> number of subsets of monsters \n");
            bw.write("1\n");
            
            bw.write("-> % of monsters in each subset \n");
            bw.write("100\n");
            
            bw.write("-> max monster damage(one per subset, each one in separate lines) \n");
            bw.write("22\n");
            
            bw.write("-> min monster damage \n");
            bw.write("1\n");
            
            bw.write("-> % of cards with attack greater than the max \n");
            bw.write("0\n");
            
            bw.write("-> max out of curve attack \n");
            bw.write("0\n");
            
            bw.write("-> max monster health \n");
            bw.write(Integer.parseInt(rule[11])+"\n");
            
            bw.write("-> min monster health \n");
            bw.write("1\n");
            
            bw.write("-> attack twice per turn (0 for subsets without this rule and 1 for subsets with this rule) \n");
            bw.write(Integer.parseInt(rule[12])+"\n");
            
            bw.write("-> attack in the same turn it was summoned (0 for subsets without this rule and 1 for subsets with this rule) \n");
            bw.write(Integer.parseInt(rule[13])+"\n");
            
            bw.write("-> enemy player must target cards with this rule (0 for subsets without this rule and 1 for subsets with this rule) \n");
            bw.write(Integer.parseInt(rule[14])+"\n");
            
            bw.write("-> cards with this rule will only last X rounds (0 for subsets without this rule and X for the subsets with this rule. X represents the number of rounds) \n");
            bw.write("0\n");//teste
            
            bw.write("-> cards with this rule cannot be target (0 for subsets without this rule and 1 for subsets with this rule) \n");
            bw.write(Integer.parseInt(rule[15])+"\n");
            
            bw.write("-> mana formula \n");
            bw.write("(a+h)/2\n");
            
            
            bw.close();
            
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    public static void printResultToFile12Min (String [] rule, int id) {
        try {
            File file = new File ("../resultsEstatistica/id"+id+"/printResultToFile12Min.txt");
            if (!file.exists ()) {
                file.createNewFile ();
            }
            FileWriter fw = new FileWriter (file.getAbsoluteFile());
            BufferedWriter bw = new BufferedWriter (fw);
            
            
            bw.write("-> start mana points \n");
            bw.write("0\n");
            
            bw.write("-> max mana points \n");
            bw.write(Integer.parseInt(rule[0])+"\n");
            
            bw.write("-> mana rate \n");
            bw.write(Integer.parseInt(rule[1])+"\n");
            
            bw.write("-> life points \n");
            bw.write(Integer.parseInt(rule[2])+"\n");
            
            bw.write("-> max number of cards in the deck \n");
            bw.write(Integer.parseInt(rule[3])+"\n");
            
            bw.write("-> max number of cards in the hand \n");
            bw.write(Integer.parseInt(rule[4])+"\n");
            
            bw.write("-> max number of cards in the battlefield \n");
            bw.write(Integer.parseInt(rule[5])+"\n");
            
            bw.write("-> number of cards draw per turn \n");
            bw.write(Integer.parseInt(rule[6])+"\n");
            
            bw.write("-> number of cards in the first draw \n");
            bw.write(Integer.parseInt(rule[7])+"\n");
            
            bw.write("-> max number of turns (0 for infinite turns) \n");
            bw.write("0\n");
            
            bw.write("-> number of the player 2 extra mana points in one round \n");
            bw.write(Integer.parseInt(rule[8])+"\n");
            
            bw.write("-> number of the player 2 extra cards in the first draw \n");
            bw.write(Integer.parseInt(rule[9])+"\n");
            
            bw.write("-> player 2 rules are the same as player 1? (1 for true, 0 for false) \n");
            bw.write("0\n");
            
            bw.write("-> number of simulations \n");
            bw.write("1000\n");
            
            bw.write("-> number of subsets of monsters \n");
            bw.write("1\n");
            
            bw.write("-> % of monsters in each subset \n");
            bw.write("100\n");
            
            bw.write("-> max monster damage(one per subset, each one in separate lines) \n");
            bw.write(Integer.parseInt(rule[10])+"\n");
            
            bw.write("-> min monster damage \n");
            bw.write("1\n");
            
            bw.write("-> % of cards with attack greater than the max \n");
            bw.write("0\n");
            
            bw.write("-> max out of curve attack \n");
            bw.write("0\n");
            
            bw.write("-> max monster health \n");
            bw.write("4\n");
            
            bw.write("-> min monster health \n");
            bw.write("1\n");
            
            bw.write("-> attack twice per turn (0 for subsets without this rule and 1 for subsets with this rule) \n");
            bw.write(Integer.parseInt(rule[12])+"\n");
            
            bw.write("-> attack in the same turn it was summoned (0 for subsets without this rule and 1 for subsets with this rule) \n");
            bw.write(Integer.parseInt(rule[13])+"\n");
            
            bw.write("-> enemy player must target cards with this rule (0 for subsets without this rule and 1 for subsets with this rule) \n");
            bw.write(Integer.parseInt(rule[14])+"\n");
            
            bw.write("-> cards with this rule will only last X rounds (0 for subsets without this rule and X for the subsets with this rule. X represents the number of rounds) \n");
            bw.write("0\n");//teste
            
            bw.write("-> cards with this rule cannot be target (0 for subsets without this rule and 1 for subsets with this rule) \n");
            bw.write(Integer.parseInt(rule[15])+"\n");
            
            bw.write("-> mana formula \n");
            bw.write("(a+h)/2\n");
            
            
            bw.close();
            
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    public static void printResultToFile12Max (String [] rule, int id) {
        try {
            File file = new File ("../resultsEstatistica/id"+id+"/printResultToFile12Max.txt");
            if (!file.exists ()) {
                file.createNewFile ();
            }
            FileWriter fw = new FileWriter (file.getAbsoluteFile());
            BufferedWriter bw = new BufferedWriter (fw);
            
            
            bw.write("-> start mana points \n");
            bw.write("0\n");
            
            bw.write("-> max mana points \n");
            bw.write(Integer.parseInt(rule[0])+"\n");
            
            bw.write("-> mana rate \n");
            bw.write(Integer.parseInt(rule[1])+"\n");
            
            bw.write("-> life points \n");
            bw.write(Integer.parseInt(rule[2])+"\n");
            
            bw.write("-> max number of cards in the deck \n");
            bw.write(Integer.parseInt(rule[3])+"\n");
            
            bw.write("-> max number of cards in the hand \n");
            bw.write(Integer.parseInt(rule[4])+"\n");
            
            bw.write("-> max number of cards in the battlefield \n");
            bw.write(Integer.parseInt(rule[5])+"\n");
            
            bw.write("-> number of cards draw per turn \n");
            bw.write(Integer.parseInt(rule[6])+"\n");
            
            bw.write("-> number of cards in the first draw \n");
            bw.write(Integer.parseInt(rule[7])+"\n");
            
            bw.write("-> max number of turns (0 for infinite turns) \n");
            bw.write("0\n");
            
            bw.write("-> number of the player 2 extra mana points in one round \n");
            bw.write(Integer.parseInt(rule[8])+"\n");
            
            bw.write("-> number of the player 2 extra cards in the first draw \n");
            bw.write(Integer.parseInt(rule[9])+"\n");
            
            bw.write("-> player 2 rules are the same as player 1? (1 for true, 0 for false) \n");
            bw.write("0\n");
            
            bw.write("-> number of simulations \n");
            bw.write("1000\n");
            
            bw.write("-> number of subsets of monsters \n");
            bw.write("1\n");
            
            bw.write("-> % of monsters in each subset \n");
            bw.write("100\n");
            
            bw.write("-> max monster damage(one per subset, each one in separate lines) \n");
            bw.write(Integer.parseInt(rule[10])+"\n");
            
            bw.write("-> min monster damage \n");
            bw.write("1\n");
            
            bw.write("-> % of cards with attack greater than the max \n");
            bw.write("0\n");
            
            bw.write("-> max out of curve attack \n");
            bw.write("0\n");
            
            bw.write("-> max monster health \n");
            bw.write("22\n");
            
            bw.write("-> min monster health \n");
            bw.write("1\n");
            
            bw.write("-> attack twice per turn (0 for subsets without this rule and 1 for subsets with this rule) \n");
            bw.write(Integer.parseInt(rule[12])+"\n");
            
            bw.write("-> attack in the same turn it was summoned (0 for subsets without this rule and 1 for subsets with this rule) \n");
            bw.write(Integer.parseInt(rule[13])+"\n");
            
            bw.write("-> enemy player must target cards with this rule (0 for subsets without this rule and 1 for subsets with this rule) \n");
            bw.write(Integer.parseInt(rule[14])+"\n");
            
            bw.write("-> cards with this rule will only last X rounds (0 for subsets without this rule and X for the subsets with this rule. X represents the number of rounds) \n");
            bw.write("0\n");//teste
            
            bw.write("-> cards with this rule cannot be target (0 for subsets without this rule and 1 for subsets with this rule) \n");
            bw.write(Integer.parseInt(rule[15])+"\n");
            
            bw.write("-> mana formula \n");
            bw.write("(a+h)/2\n");
            
            
            bw.close();
            
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    public static void printResultToFile13Min (String [] rule, int id) {
        try {
            File file = new File ("../resultsEstatistica/id"+id+"/printResultToFile13Min.txt");
            if (!file.exists ()) {
                file.createNewFile ();
            }
            FileWriter fw = new FileWriter (file.getAbsoluteFile());
            BufferedWriter bw = new BufferedWriter (fw);
            
            
            bw.write("-> start mana points \n");
            bw.write("0\n");
            
            bw.write("-> max mana points \n");
            bw.write(Integer.parseInt(rule[0])+"\n");
            
            bw.write("-> mana rate \n");
            bw.write(Integer.parseInt(rule[1])+"\n");
            
            bw.write("-> life points \n");
            bw.write(Integer.parseInt(rule[2])+"\n");
            
            bw.write("-> max number of cards in the deck \n");
            bw.write(Integer.parseInt(rule[3])+"\n");
            
            bw.write("-> max number of cards in the hand \n");
            bw.write(Integer.parseInt(rule[4])+"\n");
            
            bw.write("-> max number of cards in the battlefield \n");
            bw.write(Integer.parseInt(rule[5])+"\n");
            
            bw.write("-> number of cards draw per turn \n");
            bw.write(Integer.parseInt(rule[6])+"\n");
            
            bw.write("-> number of cards in the first draw \n");
            bw.write(Integer.parseInt(rule[7])+"\n");
            
            bw.write("-> max number of turns (0 for infinite turns) \n");
            bw.write("0\n");
            
            bw.write("-> number of the player 2 extra mana points in one round \n");
            bw.write(Integer.parseInt(rule[8])+"\n");
            
            bw.write("-> number of the player 2 extra cards in the first draw \n");
            bw.write(Integer.parseInt(rule[9])+"\n");
            
            bw.write("-> player 2 rules are the same as player 1? (1 for true, 0 for false) \n");
            bw.write("0\n");
            
            bw.write("-> number of simulations \n");
            bw.write("1000\n");
            
            bw.write("-> number of subsets of monsters \n");
            bw.write("1\n");
            
            bw.write("-> % of monsters in each subset \n");
            bw.write("100\n");
            
            bw.write("-> max monster damage(one per subset, each one in separate lines) \n");
            bw.write(Integer.parseInt(rule[10])+"\n");
            
            bw.write("-> min monster damage \n");
            bw.write("1\n");
            
            bw.write("-> % of cards with attack greater than the max \n");
            bw.write("0\n");
            
            bw.write("-> max out of curve attack \n");
            bw.write("0\n");
            
            bw.write("-> max monster health \n");
            bw.write(Integer.parseInt(rule[11])+"\n");
            
            bw.write("-> min monster health \n");
            bw.write("1\n");
            
            bw.write("-> attack twice per turn (0 for subsets without this rule and 1 for subsets with this rule) \n");
            bw.write("0\n");
            
            bw.write("-> attack in the same turn it was summoned (0 for subsets without this rule and 1 for subsets with this rule) \n");
            bw.write(Integer.parseInt(rule[13])+"\n");
            
            bw.write("-> enemy player must target cards with this rule (0 for subsets without this rule and 1 for subsets with this rule) \n");
            bw.write(Integer.parseInt(rule[14])+"\n");
            
            bw.write("-> cards with this rule will only last X rounds (0 for subsets without this rule and X for the subsets with this rule. X represents the number of rounds) \n");
            bw.write("0\n");//teste
            
            bw.write("-> cards with this rule cannot be target (0 for subsets without this rule and 1 for subsets with this rule) \n");
            bw.write(Integer.parseInt(rule[15])+"\n");
            
            bw.write("-> mana formula \n");
            bw.write("(a+h)/2\n");
            
            
            bw.close();
            
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    public static void printResultToFile13Max (String [] rule, int id) {
        try {
            File file = new File ("../resultsEstatistica/id"+id+"/printResultToFile13Max.txt");
            if (!file.exists ()) {
                file.createNewFile ();
            }
            FileWriter fw = new FileWriter (file.getAbsoluteFile());
            BufferedWriter bw = new BufferedWriter (fw);
            
            
            bw.write("-> start mana points \n");
            bw.write("0\n");
            
            bw.write("-> max mana points \n");
            bw.write(Integer.parseInt(rule[0])+"\n");
            
            bw.write("-> mana rate \n");
            bw.write(Integer.parseInt(rule[1])+"\n");
            
            bw.write("-> life points \n");
            bw.write(Integer.parseInt(rule[2])+"\n");
            
            bw.write("-> max number of cards in the deck \n");
            bw.write(Integer.parseInt(rule[3])+"\n");
            
            bw.write("-> max number of cards in the hand \n");
            bw.write(Integer.parseInt(rule[4])+"\n");
            
            bw.write("-> max number of cards in the battlefield \n");
            bw.write(Integer.parseInt(rule[5])+"\n");
            
            bw.write("-> number of cards draw per turn \n");
            bw.write(Integer.parseInt(rule[6])+"\n");
            
            bw.write("-> number of cards in the first draw \n");
            bw.write(Integer.parseInt(rule[7])+"\n");
            
            bw.write("-> max number of turns (0 for infinite turns) \n");
            bw.write("0\n");
            
            bw.write("-> number of the player 2 extra mana points in one round \n");
            bw.write(Integer.parseInt(rule[8])+"\n");
            
            bw.write("-> number of the player 2 extra cards in the first draw \n");
            bw.write(Integer.parseInt(rule[9])+"\n");
            
            bw.write("-> player 2 rules are the same as player 1? (1 for true, 0 for false) \n");
            bw.write("0\n");
            
            bw.write("-> number of simulations \n");
            bw.write("1000\n");
            
            bw.write("-> number of subsets of monsters \n");
            bw.write("1\n");
            
            bw.write("-> % of monsters in each subset \n");
            bw.write("100\n");
            
            bw.write("-> max monster damage(one per subset, each one in separate lines) \n");
            bw.write(Integer.parseInt(rule[10])+"\n");
            
            bw.write("-> min monster damage \n");
            bw.write("1\n");
            
            bw.write("-> % of cards with attack greater than the max \n");
            bw.write("0\n");
            
            bw.write("-> max out of curve attack \n");
            bw.write("0\n");
            
            bw.write("-> max monster health \n");
            bw.write(Integer.parseInt(rule[11])+"\n");
            
            bw.write("-> min monster health \n");
            bw.write("1\n");
            
            bw.write("-> attack twice per turn (0 for subsets without this rule and 1 for subsets with this rule) \n");
            bw.write("1\n");
            
            bw.write("-> attack in the same turn it was summoned (0 for subsets without this rule and 1 for subsets with this rule) \n");
            bw.write(Integer.parseInt(rule[13])+"\n");
            
            bw.write("-> enemy player must target cards with this rule (0 for subsets without this rule and 1 for subsets with this rule) \n");
            bw.write(Integer.parseInt(rule[14])+"\n");
            
            bw.write("-> cards with this rule will only last X rounds (0 for subsets without this rule and X for the subsets with this rule. X represents the number of rounds) \n");
            bw.write("0\n");//teste
            
            bw.write("-> cards with this rule cannot be target (0 for subsets without this rule and 1 for subsets with this rule) \n");
            bw.write(Integer.parseInt(rule[15])+"\n");
            
            bw.write("-> mana formula \n");
            bw.write("(a+h)/2\n");
            
            
            bw.close();
            
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    public static void printResultToFile14Min (String [] rule, int id) {
        try {
            File file = new File ("../resultsEstatistica/id"+id+"/printResultToFile14Min.txt");
            if (!file.exists ()) {
                file.createNewFile ();
            }
            FileWriter fw = new FileWriter (file.getAbsoluteFile());
            BufferedWriter bw = new BufferedWriter (fw);
            
            
            bw.write("-> start mana points \n");
            bw.write("0\n");
            
            bw.write("-> max mana points \n");
            bw.write(Integer.parseInt(rule[0])+"\n");
            
            bw.write("-> mana rate \n");
            bw.write(Integer.parseInt(rule[1])+"\n");
            
            bw.write("-> life points \n");
            bw.write(Integer.parseInt(rule[2])+"\n");
            
            bw.write("-> max number of cards in the deck \n");
            bw.write(Integer.parseInt(rule[3])+"\n");
            
            bw.write("-> max number of cards in the hand \n");
            bw.write(Integer.parseInt(rule[4])+"\n");
            
            bw.write("-> max number of cards in the battlefield \n");
            bw.write(Integer.parseInt(rule[5])+"\n");
            
            bw.write("-> number of cards draw per turn \n");
            bw.write(Integer.parseInt(rule[6])+"\n");
            
            bw.write("-> number of cards in the first draw \n");
            bw.write(Integer.parseInt(rule[7])+"\n");
            
            bw.write("-> max number of turns (0 for infinite turns) \n");
            bw.write("0\n");
            
            bw.write("-> number of the player 2 extra mana points in one round \n");
            bw.write(Integer.parseInt(rule[8])+"\n");
            
            bw.write("-> number of the player 2 extra cards in the first draw \n");
            bw.write(Integer.parseInt(rule[9])+"\n");
            
            bw.write("-> player 2 rules are the same as player 1? (1 for true, 0 for false) \n");
            bw.write("0\n");
            
            bw.write("-> number of simulations \n");
            bw.write("1000\n");
            
            bw.write("-> number of subsets of monsters \n");
            bw.write("1\n");
            
            bw.write("-> % of monsters in each subset \n");
            bw.write("100\n");
            
            bw.write("-> max monster damage(one per subset, each one in separate lines) \n");
            bw.write(Integer.parseInt(rule[10])+"\n");
            
            bw.write("-> min monster damage \n");
            bw.write("1\n");
            
            bw.write("-> % of cards with attack greater than the max \n");
            bw.write("0\n");
            
            bw.write("-> max out of curve attack \n");
            bw.write("0\n");
            
            bw.write("-> max monster health \n");
            bw.write(Integer.parseInt(rule[11])+"\n");
            
            bw.write("-> min monster health \n");
            bw.write("1\n");
            
            bw.write("-> attack twice per turn (0 for subsets without this rule and 1 for subsets with this rule) \n");
            bw.write(Integer.parseInt(rule[12])+"\n");
            
            bw.write("-> attack in the same turn it was summoned (0 for subsets without this rule and 1 for subsets with this rule) \n");
            bw.write("0\n");
            
            bw.write("-> enemy player must target cards with this rule (0 for subsets without this rule and 1 for subsets with this rule) \n");
            bw.write(Integer.parseInt(rule[14])+"\n");
            
            bw.write("-> cards with this rule will only last X rounds (0 for subsets without this rule and X for the subsets with this rule. X represents the number of rounds) \n");
            bw.write("0\n");//teste
            
            bw.write("-> cards with this rule cannot be target (0 for subsets without this rule and 1 for subsets with this rule) \n");
            bw.write(Integer.parseInt(rule[15])+"\n");
            
            bw.write("-> mana formula \n");
            bw.write("(a+h)/2\n");
            
            
            bw.close();
            
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    public static void printResultToFile14Max (String [] rule, int id) {
        try {
            File file = new File ("../resultsEstatistica/id"+id+"/printResultToFile14Max.txt");
            if (!file.exists ()) {
                file.createNewFile ();
            }
            FileWriter fw = new FileWriter (file.getAbsoluteFile());
            BufferedWriter bw = new BufferedWriter (fw);
            
            
            bw.write("-> start mana points \n");
            bw.write("0\n");
            
            bw.write("-> max mana points \n");
            bw.write(Integer.parseInt(rule[0])+"\n");
            
            bw.write("-> mana rate \n");
            bw.write(Integer.parseInt(rule[1])+"\n");
            
            bw.write("-> life points \n");
            bw.write(Integer.parseInt(rule[2])+"\n");
            
            bw.write("-> max number of cards in the deck \n");
            bw.write(Integer.parseInt(rule[3])+"\n");
            
            bw.write("-> max number of cards in the hand \n");
            bw.write(Integer.parseInt(rule[4])+"\n");
            
            bw.write("-> max number of cards in the battlefield \n");
            bw.write(Integer.parseInt(rule[5])+"\n");
            
            bw.write("-> number of cards draw per turn \n");
            bw.write(Integer.parseInt(rule[6])+"\n");
            
            bw.write("-> number of cards in the first draw \n");
            bw.write(Integer.parseInt(rule[7])+"\n");
            
            bw.write("-> max number of turns (0 for infinite turns) \n");
            bw.write("0\n");
            
            bw.write("-> number of the player 2 extra mana points in one round \n");
            bw.write(Integer.parseInt(rule[8])+"\n");
            
            bw.write("-> number of the player 2 extra cards in the first draw \n");
            bw.write(Integer.parseInt(rule[9])+"\n");
            
            bw.write("-> player 2 rules are the same as player 1? (1 for true, 0 for false) \n");
            bw.write("0\n");
            
            bw.write("-> number of simulations \n");
            bw.write("1000\n");
            
            bw.write("-> number of subsets of monsters \n");
            bw.write("1\n");
            
            bw.write("-> % of monsters in each subset \n");
            bw.write("100\n");
            
            bw.write("-> max monster damage(one per subset, each one in separate lines) \n");
            bw.write(Integer.parseInt(rule[10])+"\n");
            
            bw.write("-> min monster damage \n");
            bw.write("1\n");
            
            bw.write("-> % of cards with attack greater than the max \n");
            bw.write("0\n");
            
            bw.write("-> max out of curve attack \n");
            bw.write("0\n");
            
            bw.write("-> max monster health \n");
            bw.write(Integer.parseInt(rule[11])+"\n");
            
            bw.write("-> min monster health \n");
            bw.write("1\n");
            
            bw.write("-> attack twice per turn (0 for subsets without this rule and 1 for subsets with this rule) \n");
            bw.write(Integer.parseInt(rule[12])+"\n");
            
            bw.write("-> attack in the same turn it was summoned (0 for subsets without this rule and 1 for subsets with this rule) \n");
            bw.write("1\n");
            
            bw.write("-> enemy player must target cards with this rule (0 for subsets without this rule and 1 for subsets with this rule) \n");
            bw.write(Integer.parseInt(rule[14])+"\n");
            
            bw.write("-> cards with this rule will only last X rounds (0 for subsets without this rule and X for the subsets with this rule. X represents the number of rounds) \n");
            bw.write("0\n");//teste
            
            bw.write("-> cards with this rule cannot be target (0 for subsets without this rule and 1 for subsets with this rule) \n");
            bw.write(Integer.parseInt(rule[15])+"\n");
            
            bw.write("-> mana formula \n");
            bw.write("(a+h)/2\n");
            
            
            bw.close();
            
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    
    public static void printResultToFile15Min (String [] rule, int id) {
        try {
            File file = new File ("../resultsEstatistica/id"+id+"/printResultToFile15Min.txt");
            if (!file.exists ()) {
                file.createNewFile ();
            }
            FileWriter fw = new FileWriter (file.getAbsoluteFile());
            BufferedWriter bw = new BufferedWriter (fw);
            
            
            bw.write("-> start mana points \n");
            bw.write("0\n");
            
            bw.write("-> max mana points \n");
            bw.write(Integer.parseInt(rule[0])+"\n");
            
            bw.write("-> mana rate \n");
            bw.write(Integer.parseInt(rule[1])+"\n");
            
            bw.write("-> life points \n");
            bw.write(Integer.parseInt(rule[2])+"\n");
            
            bw.write("-> max number of cards in the deck \n");
            bw.write(Integer.parseInt(rule[3])+"\n");
            
            bw.write("-> max number of cards in the hand \n");
            bw.write(Integer.parseInt(rule[4])+"\n");
            
            bw.write("-> max number of cards in the battlefield \n");
            bw.write(Integer.parseInt(rule[5])+"\n");
            
            bw.write("-> number of cards draw per turn \n");
            bw.write(Integer.parseInt(rule[6])+"\n");
            
            bw.write("-> number of cards in the first draw \n");
            bw.write(Integer.parseInt(rule[7])+"\n");
            
            bw.write("-> max number of turns (0 for infinite turns) \n");
            bw.write("0\n");
            
            bw.write("-> number of the player 2 extra mana points in one round \n");
            bw.write(Integer.parseInt(rule[8])+"\n");
            
            bw.write("-> number of the player 2 extra cards in the first draw \n");
            bw.write(Integer.parseInt(rule[9])+"\n");
            
            bw.write("-> player 2 rules are the same as player 1? (1 for true, 0 for false) \n");
            bw.write("0\n");
            
            bw.write("-> number of simulations \n");
            bw.write("1000\n");
            
            bw.write("-> number of subsets of monsters \n");
            bw.write("1\n");
            
            bw.write("-> % of monsters in each subset \n");
            bw.write("100\n");
            
            bw.write("-> max monster damage(one per subset, each one in separate lines) \n");
            bw.write(Integer.parseInt(rule[10])+"\n");
            
            bw.write("-> min monster damage \n");
            bw.write("1\n");
            
            bw.write("-> % of cards with attack greater than the max \n");
            bw.write("0\n");
            
            bw.write("-> max out of curve attack \n");
            bw.write("0\n");
            
            bw.write("-> max monster health \n");
            bw.write(Integer.parseInt(rule[11])+"\n");
            
            bw.write("-> min monster health \n");
            bw.write("1\n");
            
            bw.write("-> attack twice per turn (0 for subsets without this rule and 1 for subsets with this rule) \n");
            bw.write(Integer.parseInt(rule[12])+"\n");
            
            bw.write("-> attack in the same turn it was summoned (0 for subsets without this rule and 1 for subsets with this rule) \n");
            bw.write(Integer.parseInt(rule[13])+"\n");
            
            bw.write("-> enemy player must target cards with this rule (0 for subsets without this rule and 1 for subsets with this rule) \n");
            bw.write("0\n");
            
            bw.write("-> cards with this rule will only last X rounds (0 for subsets without this rule and X for the subsets with this rule. X represents the number of rounds) \n");
            bw.write("0\n");//teste
            
            bw.write("-> cards with this rule cannot be target (0 for subsets without this rule and 1 for subsets with this rule) \n");
            bw.write(Integer.parseInt(rule[15])+"\n");
            
            bw.write("-> mana formula \n");
            bw.write("(a+h)/2\n");
            
            
            bw.close();
            
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    public static void printResultToFile15Max (String [] rule, int id) {
        try {
            File file = new File ("../resultsEstatistica/id"+id+"/printResultToFile15Max.txt");
            if (!file.exists ()) {
                file.createNewFile ();
            }
            FileWriter fw = new FileWriter (file.getAbsoluteFile());
            BufferedWriter bw = new BufferedWriter (fw);
            
            
            bw.write("-> start mana points \n");
            bw.write("0\n");
            
            bw.write("-> max mana points \n");
            bw.write(Integer.parseInt(rule[0])+"\n");
            
            bw.write("-> mana rate \n");
            bw.write(Integer.parseInt(rule[1])+"\n");
            
            bw.write("-> life points \n");
            bw.write(Integer.parseInt(rule[2])+"\n");
            
            bw.write("-> max number of cards in the deck \n");
            bw.write(Integer.parseInt(rule[3])+"\n");
            
            bw.write("-> max number of cards in the hand \n");
            bw.write(Integer.parseInt(rule[4])+"\n");
            
            bw.write("-> max number of cards in the battlefield \n");
            bw.write(Integer.parseInt(rule[5])+"\n");
            
            bw.write("-> number of cards draw per turn \n");
            bw.write(Integer.parseInt(rule[6])+"\n");
            
            bw.write("-> number of cards in the first draw \n");
            bw.write(Integer.parseInt(rule[7])+"\n");
            
            bw.write("-> max number of turns (0 for infinite turns) \n");
            bw.write("0\n");
            
            bw.write("-> number of the player 2 extra mana points in one round \n");
            bw.write(Integer.parseInt(rule[8])+"\n");
            
            bw.write("-> number of the player 2 extra cards in the first draw \n");
            bw.write(Integer.parseInt(rule[9])+"\n");
            
            bw.write("-> player 2 rules are the same as player 1? (1 for true, 0 for false) \n");
            bw.write("0\n");
            
            bw.write("-> number of simulations \n");
            bw.write("1000\n");
            
            bw.write("-> number of subsets of monsters \n");
            bw.write("1\n");
            
            bw.write("-> % of monsters in each subset \n");
            bw.write("100\n");
            
            bw.write("-> max monster damage(one per subset, each one in separate lines) \n");
            bw.write(Integer.parseInt(rule[10])+"\n");
            
            bw.write("-> min monster damage \n");
            bw.write("1\n");
            
            bw.write("-> % of cards with attack greater than the max \n");
            bw.write("0\n");
            
            bw.write("-> max out of curve attack \n");
            bw.write("0\n");
            
            bw.write("-> max monster health \n");
            bw.write(Integer.parseInt(rule[11])+"\n");
            
            bw.write("-> min monster health \n");
            bw.write("1\n");
            
            bw.write("-> attack twice per turn (0 for subsets without this rule and 1 for subsets with this rule) \n");
            bw.write(Integer.parseInt(rule[12])+"\n");
            
            bw.write("-> attack in the same turn it was summoned (0 for subsets without this rule and 1 for subsets with this rule) \n");
            bw.write(Integer.parseInt(rule[13])+"\n");
            
            bw.write("-> enemy player must target cards with this rule (0 for subsets without this rule and 1 for subsets with this rule) \n");
            bw.write("1\n");
            
            bw.write("-> cards with this rule will only last X rounds (0 for subsets without this rule and X for the subsets with this rule. X represents the number of rounds) \n");
            bw.write("0\n");//teste
            
            bw.write("-> cards with this rule cannot be target (0 for subsets without this rule and 1 for subsets with this rule) \n");
            bw.write(Integer.parseInt(rule[15])+"\n");
            
            bw.write("-> mana formula \n");
            bw.write("(a+h)/2\n");
            
            
            bw.close();
            
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    
    public static void printResultToFile16Min (String [] rule, int id) {
        try {
            File file = new File ("../resultsEstatistica/id"+id+"/printResultToFile16Min.txt");
            if (!file.exists ()) {
                file.createNewFile ();
            }
            FileWriter fw = new FileWriter (file.getAbsoluteFile());
            BufferedWriter bw = new BufferedWriter (fw);
            
            
            bw.write("-> start mana points \n");
            bw.write("0\n");
            
            bw.write("-> max mana points \n");
            bw.write(Integer.parseInt(rule[0])+"\n");
            
            bw.write("-> mana rate \n");
            bw.write(Integer.parseInt(rule[1])+"\n");
            
            bw.write("-> life points \n");
            bw.write(Integer.parseInt(rule[2])+"\n");
            
            bw.write("-> max number of cards in the deck \n");
            bw.write(Integer.parseInt(rule[3])+"\n");
            
            bw.write("-> max number of cards in the hand \n");
            bw.write(Integer.parseInt(rule[4])+"\n");
            
            bw.write("-> max number of cards in the battlefield \n");
            bw.write(Integer.parseInt(rule[5])+"\n");
            
            bw.write("-> number of cards draw per turn \n");
            bw.write(Integer.parseInt(rule[6])+"\n");
            
            bw.write("-> number of cards in the first draw \n");
            bw.write(Integer.parseInt(rule[7])+"\n");
            
            bw.write("-> max number of turns (0 for infinite turns) \n");
            bw.write("0\n");
            
            bw.write("-> number of the player 2 extra mana points in one round \n");
            bw.write(Integer.parseInt(rule[8])+"\n");
            
            bw.write("-> number of the player 2 extra cards in the first draw \n");
            bw.write(Integer.parseInt(rule[9])+"\n");
            
            bw.write("-> player 2 rules are the same as player 1? (1 for true, 0 for false) \n");
            bw.write("0\n");
            
            bw.write("-> number of simulations \n");
            bw.write("1000\n");
            
            bw.write("-> number of subsets of monsters \n");
            bw.write("1\n");
            
            bw.write("-> % of monsters in each subset \n");
            bw.write("100\n");
            
            bw.write("-> max monster damage(one per subset, each one in separate lines) \n");
            bw.write(Integer.parseInt(rule[10])+"\n");
            
            bw.write("-> min monster damage \n");
            bw.write("1\n");
            
            bw.write("-> % of cards with attack greater than the max \n");
            bw.write("0\n");
            
            bw.write("-> max out of curve attack \n");
            bw.write("0\n");
            
            bw.write("-> max monster health \n");
            bw.write(Integer.parseInt(rule[11])+"\n");
            
            bw.write("-> min monster health \n");
            bw.write("1\n");
            
            bw.write("-> attack twice per turn (0 for subsets without this rule and 1 for subsets with this rule) \n");
            bw.write(Integer.parseInt(rule[12])+"\n");
            
            bw.write("-> attack in the same turn it was summoned (0 for subsets without this rule and 1 for subsets with this rule) \n");
            bw.write(Integer.parseInt(rule[13])+"\n");
            
            bw.write("-> enemy player must target cards with this rule (0 for subsets without this rule and 1 for subsets with this rule) \n");
            bw.write(Integer.parseInt(rule[14])+"\n");
            
            bw.write("-> cards with this rule will only last X rounds (0 for subsets without this rule and X for the subsets with this rule. X represents the number of rounds) \n");
            bw.write("0\n");//teste
            
            bw.write("-> cards with this rule cannot be target (0 for subsets without this rule and 1 for subsets with this rule) \n");
            bw.write("0\n");
            
            bw.write("-> mana formula \n");
            bw.write("(a+h)/2\n");
            
            
            bw.close();
            
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    public static void printResultToFile16Max (String [] rule, int id) {
        try {
            File file = new File ("../resultsEstatistica/id"+id+"/printResultToFile16Max.txt");
            if (!file.exists ()) {
                file.createNewFile ();
            }
            FileWriter fw = new FileWriter (file.getAbsoluteFile());
            BufferedWriter bw = new BufferedWriter (fw);
            
            
            bw.write("-> start mana points \n");
            bw.write("0\n");
            
            bw.write("-> max mana points \n");
            bw.write(Integer.parseInt(rule[0])+"\n");
            
            bw.write("-> mana rate \n");
            bw.write(Integer.parseInt(rule[1])+"\n");
            
            bw.write("-> life points \n");
            bw.write(Integer.parseInt(rule[2])+"\n");
            
            bw.write("-> max number of cards in the deck \n");
            bw.write(Integer.parseInt(rule[3])+"\n");
            
            bw.write("-> max number of cards in the hand \n");
            bw.write(Integer.parseInt(rule[4])+"\n");
            
            bw.write("-> max number of cards in the battlefield \n");
            bw.write(Integer.parseInt(rule[5])+"\n");
            
            bw.write("-> number of cards draw per turn \n");
            bw.write(Integer.parseInt(rule[6])+"\n");
            
            bw.write("-> number of cards in the first draw \n");
            bw.write(Integer.parseInt(rule[7])+"\n");
            
            bw.write("-> max number of turns (0 for infinite turns) \n");
            bw.write("0\n");
            
            bw.write("-> number of the player 2 extra mana points in one round \n");
            bw.write(Integer.parseInt(rule[8])+"\n");
            
            bw.write("-> number of the player 2 extra cards in the first draw \n");
            bw.write(Integer.parseInt(rule[9])+"\n");
            
            bw.write("-> player 2 rules are the same as player 1? (1 for true, 0 for false) \n");
            bw.write("0\n");
            
            bw.write("-> number of simulations \n");
            bw.write("1000\n");
            
            bw.write("-> number of subsets of monsters \n");
            bw.write("1\n");
            
            bw.write("-> % of monsters in each subset \n");
            bw.write("100\n");
            
            bw.write("-> max monster damage(one per subset, each one in separate lines) \n");
            bw.write(Integer.parseInt(rule[10])+"\n");
            
            bw.write("-> min monster damage \n");
            bw.write("1\n");
            
            bw.write("-> % of cards with attack greater than the max \n");
            bw.write("0\n");
            
            bw.write("-> max out of curve attack \n");
            bw.write("0\n");
            
            bw.write("-> max monster health \n");
            bw.write(Integer.parseInt(rule[11])+"\n");
            
            bw.write("-> min monster health \n");
            bw.write("1\n");
            
            bw.write("-> attack twice per turn (0 for subsets without this rule and 1 for subsets with this rule) \n");
            bw.write(Integer.parseInt(rule[12])+"\n");
            
            bw.write("-> attack in the same turn it was summoned (0 for subsets without this rule and 1 for subsets with this rule) \n");
            bw.write(Integer.parseInt(rule[13])+"\n");
            
            bw.write("-> enemy player must target cards with this rule (0 for subsets without this rule and 1 for subsets with this rule) \n");
            bw.write(Integer.parseInt(rule[14])+"\n");
            
            bw.write("-> cards with this rule will only last X rounds (0 for subsets without this rule and X for the subsets with this rule. X represents the number of rounds) \n");
            bw.write("0\n");//teste
            
            bw.write("-> cards with this rule cannot be target (0 for subsets without this rule and 1 for subsets with this rule) \n");
            bw.write("1\n");
            
            bw.write("-> mana formula \n");
            bw.write("(a+h)/2\n");
            
            
            bw.close();
            
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    
    
    public static void printSimplifiedRulesToFile (String [] rule, int id) {
        try {
            File file = new File ("../results/id"+id+"/SimplifiedRulesP1.txt");
            if (!file.exists ()) {
                file.createNewFile ();
            }
            FileWriter fw = new FileWriter (file.getAbsoluteFile());
            BufferedWriter bw = new BufferedWriter (fw);
            
            
            bw.write("0\n");
            
            bw.write(Integer.parseInt(rule[0])+"\n");
            
            bw.write(Integer.parseInt(rule[1])+"\n");
            
            bw.write(Integer.parseInt(rule[2])+"\n");
            
            bw.write(Integer.parseInt(rule[3])+"\n");
            
            bw.write(Integer.parseInt(rule[4])+"\n");
            
            bw.write(Integer.parseInt(rule[5])+"\n");
            
            bw.write(Integer.parseInt(rule[6])+"\n");
            
            bw.write(Integer.parseInt(rule[7])+"\n");
            
            bw.write("0\n");
            
            bw.write(Integer.parseInt(rule[8])+"\n");
            
            bw.write(Integer.parseInt(rule[9])+"\n");

            bw.write("0\n");

            bw.write("1000\n");

            bw.write("1\n");

            bw.write("100\n");
            
            bw.write(Integer.parseInt(rule[10])+"\n");

            bw.write("1\n");

            bw.write("0\n");

            bw.write("0\n");

            bw.write(Integer.parseInt(rule[11])+"\n");

            bw.write("1\n");

            bw.write(Integer.parseInt(rule[12])+"\n");

            bw.write(Integer.parseInt(rule[13])+"\n");
            
            bw.write(Integer.parseInt(rule[14])+"\n");
            
            bw.write("0\n");//teste

            bw.write(Integer.parseInt(rule[15])+"\n");

            bw.write("(a+h)/2\n");
            
            
            bw.close();
            
        } catch (IOException e) {
            e.printStackTrace();
        }
        
        /*
        try {
            File file2 = new File ("../results/id"+id+"/SimplifiedRulesP2.txt");
            if (!file2.exists ()) {
                file2.createNewFile ();
            }
            FileWriter fw2 = new FileWriter (file2.getAbsoluteFile());
            BufferedWriter bw2 = new BufferedWriter (fw2);

            
            bw2.write("0\n");

            bw2.write(Integer.parseInt(rule[17])+"\n");
 
            bw2.write(Integer.parseInt(rule[18])+"\n");
            
            bw2.write(Integer.parseInt(rule[19])+"\n");
            
            bw2.write(Integer.parseInt(rule[20])+"\n");
            
            bw2.write(Integer.parseInt(rule[21])+"\n");
            
            bw2.write(Integer.parseInt(rule[22])+"\n");
            
            bw2.write(Integer.parseInt(rule[23])+"\n");
            
            bw2.write(Integer.parseInt(rule[24])+"\n");
            
            bw2.write("0\n");
            
            bw2.write(Integer.parseInt(rule[25])+"\n");
            
            bw2.write(Integer.parseInt(rule[26])+"\n");
            
            bw2.write("0\n");
            
            bw2.write("1000\n");
            
            bw2.write("1\n");
            
            bw2.write("100\n");
            
            bw2.write(Integer.parseInt(rule[27])+"\n");
            
            bw2.write("1\n");
            
            bw2.write("0\n");
            
            bw2.write("0\n");
            
            bw2.write(Integer.parseInt(rule[28])+"\n");
            
            bw2.write("1\n");
            
            bw2.write(Integer.parseInt(rule[29])+"\n");
            
            bw2.write(Integer.parseInt(rule[30])+"\n");
            
            bw2.write(Integer.parseInt(rule[31])+"\n");
            
            bw2.write(Integer.parseInt(rule[32])+"\n");
            
            bw2.write(Integer.parseInt(rule[33])+"\n");
            
            bw2.write("(a+h)/2\n");
            
            
            bw2.close();
            
        } catch (IOException e) {
            e.printStackTrace();
        }
        */
        
        try {
            File file = new File ("../results/id"+id+"/SimplifiedRulesP2.txt");
            if (!file.exists ()) {
                file.createNewFile ();
            }
            FileWriter fw = new FileWriter (file.getAbsoluteFile());
            BufferedWriter bw = new BufferedWriter (fw);
            
            
            bw.write("0\n");
            
            bw.write(Integer.parseInt(rule[0])+"\n");
            
            bw.write(Integer.parseInt(rule[1])+"\n");
            
            bw.write(Integer.parseInt(rule[2])+"\n");
            
            bw.write(Integer.parseInt(rule[3])+"\n");
            
            bw.write(Integer.parseInt(rule[4])+"\n");
            
            bw.write(Integer.parseInt(rule[5])+"\n");
            
            bw.write(Integer.parseInt(rule[6])+"\n");
            
            bw.write(Integer.parseInt(rule[7])+"\n");
            
            bw.write("0\n");
            
            bw.write(Integer.parseInt(rule[8])+"\n");
            
            bw.write(Integer.parseInt(rule[9])+"\n");
            
            bw.write("0\n");
            
            bw.write("1000\n");
            
            bw.write("1\n");
            
            bw.write("100\n");
            
            bw.write(Integer.parseInt(rule[10])+"\n");
            
            bw.write("1\n");
            
            bw.write("0\n");
            
            bw.write("0\n");
            
            bw.write(Integer.parseInt(rule[11])+"\n");
            
            bw.write("1\n");
            
            bw.write(Integer.parseInt(rule[12])+"\n");
            
            bw.write(Integer.parseInt(rule[13])+"\n");
            
            bw.write(Integer.parseInt(rule[14])+"\n");
            
            bw.write("0\n");//teste
            
            bw.write(Integer.parseInt(rule[15])+"\n");
            
            bw.write("(a+h)/2\n");
            
            
            bw.close();
            
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    
    public static void main (String [] args) {
        int numberOfExecutions = 10;
        
        for (int t = 1; t <= numberOfExecutions; t++) {
            // Create a factory
            char[] chars = new char[10];
            chars [0] = '0';
            chars [1] = '1';
            chars [2] = '2';
            chars [3] = '3';
            chars [4] = '4';
            chars [5] = '5';
            chars [6] = '6';
            chars [7] = '7';
            chars [8] = '8';
            chars [9] = '9';
        
            //regras diferentes para p1 e p2
            //CandidateFactory<String> factory = new StringFactory(chars, 34);
            
            //regras iguais para p1 e p2
            CandidateFactory<String> factory = new StringFactory(chars, 16);
        
            // Create a pipeline that applies cross-over then mutation.
            List<EvolutionaryOperator<String>> operators
            = new LinkedList<EvolutionaryOperator<String>>();
            operators.add(new StringMutation(chars, new Probability(0.05)));
            operators.add(new StringCrossover());
            EvolutionaryOperator<String> pipeline
            = new EvolutionPipeline<String>(operators);
        
        
            FitnessEvaluator<String> fitnessEvaluator = new StringEvaluator();
            SelectionStrategy<Object> selection = new RouletteWheelSelection();
            Random rng = new MersenneTwisterRNG();
        
        
            EvolutionEngine<String> engine
            = new GenerationalEvolutionEngine<String>(factory,
                                                      pipeline,
                                                      fitnessEvaluator,
                                                      selection,
                                                      rng);
        
            engine.addEvolutionObserver(new EvolutionObserver<String>()
            {
                public void populationUpdate(PopulationData<? extends String> data)
                {
                
                    String [] list = new String [data.getBestCandidate().length()];
                
                    for (int i = 0; i < data.getBestCandidate().length(); i++) {
                        char  chars = data.getBestCandidate().charAt(i);
                        list [i] = chars+"";
                    }
                
                    String listFormated = format (list);
                
                    System.out.printf("Generation %d: %s\n",
                                      data.getGenerationNumber(),
                                      listFormated);
                }
            });
        
            String result = engine.evolve(10, 2, new TargetFitness(0,false));
            char [] resultChar = result.toCharArray();
            String [] list3 = new String [resultChar.length];
        
            for (int i = 0; i < resultChar.length; i++) {
                list3[i] = resultChar[i]+"";
            }
        
            result = format(list3);
        
            System.out.println(result);
        
            list3 = formatToFile(list3);
        
            printResultToFile (list3,(t));
            
            printSimplifiedRulesToFile (list3,(t));
            
            printResultToFile1Min (list3,(t));
            
            printResultToFile1Max (list3,(t));
            
            printResultToFile2Min (list3,(t));
            
            printResultToFile2Max (list3,(t));
            
            printResultToFile3Min (list3,(t));
            
            printResultToFile3Max (list3,(t));
            
            printResultToFile4Min (list3,(t));
            
            printResultToFile4Max (list3,(t));
            
            printResultToFile5Min (list3,(t));
            
            printResultToFile5Max (list3,(t));
            
            printResultToFile6Min (list3,(t));
            
            printResultToFile6Max (list3,(t));
            
            printResultToFile7Min (list3,(t));
            
            printResultToFile7Max (list3,(t));
            
            printResultToFile8Min (list3,(t));
            
            printResultToFile8Max (list3,(t));
            
            printResultToFile9Min (list3,(t));
            
            printResultToFile9Max (list3,(t));
            
            printResultToFile10Min (list3,(t));
            
            printResultToFile10Max (list3,(t));
            
            printResultToFile11Min (list3,(t));
            
            printResultToFile11Max (list3,(t));
            
            printResultToFile12Min (list3,(t));
            
            printResultToFile12Max (list3,(t));
            
            printResultToFile13Min (list3,(t));
            
            printResultToFile13Max (list3,(t));
            
            printResultToFile14Min (list3,(t));
            
            printResultToFile14Max (list3,(t));
            
            printResultToFile15Min (list3,(t));
            
            printResultToFile15Max (list3,(t));
            
            printResultToFile16Min (list3,(t));
            
            printResultToFile16Max (list3,(t));
        }
    }
}









