class hand {
    int cardsInHand;
    int handSize;
    card cards [];
    
    public hand (int maxHandSize) {
        cardsInHand = 0;
        handSize = maxHandSize;
        cards = new card [handSize + 1];
    }
    
    int getNumberOfCardsInHand () {
        return cardsInHand;
    }
    
    boolean addCard (card x) {
        boolean out = true;
        if (cardsInHand >= handSize) {
            out = false;
        } else {
            cards [cardsInHand + 1] = x;
            cardsInHand++;
        }
        return out;
    }
    
    card [] returnAllCards () {
        return cards;
    }
    
    card returnCard (int cardId) {
        card out = null;
        if (cardId <= cardsInHand && cardId > 0) {
            out = cards[cardId];
        }
        return out;
    }
    
    boolean removeCard (int cardId) {
        boolean out = false;
        if (cardId <= cardsInHand && cardId > 0) {
            out = true;
            for (int i = cardId; i < cardsInHand; i++){
                cards[i] = cards[i+1];
            }
            cardsInHand--;
        }
        return out;
    }
    
    void printHand () {
        for (int i = 1; i <= cardsInHand; i++) {
            card x = cards[i];
            x.printCard();
        }
    }
    
    public static void main (String [] args) {
        
    }
}



















