class card {
    private String name;
    private int subset;
    private int attack;
    private int health;
    private int mana;
    private int remainingRounds;
    
    private boolean canAttack;
    
    public card () {
        remainingRounds = -5;
    }
    
    void setName (String n) {
        name = n;
    }
    
    void setSubset (int s) {
        subset = s;
    }
    
    void setAttack (int a) {
        attack = a;
    }
    
    void setHealth (int h) {
        health = h;
    }
    
    void setMana (int m) {
        mana = m;
    }
    
    String getName () {
        return name;
    }
    
    int getSubset () {
        return subset;
    }
    
    int getAttack () {
        return attack;
    }
    
    int getHealth () {
        return health;
    }
    
    int getMana () {
        return mana;
    }
    
    void takeDamage (int d) {
        health = health - d;
    }
    
    boolean isDead () {
        boolean dead = false;
        if (health <= 0) {
            dead = true;
        }
        return dead;
    }
    
    void setCanAttackFalse () {
        canAttack = false;
    }
    
    void setCanAttackTrue () {
        canAttack = true;
    }
    
    boolean getCanAttack () {
        return canAttack;
    }
    
    void setRemainingRounds (int x) {
        remainingRounds = x;
    }
    
    int getRemainingRounds () {
        return remainingRounds;
    }
    
    void decreaseRemainingRounds () {
        remainingRounds--;
    }
    
    void printCard () {
        if (remainingRounds == -5) {
            System.out.println ("Name "+name);
            System.out.println ("Subset "+subset);
            System.out.println ("Attack "+attack);
            System.out.println ("Health "+health);
            System.out.println ("Mana "+mana);
            System.out.println();
        } else {
            System.out.println ("Name "+name);
            System.out.println ("Subset "+subset);
            System.out.println ("Attack "+attack);
            System.out.println ("Health "+health);
            System.out.println ("Mana "+mana);
            System.out.println ("Remaining Rounds "+remainingRounds);
            System.out.println();
        }
    }
    
}





