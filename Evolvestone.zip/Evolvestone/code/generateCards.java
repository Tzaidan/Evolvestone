import java.io.*;
import java.util.Random;
import java.lang.Math;


class generateCards {
    
    public generateCards () {
        
    }
    
    public card [] generateToMemory (int playerId, rules r) {
        card deck [];
        
        int numberOfCards = r.getMaxCardsInDeck();
        
        deck = new card [numberOfCards];
        
        int numberOfSubsets = r.getNumberOfMonstersSubsets();
        int [] percentagePerSubset = r.getAmountOfMonstersPerSubset();
        int [] maxCardIdInEachSubset = new int [numberOfSubsets];
        
        for (int i = 0; i < numberOfSubsets - 1; i++) {
            if (i == 0) {
                maxCardIdInEachSubset[i] = (numberOfCards * percentagePerSubset[i]) / 100;
            } else {
                maxCardIdInEachSubset[i] = ((numberOfCards * percentagePerSubset[i]) / 100) + maxCardIdInEachSubset[i-1];
            }
        }
        maxCardIdInEachSubset[numberOfSubsets - 1] = numberOfCards;
        
        
        int [] outOfCurveAttack = new int [numberOfSubsets]; // registra o numero de cartas com ataque fora da curva em cada subset
            
        for (int i = 0; i < numberOfSubsets; i++) {
            if (r.getAmountOfCardsWithAttackGreaterThanMax(i) != 0) {
                double temp = (numberOfCards * percentagePerSubset[i]) / 100.0;
                outOfCurveAttack [i] = (int)Math.ceil((temp*r.getAmountOfCardsWithAttackGreaterThanMax(i))/100.0);
            }
        }
            
        int [] countOutOfCurve = new int [numberOfSubsets];
        for (int i = 0; i < numberOfSubsets; i++) {
            countOutOfCurve[i] = 0;
        }
        
        int count2 = 0;
        int count = 0;
        for (int i = 0; i < numberOfCards; i++) {
                
            Random rand = new Random();
                    
                    
                
            if ((i / maxCardIdInEachSubset[count]) < 1.0) {
                String name = "card"+i;
                int subset = count;
                int a = 0;
                if (r.getAmountOfCardsWithAttackGreaterThanMax(count) == 0) {
                    a = (rand.nextInt((r.getMaxMonsterDemage(count)) - (r.getMinMonsterDemage(count)))+1) + r.getMinMonsterDemage(count);
                } else {
                    if (countOutOfCurve[count] < outOfCurveAttack[count]) {
                        countOutOfCurve[count]++;
                        a = (rand.nextInt((r.getMaxOutOfCurveAttack(count)) - (r.getMaxMonsterDemage(count)))) + r.getMaxMonsterDemage(count);
                    } else {
                        a = (rand.nextInt((r.getMaxMonsterDemage(count)) - (r.getMinMonsterDemage(count)))+1) + r.getMinMonsterDemage(count);
                    }
                }
                int h = (rand.nextInt((r.getMaxMonsterHealth(count)) - (r.getMinMonsterHealth(count)))+1) + r.getMinMonsterHealth(count);
                        
                        
                        
                String manaFormula = r.getManaFormula(count);
                String manaFormulaFix = "";
                for (int jj = 0; jj < manaFormula.length(); jj++) {
                    if (manaFormula.charAt(jj) == 'a') {
                        manaFormulaFix = manaFormulaFix+""+a;
                    } else if (manaFormula.charAt(jj) == 'h') {
                        manaFormulaFix = manaFormulaFix+""+h;
                    } else {
                        manaFormulaFix = manaFormulaFix+""+manaFormula.charAt(jj);
                    }
                }
                        
                parser par = new parser (manaFormulaFix);
                int m = (int) par.parse();
                    
                int attack = a;
                int health = h;
                int mana = m;
                
                deck[count2] = new card();
                
                deck[count2].setName(name);
                deck[count2].setSubset(subset);
                deck[count2].setAttack(attack);
                deck[count2].setHealth(health);
                deck[count2].setMana(mana);
                
                count2++;
                
                
            } else {
                if (i < (numberOfCards)) {
                    i--;
                    count++;
                }
            }

        }
        return deck;
        
    }
    
    public void generateToFile (int playerId, rules r) {
        int numberOfCards = r.getMaxCardsInDeck();
        int numberOfSubsets = r.getNumberOfMonstersSubsets();
        int [] percentagePerSubset = r.getAmountOfMonstersPerSubset();
        int [] maxCardIdInEachSubset = new int [numberOfSubsets];
        
        for (int i = 0; i < numberOfSubsets - 1; i++) {
            if (i == 0) {
                maxCardIdInEachSubset[i] = (numberOfCards * percentagePerSubset[i]) / 100;
            } else {
                maxCardIdInEachSubset[i] = ((numberOfCards * percentagePerSubset[i]) / 100) + maxCardIdInEachSubset[i-1];
            }
        }
        maxCardIdInEachSubset[numberOfSubsets - 1] = numberOfCards;
        
        
        int [] outOfCurveAttack = new int [numberOfSubsets]; // registra o numero de cartas com ataque fora da curva em cada subset
        
        for (int i = 0; i < numberOfSubsets; i++) {
            if (r.getAmountOfCardsWithAttackGreaterThanMax(i) != 0) {
                double temp = (numberOfCards * percentagePerSubset[i]) / 100.0;
                outOfCurveAttack [i] = (int)Math.ceil((temp*r.getAmountOfCardsWithAttackGreaterThanMax(i))/100.0);
            }
        }
        
        int [] countOutOfCurve = new int [numberOfSubsets];
        for (int i = 0; i < numberOfSubsets; i++) {
            countOutOfCurve[i] = 0;
        }
        
        File file1 = new File ("../cards/Player"+playerId);
        deleteFolder(file1);
        
        int count = 0;
        for (int i = 0; i < numberOfCards; i++) {
            try {
                File file = new File ("../cards/Player"+playerId+"/card"+i+".txt");
                if (!file.exists ()) {
                    file.createNewFile ();
                }
                FileWriter fw = new FileWriter (file.getAbsoluteFile());
                BufferedWriter bw = new BufferedWriter (fw);
                
                Random rand = new Random();
                
                
                
                if ((i / maxCardIdInEachSubset[count]) < 1.0) {
                    String name = "card"+i+"\n";
                    String subset = "subset "+count+"\n";
                    int a = 0;
                    if (r.getAmountOfCardsWithAttackGreaterThanMax(count) == 0) {
                        a = (rand.nextInt((r.getMaxMonsterDemage(count)) - (r.getMinMonsterDemage(count)))+1) + r.getMinMonsterDemage(count);
                    } else {
                        if (countOutOfCurve[count] < outOfCurveAttack[count]) {
                            countOutOfCurve[count]++;
                            a = (rand.nextInt((r.getMaxOutOfCurveAttack(count)) - (r.getMaxMonsterDemage(count)))) + r.getMaxMonsterDemage(count);
                        } else {
                            a = (rand.nextInt((r.getMaxMonsterDemage(count)) - (r.getMinMonsterDemage(count)))+1) + r.getMinMonsterDemage(count);
                        }
                    }
                    int h = (rand.nextInt((r.getMaxMonsterHealth(count)) - (r.getMinMonsterHealth(count)))+1) + r.getMinMonsterHealth(count);
                    
                    
                    
                    String manaFormula = r.getManaFormula(count);
                    String manaFormulaFix = "";
                    for (int jj = 0; jj < manaFormula.length(); jj++) {
                        if (manaFormula.charAt(jj) == 'a') {
                            manaFormulaFix = manaFormulaFix+""+a;
                        } else if (manaFormula.charAt(jj) == 'h') {
                            manaFormulaFix = manaFormulaFix+""+h;
                        } else {
                            manaFormulaFix = manaFormulaFix+""+manaFormula.charAt(jj);
                        }
                    }
                    
                    parser par = new parser (manaFormulaFix);
                    int m = (int) par.parse();
                    
                    String attack = "attack "+a+"\n";
                    String health = "health "+h+"\n";
                    String mana = "mana "+m+"\n";
                    
                    bw.write(name);
                    bw.write(subset);
                    bw.write(attack);
                    bw.write(health);
                    bw.write(mana);
                    
                    bw.close();
                } else {
                    if (i < (numberOfCards)) {
                        i--;
                        count++;
                    }
                }
                
                
                
            } catch (Exception e) {
                e.printStackTrace();
            }
            
        }
        
    }
    
    public static void deleteFolder(File folder) {
        File[] files = folder.listFiles();
        if(files!=null) {
            for(File f: files) {
                if(!f.isDirectory()) {
                    f.delete();
                }
            }
        }
    }
    
    void generate (rules r1, rules r2) {
        generateToMemory(1,r1);
        generateToMemory(2,r2);
    }
    
    public static void main (String [] args) {
    }
    
}
