import java.lang.Math;

class deck {
    private int playerId;
    private int deckLength;
    private card cards [];
    int cardsLeft;
    rules r;
    
    public deck (int id, int cardsInDeck, rules rule) {
        playerId = id;
        deckLength = cardsInDeck;
        cards = new card [cardsInDeck];
        cardsLeft = deckLength;
        r = rule;
        
    }
    
    void getDeck () {
        generateCards g = new generateCards( );
        cards = g.generateToMemory(playerId, r);
        
        
        //maneira antiga de obter deck. Dessa maneira cada carta e gravada em arquivo
        /**
        readCards r = new readCards (deckLength, playerId);
        for (int i = 0; i < deckLength; i++) {
            cards [i] = r.returnPlayerCard (i);
        }
         */
        
    }
    
    card returnCard (int cardId) {
        return cards [cardId];
    }
    
    void printDeck () {
        for (int i = 0; i < deckLength; i++) {
            cards[i].printCard();
        }
    }
    
    void shuffle () {
        for (int i = cards.length -1; i > 0; i--) {
            int rand = (int) (Math.random()*(i+1));
            card temp = cards[i];
            cards[i] = cards[rand];
            cards[rand] = temp;
        }
    }
    
    card getNextCard () {
        card out = null;
        if (cardsLeft > 0) {
            out = cards[cardsLeft - 1];
            cardsLeft--;
        }
        return out;
    }
    
    public static void main (String [] args) {

    }

}






