import java.io.*;

class rules {
    
    int [] rulesIdPart1;
    String [][] rulesIdPart2;
    
    public rules () {
        
    }
    
    
    /**
     
     */
    public void printRulesOnFile (int playerId) {
        try {
            File file = new File ("../rulesText/rulesP"+playerId+".txt");
            if (!file.exists ()) {
                file.createNewFile ();
            }
            FileWriter fw = new FileWriter (file.getAbsoluteFile());
            BufferedWriter bw = new BufferedWriter (fw);
            
            
            bw.write("-> start mana points \n");
            bw.write("-> max mana points \n");
            bw.write("-> mana rate \n");
            bw.write("-> life points \n");
            bw.write("-> max number of cards in the deck \n");
            bw.write("-> max number of cards in the hand \n");
            bw.write("-> max number of cards in the battlefield \n");
            bw.write("-> number of cards draw per turn \n");
            bw.write("-> number of cards in the first draw \n");
            bw.write("-> max number of turns (0 for infinite turns) \n");
            bw.write("-> number of the player 2 extra mana points in one round \n");
            bw.write("-> number of the player 2 extra cards in the first draw \n");
            bw.write("-> player 2 rules are the same as player 1? (1 for true, 0 for false) \n");
            bw.write("-> number of simulations \n");
            bw.write("-> number of subsets of monsters \n");
            bw.write("-> % of monsters in each subset \n");
            bw.write("-> max monster damage(one per subset, each one in separate lines) \n");
            bw.write("-> min monster damage \n");
            bw.write("-> % of cards with attack greater than the max \n");
            bw.write("-> max out of curve attack \n");
            bw.write("-> max monster health \n");
            bw.write("-> min monster health \n");
            bw.write("-> attack twice per turn (0 for subsets without this rule and 1 for subsets with this rule) \n");
            bw.write("-> attack in the same turn it was summoned (0 for subsets without this rule and 1 for subsets with this rule) \n");
            bw.write("-> enemy player must target cards with this rule (0 for subsets without this rule and 1 for subsets with this rule) \n");
            bw.write("-> cards with this rule will only last X rounds (0 for subsets without this rule and X for the subsets with this rule. X represents the number of rounds) \n");
            bw.write("-> cards with this rule cannot be target (0 for subsets without this rule and 1 for subsets with this rule) \n");
            bw.write("-> mana formula \n");
            
            
            bw.close();
            
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    
    public void printDefaultRulesOnFile (int playerId) {
        try {
            File file = new File ("../rulesText/rulesP"+playerId+".txt");
            if (!file.exists ()) {
                file.createNewFile ();
            }
            FileWriter fw = new FileWriter (file.getAbsoluteFile());
            BufferedWriter bw = new BufferedWriter (fw);
            
            
            bw.write("-> start mana points \n");
            bw.write("0\n");
            
            bw.write("-> max mana points \n");
            bw.write("15\n");
            
            bw.write("-> mana rate \n");
            bw.write("1\n");
            
            bw.write("-> life points \n");
            bw.write("40\n");
            
            bw.write("-> max number of cards in the deck \n");
            bw.write("35\n");
            
            bw.write("-> max number of cards in the hand \n");
            bw.write("10\n");
            
            bw.write("-> max number of cards in the battlefield \n");
            bw.write("8\n");
            
            bw.write("-> number of cards draw per turn \n");
            bw.write("1\n");
            
            bw.write("-> number of cards in the first draw \n");
            bw.write("5\n");
            
            bw.write("-> max number of turns (0 for infinite turns) \n");
            bw.write("0\n");
            
            bw.write("-> number of the player 2 extra mana points in one round \n");
            bw.write("1\n");
            
            bw.write("-> number of the player 2 extra cards in the first draw \n");
            bw.write("1\n");
            
            bw.write("-> player 2 rules are the same as player 1? (1 for true, 0 for false) \n");
            bw.write("1\n");
            
            bw.write("-> number of simulations \n");
            bw.write("1000\n");
            
            bw.write("-> number of subsets of monsters \n");
            bw.write("3\n");
            
            bw.write("-> % of monsters in each subset \n");
            bw.write("30\n");
            bw.write("50\n");
            bw.write("20\n");
            
            bw.write("-> max monster damage(one per subset, each one in separate lines) \n");
            bw.write("15\n");
            bw.write("10\n");
            bw.write("20\n");
            
            bw.write("-> min monster damage \n");
            bw.write("1\n");
            bw.write("1\n");
            bw.write("5\n");
            
            bw.write("-> % of cards with attack greater than the max \n");
            bw.write("0\n");
            bw.write("0\n");
            bw.write("5\n");
            
            bw.write("-> max out of curve attack \n");
            bw.write("0\n");
            bw.write("0\n");
            bw.write("40\n");
            
            bw.write("-> max monster health \n");
            bw.write("15\n");
            bw.write("10\n");
            bw.write("10\n");
            
            bw.write("-> min monster health \n");
            bw.write("1\n");
            bw.write("1\n");
            bw.write("5\n");
            
            bw.write("-> attack twice per turn (0 for subsets without this rule and 1 for subsets with this rule) \n");
            bw.write("1\n");
            bw.write("0\n");
            bw.write("0\n");
            
            bw.write("-> attack in the same turn it was summoned (0 for subsets without this rule and 1 for subsets with this rule) \n");
            bw.write("1\n");
            bw.write("0\n");
            bw.write("1\n");
            
            bw.write("-> enemy player must target cards with this rule (0 for subsets without this rule and 1 for subsets with this rule) \n");
            bw.write("0\n");
            bw.write("1\n");
            bw.write("0\n");
            
            bw.write("-> cards with this rule will only last X rounds (0 for subsets without this rule and X for the subsets with this rule. X represents the number of rounds) \n");
            bw.write("0\n");
            bw.write("0\n");
            bw.write("2\n");
            
            bw.write("-> cards with this rule cannot be target (0 for subsets without this rule and 1 for subsets with this rule) \n");
            bw.write("0\n");
            bw.write("0\n");
            bw.write("0\n");
            
            bw.write("-> mana formula \n");
            bw.write("(a+h)/2\n");
            bw.write("(2*a)/2\n");
            bw.write("(a+h)/2\n");
            
            
            bw.close();
            
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    
    
    public void printGeneticsRulesOnFile (int playerId, String rule1, String rule2, String rule3, String rule4, String rule5) {
        try {
            File file = new File ("../rulesText/rulesP"+playerId+".txt");
            if (!file.exists ()) {
                file.createNewFile ();
            }
            FileWriter fw = new FileWriter (file.getAbsoluteFile());
            BufferedWriter bw = new BufferedWriter (fw);
            
            
            bw.write("-> start mana points \n");
            bw.write("0\n");
            
            bw.write("-> max mana points \n");
            bw.write("15\n");
            
            bw.write("-> mana rate \n");
            bw.write("1\n");
            
            bw.write("-> life points \n");
            bw.write("30\n");
            
            bw.write("-> max number of cards in the deck \n");
            bw.write("30\n");
            
            bw.write("-> max number of cards in the hand \n");
            bw.write("7\n");
            
            bw.write("-> max number of cards in the battlefield \n");
            bw.write("6\n");
            
            bw.write("-> number of cards draw per turn \n");
            bw.write("1\n");
            
            bw.write("-> number of cards in the first draw \n");
            bw.write("5\n");
            
            bw.write("-> max number of turns (0 for infinite turns) \n");
            bw.write("0\n");
            
            bw.write("-> number of the player 2 extra mana points in one round \n");
            bw.write("1\n");
            
            bw.write("-> number of the player 2 extra cards in the first draw \n");
            bw.write("1\n");
            
            bw.write("-> player 2 rules are the same as player 1? (1 for true, 0 for false) \n");
            bw.write("0\n");
            
            bw.write("-> number of simulations \n");
            bw.write("50\n");
            
            bw.write("-> number of subsets of monsters \n");
            bw.write("1\n");
            
            bw.write("-> % of monsters in each subset \n");
            bw.write("100\n");
            
            bw.write("-> max monster damage(one per subset, each one in separate lines) \n");
            bw.write("15\n");
            
            bw.write("-> min monster damage \n");
            bw.write("1\n");
            
            bw.write("-> % of cards with attack greater than the max \n");
            bw.write("0\n");
            
            bw.write("-> max out of curve attack \n");
            bw.write("0\n");
            
            bw.write("-> max monster health \n");
            bw.write("15\n");
            
            bw.write("-> min monster health \n");
            bw.write("1\n");
            
            bw.write("-> attack twice per turn (0 for subsets without this rule and 1 for subsets with this rule) \n");
            bw.write(rule1+"\n");
            
            bw.write("-> attack in the same turn it was summoned (0 for subsets without this rule and 1 for subsets with this rule) \n");
            bw.write(rule2+"\n");
            
            bw.write("-> enemy player must target cards with this rule (0 for subsets without this rule and 1 for subsets with this rule) \n");
            bw.write(rule3+"\n");
            
            bw.write("-> cards with this rule will only last X rounds (0 for subsets without this rule and X for the subsets with this rule. X represents the number of rounds) \n");
            bw.write(rule4+"\n");
            
            bw.write("-> cards with this rule cannot be target (0 for subsets without this rule and 1 for subsets with this rule) \n");
            bw.write(rule5+"\n");
            
            bw.write("-> mana formula \n");
            bw.write("(a+h)/2\n");
            
            
            bw.close();
            
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    
    public void readRulesFile (int playerId) {
        int rulesWithoutSubset = 15;
        rulesIdPart1 = new int [rulesWithoutSubset];
        try (BufferedReader br = new BufferedReader(new FileReader("../rulesText/rulesP"+playerId+".txt"))) {
            String line;
            
            for (int i = 0; i < rulesWithoutSubset; i++) {
                line = br.readLine();
                line = br.readLine();
                rulesIdPart1 [i] = Integer.parseInt(line);
                //System.out.println(rulesIdPart1[i]);
            }
            
            //System.out.println();
            
            int rulesWithSubset = 13;
            rulesIdPart2 = new String [rulesWithSubset][rulesIdPart1[rulesWithoutSubset-1]]; // rulesWithoutSubset - 1 = the position of the number of subsets of monsters
            
            for (int i = 0; i < rulesWithSubset; i++) {
                line = br.readLine();
                for (int j = 0; j < rulesIdPart1[rulesWithoutSubset-1]; j++) {
                    line = br.readLine();
                    rulesIdPart2[i][j] = line;
                    //System.out.println(rulesIdPart2[i][j]);
                }
                //System.out.println();
            }
            
          
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    
    public void readRulesFileAutomatic (int playerId, int id) {
        int rulesWithoutSubset = 15;
        rulesIdPart1 = new int [rulesWithoutSubset];
        try (BufferedReader br = new BufferedReader(new FileReader("../resultsEstatistica/id"+id+"/printResultToFile16Max.txt"))) {
            String line;
            
            for (int i = 0; i < rulesWithoutSubset; i++) {
                line = br.readLine();
                line = br.readLine();
                rulesIdPart1 [i] = Integer.parseInt(line);
                //System.out.println(rulesIdPart1[i]);
            }
            
            //System.out.println();
            
            int rulesWithSubset = 13;
            rulesIdPart2 = new String [rulesWithSubset][rulesIdPart1[rulesWithoutSubset-1]]; // rulesWithoutSubset - 1 = the position of the number of subsets of monsters
            
            for (int i = 0; i < rulesWithSubset; i++) {
                line = br.readLine();
                for (int j = 0; j < rulesIdPart1[rulesWithoutSubset-1]; j++) {
                    line = br.readLine();
                    rulesIdPart2[i][j] = line;
                    //System.out.println(rulesIdPart2[i][j]);
                }
                //System.out.println();
            }
            
            
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    
    
    public void readRulesForEvolucionary (int playerId,String [] rule) {
        
        int rulesWithoutSubset = 15;
        rulesIdPart1 = new int [rulesWithoutSubset];
        
        if (playerId == 1) {
            rulesIdPart1 [0] = 0;
            rulesIdPart1 [1] = Integer.parseInt(rule[0]);
            rulesIdPart1 [2] = Integer.parseInt(rule[1]);
            rulesIdPart1 [3] = Integer.parseInt(rule[2]);
            rulesIdPart1 [4] = Integer.parseInt(rule[3]);
            rulesIdPart1 [5] = Integer.parseInt(rule[4]);
            rulesIdPart1 [6] = Integer.parseInt(rule[5]);
            rulesIdPart1 [7] = Integer.parseInt(rule[6]);
            rulesIdPart1 [8] = Integer.parseInt(rule[7]);
            rulesIdPart1 [9] = 0;
            rulesIdPart1 [10] = Integer.parseInt(rule[8]);
            rulesIdPart1 [11] = Integer.parseInt(rule[9]);
            rulesIdPart1 [12] = 0;
            rulesIdPart1 [13] = 1000;
            rulesIdPart1 [14] = 1;
        
        
        
            int rulesWithSubset = 13;
            rulesIdPart2 = new String [rulesWithSubset][1];
        
            rulesIdPart2 [0][0] = "100";
            rulesIdPart2 [1][0] = rule[10];
            rulesIdPart2 [2][0] = "1";
            rulesIdPart2 [3][0] = "0";
            rulesIdPart2 [4][0] = "0";
            rulesIdPart2 [5][0] = rule[11];
            rulesIdPart2 [6][0] = "1";
            rulesIdPart2 [7][0] = rule[12];
            rulesIdPart2 [8][0] = rule[13];
            rulesIdPart2 [9][0] = rule[14];
            rulesIdPart2 [10][0] = "0";// teste
            rulesIdPart2 [11][0] = rule[15];
            rulesIdPart2 [12][0] = "(a+h)/2";
        
        } else if (playerId == 2) {
            rulesIdPart1 [0] = 0;
            rulesIdPart1 [1] = Integer.parseInt(rule[17]);
            rulesIdPart1 [2] = Integer.parseInt(rule[18]);
            rulesIdPart1 [3] = Integer.parseInt(rule[19]);
            rulesIdPart1 [4] = Integer.parseInt(rule[20]);
            rulesIdPart1 [5] = Integer.parseInt(rule[21]);
            rulesIdPart1 [6] = Integer.parseInt(rule[22]);
            rulesIdPart1 [7] = Integer.parseInt(rule[23]);
            rulesIdPart1 [8] = Integer.parseInt(rule[24]);
            rulesIdPart1 [9] = 0;
            rulesIdPart1 [10] = Integer.parseInt(rule[25]);
            rulesIdPart1 [11] = Integer.parseInt(rule[26]);
            rulesIdPart1 [12] = 0;
            rulesIdPart1 [13] = 1000;
            rulesIdPart1 [14] = 1;
            
            
            
            int rulesWithSubset = 13;
            rulesIdPart2 = new String [rulesWithSubset][1];
            
            rulesIdPart2 [0][0] = "100";
            rulesIdPart2 [1][0] = rule[27];
            rulesIdPart2 [2][0] = "1";
            rulesIdPart2 [3][0] = "0";
            rulesIdPart2 [4][0] = "0";
            rulesIdPart2 [5][0] = rule[28];
            rulesIdPart2 [6][0] = "1";
            rulesIdPart2 [7][0] = rule[29];
            rulesIdPart2 [8][0] = rule[30];
            rulesIdPart2 [9][0] = rule[31];
            rulesIdPart2 [10][0] = rule[32];
            rulesIdPart2 [11][0] = rule[33];
            rulesIdPart2 [12][0] = "(a+h)/2";
        }
    }
    
    
    public int getStartManaPoints () {
        return rulesIdPart1[0];
    }
    
    public int getMaxManaPoints () {
        return rulesIdPart1[1];
    }
    
    public int getManaRate () {
        return rulesIdPart1[2];
    }
    
    public int getLifePoints () {
        return rulesIdPart1[3];
    }
    
    public int getMaxCardsInDeck () {
        return rulesIdPart1[4];
    }
    
    public int getMaxCardsInHand () {
        return rulesIdPart1[5];
    }
    
    public int getMaxCardsInBattlefield () {
        return rulesIdPart1[6];
    }
    
    public int getCardsDrawPerTurn () {
        return rulesIdPart1[7];
    }
    
    public int getCardsDrawInFirstTurn () {
        return rulesIdPart1[8];
    }
    
    public int getMaxTurns() {
        return rulesIdPart1[9];
    }
    
    public int getPlayer2ExtraManaPoints () {
        return rulesIdPart1[10];
    }
    
    public int getPlayer2ExtraCardsInFirstDraw () {
        return rulesIdPart1[11];
    }
    
    public int getPlayer2RulesEqualsPlayer1 () {
        return rulesIdPart1[12];
    }
    
    public int getNumberOfSimulations () {
        return rulesIdPart1[13];
    }
    
    public int getNumberOfMonstersSubsets () {
        return rulesIdPart1[14];
    }
    
    public int [] getAmountOfMonstersPerSubset () {
        int [] x = new int [getNumberOfMonstersSubsets()];
        for (int i = 0; i < getNumberOfMonstersSubsets(); i++) {
            x[i] = Integer.parseInt(rulesIdPart2[0][i]);
        }
        return x;
    }
    
    public int [] getMaxMonsterDemage () {
        int [] x = new int [getNumberOfMonstersSubsets()];
        for (int i = 0; i < getNumberOfMonstersSubsets(); i++) {
            x[i] = Integer.parseInt(rulesIdPart2[1][i]);
        }
        return x;
    }
    
    public int getMaxMonsterDemage (int i) {
        return Integer.parseInt(rulesIdPart2[1][i]);
    }

    
    public int [] getMinMonsterDemage () {
        int [] x = new int [getNumberOfMonstersSubsets()];
        for (int i = 0; i < getNumberOfMonstersSubsets(); i++) {
            x[i] = Integer.parseInt(rulesIdPart2[2][i]);
        }
        return x;
    }
    
    public int getMinMonsterDemage (int i) {
        return Integer.parseInt(rulesIdPart2[2][i]);
    }
    
    public int [] getAmountOfCardsWithAttackGreaterThanMax () {
        int [] x = new int [getNumberOfMonstersSubsets()];
        for (int i = 0; i < getNumberOfMonstersSubsets(); i++) {
            x[i] = Integer.parseInt(rulesIdPart2[3][i]);
        }
        return x;
    }
                                
    public int getAmountOfCardsWithAttackGreaterThanMax(int i) {
        return Integer.parseInt(rulesIdPart2[3][i]);
    }
                                
    public int [] getMaxOutOfCurveAttack () {
        int [] x = new int [getNumberOfMonstersSubsets()];
        for (int i = 0; i < getNumberOfMonstersSubsets(); i++) {
            x[i] = Integer.parseInt(rulesIdPart2[4][i]);
        }
        return x;
    }
                                
    public int getMaxOutOfCurveAttack (int i) {
        return Integer.parseInt(rulesIdPart2[4][i]);
    }
                                
    public int [] getMaxMonsterHealth () {
        int [] x = new int [getNumberOfMonstersSubsets()];
        for (int i = 0; i < getNumberOfMonstersSubsets(); i++) {
            x[i] = Integer.parseInt(rulesIdPart2[5][i]);
        }
        return x;
    }
    
    public int getMaxMonsterHealth (int i) {
        return Integer.parseInt(rulesIdPart2[5][i]);
    }
                                
    public int [] getMinMonsterHealth () {
        int [] x = new int [getNumberOfMonstersSubsets()];
        for (int i = 0; i < getNumberOfMonstersSubsets(); i++) {
            x[i] = Integer.parseInt(rulesIdPart2[6][i]);
        }
        return x;
    }
    
    public int getMinMonsterHealth (int i) {
        return Integer.parseInt(rulesIdPart2[6][i]);
    }
                                
    public int [] getAttackTwicePerTurnRule () {
        int [] x = new int [getNumberOfMonstersSubsets()];
        for (int i = 0; i < getNumberOfMonstersSubsets(); i++) {
            x[i] = Integer.parseInt(rulesIdPart2[7][i]);
        }
        return x;
    }
    
    public int [] getAttackInTheSameTurnItWasSummonedRule () {
        int [] x = new int [getNumberOfMonstersSubsets()];
        for (int i = 0; i < getNumberOfMonstersSubsets(); i++) {
            x[i] = Integer.parseInt(rulesIdPart2[8][i]);
        }
        return x;
    }
    
    public int [] getMustTargetThisCardRule () {
        int [] x = new int [getNumberOfMonstersSubsets()];
        for (int i = 0; i < getNumberOfMonstersSubsets(); i++) {
            x[i] = Integer.parseInt(rulesIdPart2[9][i]);
        }
        return x;
    }
    
    public int [] getNumberOfRoundsThisCardWillLastRule () {
        int [] x = new int [getNumberOfMonstersSubsets()];
        for (int i = 0; i < getNumberOfMonstersSubsets(); i++) {
            x[i] = Integer.parseInt(rulesIdPart2[10][i]);
        }
        return x;
    }
    
    public int [] getCannotBeTargetRule () {
        int [] x = new int [getNumberOfMonstersSubsets()];
        for (int i = 0; i < getNumberOfMonstersSubsets(); i++) {
            x[i] = Integer.parseInt(rulesIdPart2[11][i]);
        }
        return x;
    }
    
    public String [] getManaFormula () {
        return rulesIdPart2 [12];
    }
    
    public String getManaFormula (int i) {
        return rulesIdPart2 [12][i];
    }

    
    public static void main (String [] args) {
        rules r = new rules ();
        
        
        //r.printRulesOnFile(1);
        //r.printRulesOnFile(2);
        
        //r.printDefaultRulesOnFile(1);
        //r.printDefaultRulesOnFile(2);
        
        
        //r.readRulesFile(1);
        
        //int [] x = r.getMustTargetThisCardRule();
        //System.out.println(x[1]);
        
        //String [] y = r.getManaFormula();
        //System.out.println(y[1]);
        
    }
}





